# IngeTrazo Material Studio v0.4.14

Target: IngeTrazo 0.6.x · Blender 5.3 (with legacy Blender 4.x compositor fallback)

## What's new in v0.4.13

- Adds **Procedural Surface Relief** for materials that do not have a dedicated Height Map.
- Pattern options: Brick / Mortar, Stone / Cellular, Concrete / Plaster, Wood Grain, Fabric Weave, and Fine Noise.
- Controls for pattern scale, relief strength, relief depth, detail, contrast, and pattern inversion.
- Procedural relief is added as a separate Bump layer. It does not change Base Color or the source material in the .igz document.
- The procedural height output can also feed optional Cycles adaptive displacement when that feature is enabled and supported by the installed Blender version.
- Existing image-based Height / Normal maps, base-texture bump, micro-bump, material presets, Emission, Glow / Bloom, lighting, camera, and render controls are retained.
- New controls are stored per material in the .igz project. Existing v0.4.12 projects remain compatible; procedural relief defaults to off unless enabled.

## Install

Preferred installation:
1. Open **Extensions → Extension Manager** in IngeTrazo.
2. Find **Material Studio** and choose **Install**.

Manual installation:
1. Close IngeTrazo.
2. Copy the complete `material_studio` folder from this ZIP into the user plugins folder.
3. Reopen IngeTrazo and open **Material Studio**.

## Test procedural brick relief

1. Select the brick material in Material Studio.
2. Open **Maps & Relief**.
3. Find **Procedural Surface Relief · no image map required**.
4. Enable **Enable procedural surface pattern**.
5. Choose **Brick / Mortar**.
6. Start with Pattern scale `8.0`, Relief strength `0.22`, Relief depth `0.003 m`, Pattern detail `4.0`, and Pattern contrast `0.65`.
7. If the raised/recessed areas look reversed, toggle **Invert procedural pattern**.
8. Click **Apply PBR Maps & Relief**, then render.

## Suggested tests

- Try **Concrete / Plaster** on a plain gray material.
- Try **Wood Grain** on a plain brown material.
- Try **Stone / Cellular** on a plain stone-colored material.
- Compare the same view with procedural relief off and on.
- Keep relief depth subtle at first; too much bump can look inflated or noisy.

## Important limitations

- Procedural relief uses shader bump by default, so it changes shading/highlights rather than the object's silhouette.
- True geometric displacement is optional, Cycles-only, and depends on adaptive subdivision support and mesh/render settings in the installed Blender build.
- This package is syntax-checked and the embedded Blender hook is compiled. The actual IngeTrazo UI and final render must still be tested in the user's installation.
