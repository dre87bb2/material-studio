# SPDX-License-Identifier: GPL-3.0-or-later
"""
Material Studio for IngeTrazo 0.6.x (v0.4.13).

Universal per-material PBR editor and a dedicated Blender render path:
Cycles / EEVEE, texture maps, normal and bump relief, optional Cycles
adaptive displacement, camera depth of field, and extended compositor
Glow / Bloom controls with presets, per-material emission AOV isolation, and Blender 5.x compositor support.

The model's native material registry is changed only for the existing
Finish choice. Extended PBR and camera values are stored in this extension's
own document data (the .igz project).
"""
from __future__ import annotations

import json
import math
import re
import time
import weakref
import uuid
from pathlib import Path

from PySide6.QtCore import (
    Qt, QEvent, QProcess, QProcessEnvironment, QSettings, QUrl, QPointF, QRectF,
)
from PySide6.QtGui import (
    QColor, QDesktopServices, QFont, QPainter, QPen, QVector3D,
)
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QGroupBox, QLabel,
    QColorDialog,
    QComboBox, QDoubleSpinBox, QCheckBox, QLineEdit, QPushButton,
    QFileDialog, QMessageBox, QScrollArea, QProgressBar, QSpinBox, QSlider,
    QTabWidget, QListWidget, QListWidgetItem,
)


# Render Style Presets change only the render's ambience, reflection-light
# strength and color-management controls. They do not modify any model
# material, material map, camera, render engine, output size or quality.
RENDER_STYLE_PRESETS = {
    "architectural_daylight": {
        "label": "Architectural Daylight",
        "ambience": "day", "studio_reflections": True,
        "studio_strength": 0.25, "exposure": -0.3, "gamma": 1.0,
        "render_look": "Medium High Contrast",
    },
    "golden_hour": {
        "label": "Golden Hour",
        "ambience": "day", "studio_reflections": True,
        "studio_strength": 0.35, "exposure": -0.35, "gamma": 1.0,
        "render_look": "Medium High Contrast",
    },
    "overcast_soft": {
        "label": "Overcast Soft",
        "ambience": "overcast", "studio_reflections": False,
        "studio_strength": 0.0, "exposure": -0.15, "gamma": 1.0,
        "render_look": "Medium Contrast",
    },
    "studio_product": {
        "label": "Studio Product",
        "ambience": "overcast", "studio_reflections": True,
        "studio_strength": 0.75, "exposure": -0.35, "gamma": 1.0,
        "render_look": "High Contrast",
    },
    "interior_warm": {
        "label": "Interior Warm",
        "ambience": "overcast", "studio_reflections": True,
        "studio_strength": 0.30, "exposure": -0.25, "gamma": 1.0,
        "render_look": "Medium High Contrast",
    },
    "night_architecture": {
        "label": "Night Architecture",
        "ambience": "night", "studio_reflections": True,
        "studio_strength": 0.20, "exposure": -0.15, "gamma": 1.0,
        "render_look": "High Contrast",
    },
    "presentation_white": {
        "label": "Presentation White",
        "ambience": "overcast", "studio_reflections": False,
        "studio_strength": 0.0, "exposure": 0.0, "gamma": 1.0,
        "render_look": "Medium High Contrast",
    },
    "dramatic_exterior": {
        "label": "Dramatic Exterior",
        "ambience": "day", "studio_reflections": True,
        "studio_strength": 0.25, "exposure": -0.8, "gamma": 1.0,
        "render_look": "High Contrast",
    },
}

# Glow presets are starting points only. Every value remains editable,
# and choosing a preset never changes the source model's native materials.
GLOW_PRESETS = {
    "subtle_glow": {
        "label": "Subtle Glow", "effect": "BLOOM", "quality": "HIGH",
        "threshold": 1.0, "strength": 0.65, "size": 0.50,
        "smoothness": 0.25, "saturation": 1.0, "streaks": 6,
        "clamp": False, "maximum": 10.0,
        "emission_boost_enabled": False, "emission_boost": 1.0,
    },
    "led_strip": {
        "label": "LED Strip", "effect": "BLOOM", "quality": "HIGH",
        "threshold": 0.25, "strength": 2.0, "size": 0.85,
        "smoothness": 0.35, "saturation": 1.0, "streaks": 6,
        "clamp": False, "maximum": 10.0,
        "emission_boost_enabled": True, "emission_boost": 1.5,
    },
    "neon_strong": {
        "label": "Neon Strong", "effect": "BLOOM", "quality": "HIGH",
        "threshold": 0.10, "strength": 4.0, "size": 1.60,
        "smoothness": 0.50, "saturation": 1.0, "streaks": 6,
        "clamp": False, "maximum": 10.0,
        "emission_boost_enabled": True, "emission_boost": 2.0,
    },
    "soft_halo": {
        "label": "Soft Halo", "effect": "FOG_GLOW", "quality": "HIGH",
        "threshold": 0.35, "strength": 1.40, "size": 1.20,
        "smoothness": 0.60, "saturation": 1.0, "streaks": 6,
        "clamp": False, "maximum": 10.0,
        "emission_boost_enabled": False, "emission_boost": 1.0,
    },
    "cinematic_bloom": {
        "label": "Cinematic Bloom", "effect": "BLOOM", "quality": "HIGH",
        "threshold": 0.80, "strength": 2.50, "size": 1.40,
        "smoothness": 0.35, "saturation": 0.95, "streaks": 6,
        "clamp": True, "maximum": 10.0,
        "emission_boost_enabled": False, "emission_boost": 1.0,
    },
}

# Emission presets are artistic starting points. They change only the selected
# material's Emission color and strength; Base Color and PBR finish are untouched.
EMISSION_PRESETS = {
    "warm_white": {"label": "LED Warm White", "color": (1.00, 0.66, 0.38), "strength": 2.5},
    "neutral_white": {"label": "LED Neutral White", "color": (1.00, 0.86, 0.70), "strength": 2.2},
    "cool_white": {"label": "LED Cool White", "color": (0.78, 0.88, 1.00), "strength": 2.5},
    "amber": {"label": "Warm Amber", "color": (1.00, 0.30, 0.045), "strength": 2.0},
    "neon_blue": {"label": "Neon Blue", "color": (0.035, 0.18, 1.00), "strength": 3.5},
    "neon_cyan": {"label": "Neon Cyan", "color": (0.015, 0.82, 1.00), "strength": 3.5},
    "neon_pink": {"label": "Neon Pink", "color": (1.00, 0.035, 0.28), "strength": 3.5},
    "neon_green": {"label": "Neon Green", "color": (0.04, 1.00, 0.20), "strength": 3.5},
}

# Three-step shortcut for quickly adjusting the compositor bloom amount.
# It changes only Glow Intensity and Glow Size.
GLOW_LEVELS = {
    0: {"label": "Low", "strength": 0.35, "size": 0.25},
    1: {"label": "Medium", "strength": 0.65, "size": 0.40},
    2: {"label": "High", "strength": 1.00, "size": 0.65},
}


MAP_FILTER = (
    "Image maps (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.exr *.hdr)"
    ";;All files (*.*)"
)

# Values are intentionally conservative starting points, not physically
# exact prescriptions. Users can adjust every parameter afterwards.
MATERIAL_PRESETS = {
    "brick": {
        "label": "Brick / Stone · Deep Relief", "finish": "matte",
        "roughness": 0.84, "metallic": 0.0, "ior": 1.45,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.2,
        "specular": 0.32, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.90, "bump_distance": 0.015,
        "height_contrast": 0.72, "invert_height": True,
        "micro_bump_enabled": True, "micro_bump_strength": 0.10,
        "micro_bump_scale": 110.0,
    },
    "concrete": {
        "label": "Concrete / Plaster", "finish": "matte",
        "roughness": 0.92, "metallic": 0.0, "ior": 1.45,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.2,
        "specular": 0.3, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.48, "bump_distance": 0.008,
        "height_contrast": 0.58, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.12,
        "micro_bump_scale": 85.0,
    },
    "wood": {
        "label": "Wood", "finish": "satin",
        "roughness": 0.52, "metallic": 0.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.08, "coat_roughness": 0.22,
        "specular": 0.45, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.24, "bump_distance": 0.003,
        "height_contrast": 0.52, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.07,
        "micro_bump_scale": 95.0,
    },
    "marble": {
        "label": "Polished Marble", "finish": "gloss",
        "roughness": 0.10, "metallic": 0.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.38, "coat_roughness": 0.045,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.05, "bump_distance": 0.0008,
        "height_contrast": 0.30, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.025,
        "micro_bump_scale": 130.0,
    },
    "metal": {
        "label": "Polished Metal", "finish": "metal",
        "roughness": 0.075, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.2,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.025, "bump_distance": 0.0006,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.02,
        "micro_bump_scale": 180.0,
    },
    "brushed_metal": {
        "label": "Brushed Metal", "finish": "metal",
        "roughness": 0.24, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.2,
        "specular": 0.5, "anisotropy": 0.68,
        "use_base_texture_bump": False,
        "bump_strength": 0.035, "bump_distance": 0.0008,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.025,
        "micro_bump_scale": 220.0,
    },
    "chrome": {
        "label": "Chrome / Mirror Metal", "finish": "metal",
        "roughness": 0.035, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.03,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.0, "bump_distance": 0.0005,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 200.0,
    },
    "glass": {
        "label": "Glass", "finish": "glass",
        "roughness": 0.02, "metallic": 0.0, "ior": 1.45,
        "transmission": 1.0, "coat": 0.0, "coat_roughness": 0.03,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.0, "bump_distance": 0.001,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 100.0,
    },
    "water": {
        "label": "Water", "finish": "water",
        "roughness": 0.03, "metallic": 0.0, "ior": 1.33,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.03,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.12, "bump_distance": 0.02,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 100.0,
    },
    "plastic": {
        "label": "Plastic", "finish": "gloss",
        "roughness": 0.22, "metallic": 0.0, "ior": 1.46,
        "transmission": 0.0, "coat": 0.25, "coat_roughness": 0.07,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.05, "bump_distance": 0.001,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.02,
        "micro_bump_scale": 150.0,
    },
    "ceramic": {
        "label": "Ceramic", "finish": "gloss",
        "roughness": 0.16, "metallic": 0.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.38, "coat_roughness": 0.045,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.04, "bump_distance": 0.0008,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.02,
        "micro_bump_scale": 140.0,
    },
    "porcelain_gloss": {
        "label": "Porcelain / Glossy Ceramic", "finish": "gloss",
        "roughness": 0.07, "metallic": 0.0, "ior": 1.52,
        "transmission": 0.0, "coat": 0.55, "coat_roughness": 0.02,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.025, "bump_distance": 0.0004,
        "height_contrast": 0.30, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 120.0,
    },
    "stainless": {
        "label": "Stainless Steel", "finish": "metal",
        "roughness": 0.14, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.05,
        "specular": 0.5, "anisotropy": 0.15,
        "use_base_texture_bump": False,
        "bump_strength": 0.01, "bump_distance": 0.0004,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 180.0,
    },
    "mirror_chrome": {
        "label": "Mirror Chrome · High Gloss", "finish": "metal",
        "roughness": 0.018, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.02,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.0, "bump_distance": 0.0003,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 180.0,
    },
    "polished_stainless": {
        "label": "Polished Stainless Steel", "finish": "metal",
        "roughness": 0.055, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.04,
        "specular": 0.5, "anisotropy": 0.08,
        "use_base_texture_bump": False,
        "bump_strength": 0.008, "bump_distance": 0.0003,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 180.0,
    },
    "satin_aluminium": {
        "label": "Satin Aluminium", "finish": "metal",
        "roughness": 0.28, "metallic": 1.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.08,
        "specular": 0.5, "anisotropy": 0.48,
        "use_base_texture_bump": False,
        "bump_strength": 0.02, "bump_distance": 0.0005,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.012,
        "micro_bump_scale": 220.0,
    },
    "frosted_glass": {
        "label": "Frosted Glass", "finish": "glass",
        "roughness": 0.28, "metallic": 0.0, "ior": 1.45,
        "transmission": 0.88, "coat": 0.0, "coat_roughness": 0.18,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": False,
        "bump_strength": 0.0, "bump_distance": 0.001,
        "height_contrast": 0.35, "invert_height": False,
        "micro_bump_enabled": False, "micro_bump_strength": 0.0,
        "micro_bump_scale": 100.0,
    },
    "natural_wood": {
        "label": "Natural Wood · Satin", "finish": "satin",
        "roughness": 0.48, "metallic": 0.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.12, "coat_roughness": 0.2,
        "specular": 0.42, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.22, "bump_distance": 0.0025,
        "height_contrast": 0.5, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.055,
        "micro_bump_scale": 105.0,
    },
    "polished_marble": {
        "label": "Polished Marble · Reflective", "finish": "gloss",
        "roughness": 0.075, "metallic": 0.0, "ior": 1.5,
        "transmission": 0.0, "coat": 0.48, "coat_roughness": 0.025,
        "specular": 0.5, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.035, "bump_distance": 0.0006,
        "height_contrast": 0.25, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.018,
        "micro_bump_scale": 135.0,
    },
    "fabric": {
        "label": "Fabric", "finish": "matte",
        "roughness": 0.94, "metallic": 0.0, "ior": 1.45,
        "transmission": 0.0, "coat": 0.0, "coat_roughness": 0.2,
        "specular": 0.25, "anisotropy": 0.0,
        "use_base_texture_bump": True,
        "bump_strength": 0.24, "bump_distance": 0.0025,
        "height_contrast": 0.55, "invert_height": False,
        "micro_bump_enabled": True, "micro_bump_strength": 0.18,
        "micro_bump_scale": 150.0,
    },
}

# Runs inside Blender, after IngeTrazo's standard Finish conversion.
BLENDER_MATERIAL_HOOK = r'''
import re

def _ms_socket(node, names):
    for name in names:
        socket = node.inputs.get(name)
        if socket is not None:
            return socket
    return None


def _ms_set(node, names, value):
    socket = _ms_socket(node, names)
    if socket is None:
        return False
    for link in list(socket.links):
        node.id_data.links.remove(link)
    try:
        socket.default_value = value
        return True
    except (TypeError, ValueError):
        return False


def _ms_srgb_to_linear(value):
    value = max(0.0, float(value))
    if value <= 0.04045:
        return value / 12.92
    return ((value + 0.055) / 1.055) ** 2.4


def _ms_tag(node, label):
    node.label = label
    node["ingetrazo_material_studio"] = True
    return node


def _ms_clean_name(name):
    return "".join(c if c.isalnum() or c in "._-" else "_"
                   for c in str(name)).strip("._-")


def _ms_config_for(name, per_material, global_config):
    # Blender may append .001; IngeTrazo's glTF writer may append _2 when
    # one named material exports as multiple texture/opacity variants.
    base = re.sub(r"\.\d{3}$", "", str(name))
    cfg = per_material.get(base)
    if cfg is not None:
        return cfg
    candidates = sorted(per_material, key=len, reverse=True)
    for key in candidates:
        if base.startswith(key + "_"):
            suffix = base[len(key) + 1:]
            if suffix.isdigit():
                return per_material[key]
    return global_config if global_config else None


def _ms_finish(bsdf, finish):
    spec = ("Specular IOR Level", "Specular")
    if finish == "matte":
        _ms_set(bsdf, ("Roughness",), 0.9)
        _ms_set(bsdf, spec, 0.3)
    elif finish == "satin":
        _ms_set(bsdf, ("Roughness",), 0.45)
    elif finish == "gloss":
        _ms_set(bsdf, ("Roughness",), 0.12)
        _ms_set(bsdf, ("Coat Weight", "Clearcoat"), 0.5)
        _ms_set(bsdf, ("Coat Roughness", "Clearcoat Roughness"), 0.04)
    elif finish == "metal":
        _ms_set(bsdf, ("Metallic",), 1.0)
        _ms_set(bsdf, ("Roughness",), 0.12)
    elif finish == "glass":
        _ms_set(bsdf, ("Roughness",), 0.02)
        _ms_set(bsdf, ("Metallic",), 0.0)
        _ms_set(bsdf, ("IOR",), 1.45)
        _ms_set(bsdf, ("Transmission Weight", "Transmission"), 1.0)
        _ms_set(bsdf, ("Alpha",), 1.0)
    elif finish == "water":
        _ms_set(bsdf, ("Roughness",), 0.03)
        _ms_set(bsdf, ("IOR",), 1.33)
        _ms_set(bsdf, ("Metallic",), 0.0)


def _ms_vector_output(nodes, links, texcoord, cfg, coord_name="UV"):
    coord = texcoord.outputs.get(coord_name) or texcoord.outputs.get("UV")
    if coord is None:
        return None
    scale_u = float(cfg.get("map_scale_u", 1.0))
    scale_v = float(cfg.get("map_scale_v", 1.0))
    offset_u = float(cfg.get("map_offset_u", 0.0))
    offset_v = float(cfg.get("map_offset_v", 0.0))
    rotation = float(cfg.get("map_rotation", 0.0))
    if (abs(scale_u - 1.0) < 1e-6 and abs(scale_v - 1.0) < 1e-6
            and abs(offset_u) < 1e-6 and abs(offset_v) < 1e-6
            and abs(rotation) < 1e-6):
        return coord
    mapping = _ms_tag(nodes.new("ShaderNodeMapping"),
                      "Material Studio · Mapping")
    mapping.inputs["Location"].default_value[0] = offset_u
    mapping.inputs["Location"].default_value[1] = offset_v
    mapping.inputs["Scale"].default_value[0] = scale_u
    mapping.inputs["Scale"].default_value[1] = scale_v
    try:
        from math import radians
        mapping.inputs["Rotation"].default_value[2] = radians(rotation)
    except Exception:
        pass
    links.new(coord, mapping.inputs["Vector"])
    return mapping.outputs["Vector"]



def _ms_apply_base_color_transform(nodes, links, bsdf, cfg):
    """Insert/reuse a persistent Mapping node on each Base Color image vector.

    The Mapping node is deliberately not tagged as a transient Material Studio
    node: render setup runs repeatedly, and deleting it would sever the original
    texture-coordinate chain. Its private marker lets subsequent renders reuse
    and update the same node instead of stacking more Mapping nodes.
    """
    base = _ms_socket(bsdf, ("Base Color",))
    if base is None or not base.is_linked:
        return 0

    # Find image texture nodes anywhere upstream of Principled Base Color.
    stack = [link.from_node for link in list(base.links)]
    visited = set()
    images = []
    while stack:
        node = stack.pop()
        try:
            identity = node.as_pointer()
        except Exception:
            identity = id(node)
        if identity in visited:
            continue
        visited.add(identity)
        if node.type == "TEX_IMAGE" and getattr(node, "image", None) is not None:
            images.append(node)
        for socket in node.inputs:
            if socket.is_linked:
                stack.extend(link.from_node for link in list(socket.links))

    if not images:
        return 0

    scale_u = float(cfg.get("map_scale_u", 1.0))
    scale_v = float(cfg.get("map_scale_v", 1.0))
    offset_u = float(cfg.get("map_offset_u", 0.0))
    offset_v = float(cfg.get("map_offset_v", 0.0))
    rotation = float(cfg.get("map_rotation", 0.0))
    changed = 0

    for image_node in images:
        vector_input = image_node.inputs.get("Vector")
        if vector_input is None:
            continue

        mapping_node = None
        original_source = None
        for link in list(vector_input.links):
            upstream = link.from_node
            if upstream.get("ingetrazo_material_studio_base_mapping"):
                mapping_node = upstream
                break
            original_source = link.from_socket

        if mapping_node is None:
            mapping_node = nodes.new("ShaderNodeMapping")
            mapping_node["ingetrazo_material_studio_base_mapping"] = True
            mapping_node.label = "Material Studio · Base Texture Mapping"
            mapping_node.name = "Material Studio · Base Texture Mapping"
            # Preserve the model's original UV / mapping source when present.
            if original_source is not None:
                links.new(original_source, mapping_node.inputs["Vector"])
            else:
                coord_node = next((n for n in nodes
                                   if n.get("ingetrazo_material_studio_base_coords")), None)
                if coord_node is None:
                    coord_node = nodes.new("ShaderNodeTexCoord")
                    coord_node["ingetrazo_material_studio_base_coords"] = True
                    coord_node.label = "Material Studio · Base Texture Coordinates"
                    coord_node.name = "Material Studio · Base Texture Coordinates"
                mapping_mode = cfg.get("mapping", "UV")
                coord = coord_node.outputs.get(mapping_mode) or coord_node.outputs.get("UV")
                if coord is not None:
                    links.new(coord, mapping_node.inputs["Vector"])
            for link in list(vector_input.links):
                links.remove(link)
            links.new(mapping_node.outputs["Vector"], vector_input)
        else:
            # Mapping already exists from an earlier render; retain its source.
            pass

        mapping_node.inputs["Location"].default_value[0] = offset_u
        mapping_node.inputs["Location"].default_value[1] = offset_v
        mapping_node.inputs["Scale"].default_value[0] = scale_u
        mapping_node.inputs["Scale"].default_value[1] = scale_v
        try:
            from math import radians
            mapping_node.inputs["Rotation"].default_value[2] = radians(rotation)
        except Exception:
            pass
        changed += 1

    return changed

def _ms_load_image(nodes, links, vector_socket, path, label,
                   colorspace="Non-Color"):
    import os
    if not path or not os.path.isfile(path):
        if path:
            say("material studio map missing", label, path)
        return None
    try:
        # A separate datablock prevents Non-Color data maps from changing the
        # colour interpretation of a Base Color image that shares the file.
        image = bpy.data.images.load(path, check_existing=False)
        try:
            image.colorspace_settings.name = colorspace
        except (TypeError, ValueError):
            pass
        node = _ms_tag(nodes.new("ShaderNodeTexImage"), label)
        node.image = image
        if vector_socket is not None:
            links.new(vector_socket, node.inputs["Vector"])
        return node
    except Exception as exc:
        say("material studio map error", label, str(exc))
        return None


def _ms_base_image_as_height(nodes, links, texcoord, bsdf):
    base = _ms_socket(bsdf, ("Base Color",))
    if base is None or not base.is_linked:
        return None

    # Follow the Base Color node chain upstream. This also finds the original
    # image when optional tint/mix nodes sit between the image and the BSDF.
    stack = [link.from_node for link in base.links]
    visited = set()
    source = None
    while stack:
        candidate = stack.pop()
        identity = candidate.as_pointer()
        if identity in visited:
            continue
        visited.add(identity)
        if (candidate.type == "TEX_IMAGE"
                and candidate.image is not None):
            source = candidate
            break
        for socket in candidate.inputs:
            if socket.is_linked:
                stack.extend(link.from_node for link in socket.links)

    if source is None:
        return None
    try:
        image = source.image.copy()
        try:
            image.colorspace_settings.name = "Non-Color"
        except (TypeError, ValueError):
            pass
        node = _ms_tag(nodes.new("ShaderNodeTexImage"),
                       "Material Studio · Base Texture Height")
        node.image = image
        vector = source.inputs.get("Vector")
        if vector is not None and vector.is_linked:
            links.new(vector.links[0].from_socket, node.inputs["Vector"])
        else:
            links.new(texcoord.outputs["UV"], node.inputs["Vector"])
        return node
    except Exception as exc:
        say("material studio base height error", str(exc))
        return None


def _ms_safe_input(node, name, value):
    """Set a node input when that socket exists in this Blender version."""
    try:
        socket = node.inputs.get(name)
        if socket is not None:
            socket.default_value = value
            return True
    except Exception:
        pass
    return False


def _ms_make_procedural_height(nodes, links, vector_socket, cfg):
    """Build a non-destructive procedural height source for solid materials.

    This is intentionally a bump/normal source by default. It does not alter
    Base Color. True geometric displacement can consume the same height output
    when the user separately enables Cycles adaptive displacement.
    """
    if not bool(cfg.get("procedural_relief_enabled", False)):
        return None

    pattern = str(cfg.get("procedural_relief_type", "brick") or "brick").lower()
    if pattern not in ("brick", "stone", "concrete", "wood", "fabric", "noise"):
        pattern = "noise"

    try:
        scale = max(0.1, min(100.0, float(cfg.get("procedural_relief_scale", 8.0))))
        detail = max(0.0, min(10.0, float(cfg.get("procedural_relief_detail", 4.0))))
        contrast = max(0.0, min(1.0, float(cfg.get("procedural_relief_contrast", 0.65))))
        invert = bool(cfg.get("procedural_relief_invert", False))

        mapping = _ms_tag(nodes.new("ShaderNodeMapping"),
                          "Material Studio · Procedural Relief Mapping")
        mapping.inputs["Scale"].default_value = (scale, scale, scale)
        if vector_socket is not None:
            links.new(vector_socket, mapping.inputs["Vector"])

        if pattern == "brick":
            texture = _ms_tag(nodes.new("ShaderNodeTexBrick"),
                              "Material Studio · Procedural Brick Pattern")
            _ms_safe_input(texture, "Scale", 1.0)
            _ms_safe_input(texture, "Brick Width", 0.50)
            _ms_safe_input(texture, "Row Height", 0.25)
            _ms_safe_input(texture, "Mortar Size", 0.025)
            _ms_safe_input(texture, "Mortar Smooth", 0.01)
            _ms_safe_input(texture, "Bias", 0.0)
            _ms_safe_input(texture, "Offset", 0.5)
            _ms_safe_input(texture, "Offset Frequency", 2)
            source_socket = texture.outputs.get("Fac") or texture.outputs.get("Color")
        elif pattern == "stone":
            texture = _ms_tag(nodes.new("ShaderNodeTexVoronoi"),
                              "Material Studio · Procedural Stone Pattern")
            try:
                texture.distance = "EUCLIDEAN"
                texture.feature = "F1"
            except Exception:
                pass
            _ms_safe_input(texture, "Scale", 3.0)
            _ms_safe_input(texture, "Randomness", 0.85)
            source_socket = texture.outputs.get("Distance") or texture.outputs.get("Color")
        elif pattern == "wood":
            texture = _ms_tag(nodes.new("ShaderNodeTexWave"),
                              "Material Studio · Procedural Wood Grain")
            try:
                texture.wave_type = "BANDS"
                texture.bands_direction = "X"
            except Exception:
                pass
            _ms_safe_input(texture, "Scale", 5.0)
            _ms_safe_input(texture, "Distortion", 3.0)
            _ms_safe_input(texture, "Detail", detail)
            _ms_safe_input(texture, "Detail Scale", 2.0)
            _ms_safe_input(texture, "Detail Roughness", 0.5)
            source_socket = texture.outputs.get("Fac") or texture.outputs.get("Color")
        elif pattern == "fabric":
            texture = _ms_tag(nodes.new("ShaderNodeTexWave"),
                              "Material Studio · Procedural Fabric Weave")
            try:
                texture.wave_type = "BANDS"
                texture.bands_direction = "Y"
            except Exception:
                pass
            _ms_safe_input(texture, "Scale", 18.0)
            _ms_safe_input(texture, "Distortion", 0.6)
            _ms_safe_input(texture, "Detail", max(1.0, detail))
            _ms_safe_input(texture, "Detail Scale", 2.0)
            _ms_safe_input(texture, "Detail Roughness", 0.5)
            source_socket = texture.outputs.get("Fac") or texture.outputs.get("Color")
        else:
            texture = _ms_tag(nodes.new("ShaderNodeTexNoise"),
                              "Material Studio · Procedural Surface Noise")
            _ms_safe_input(texture, "Scale", 5.0 if pattern == "concrete" else 8.0)
            _ms_safe_input(texture, "Detail", detail)
            _ms_safe_input(texture, "Roughness", 0.72)
            _ms_safe_input(texture, "Distortion", 0.25)
            source_socket = texture.outputs.get("Fac") or texture.outputs.get("Color")

        vector_input = texture.inputs.get("Vector")
        if vector_input is not None:
            links.new(mapping.outputs["Vector"], vector_input)

        if source_socket is None:
            say("material studio procedural relief: no output socket", pattern)
            return None

        ramp = _ms_tag(nodes.new("ShaderNodeValToRGB"),
                       "Material Studio · Procedural Relief Contrast")
        low = 0.5 - (0.48 * contrast)
        high = 0.5 + (0.48 * contrast)
        ramp.color_ramp.elements[0].position = low
        ramp.color_ramp.elements[1].position = high
        if invert:
            ramp.color_ramp.elements[0].color = (1.0, 1.0, 1.0, 1.0)
            ramp.color_ramp.elements[1].color = (0.0, 0.0, 0.0, 1.0)
        else:
            ramp.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
            ramp.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
        links.new(source_socket, ramp.inputs["Fac"])
        say("material studio procedural relief ready", pattern,
            "scale", scale, "detail", detail, "contrast", contrast)
        return ramp.outputs["Color"]
    except Exception as exc:
        say("material studio procedural relief unavailable", pattern, str(exc))
        return None


def _ms_apply_tint(nodes, links, bsdf, tint):
    if not tint:
        return
    base = _ms_socket(bsdf, ("Base Color",))
    if base is None:
        return
    rgba = (float(tint[0]), float(tint[1]), float(tint[2]), 1.0)
    if base.is_linked:
        source = base.links[0].from_socket
        mix = _ms_tag(nodes.new("ShaderNodeMixRGB"),
                      "Material Studio · Base Color Tint")
        mix.blend_type = "MULTIPLY"
        mix.inputs["Fac"].default_value = 1.0
        mix.inputs["Color2"].default_value = rgba
        links.new(source, mix.inputs["Color1"])
        for link in list(base.links):
            links.remove(link)
        links.new(mix.outputs["Color"], base)
    else:
        try:
            base.default_value = rgba
        except (TypeError, ValueError):
            pass



_MS_EMISSION_AOV_BASE = "IngeTrazo_MS_Emission_Glow"


def _ms_prepare_emission_aov(scene, base_name=_MS_EMISSION_AOV_BASE):
    """Create/reuse a color AOV on every view layer without replacing user AOVs."""
    layers = list(getattr(scene, "view_layers", []) or [])
    if not layers:
        return None

    stored_name = ""
    try:
        stored_name = str(scene.get("ingetrazo_ms_emission_aov_name", "") or "")
    except Exception:
        stored_name = ""

    if stored_name:
        for layer in layers:
            try:
                aov = next((item for item in layer.aovs if item.name == stored_name), None)
                if aov is None:
                    aov = layer.aovs.add()
                    aov.name = stored_name
                    aov.type = "COLOR"
                try:
                    layer.update_render_passes()
                except Exception:
                    pass
            except Exception as exc:
                say("material studio AOV reuse failed", layer.name, str(exc))
                return None
        return stored_name

    used_names = set()
    for layer in layers:
        try:
            used_names.update(str(item.name) for item in layer.aovs)
        except Exception:
            pass

    candidate = str(base_name)
    suffix = 1
    while candidate in used_names:
        candidate = f"{base_name}_{suffix}"
        suffix += 1

    try:
        for layer in layers:
            aov = layer.aovs.add()
            aov.name = candidate
            aov.type = "COLOR"
            try:
                layer.update_render_passes()
            except Exception:
                pass
        scene["ingetrazo_ms_emission_aov_name"] = candidate
        say("material studio emission AOV ready", candidate)
        return candidate
    except Exception as exc:
        say("material studio AOV creation failed", str(exc))
        return None


def _ms_add_emission_aov(nodes, links, bsdf, aov_name, strength, material_name):
    """Write only this Material Studio-managed emitter into the dedicated AOV."""
    color_socket = _ms_socket(bsdf, ("Emission Color", "Emission"))
    if color_socket is None:
        return False

    created = []
    try:
        scale = _ms_tag(nodes.new("ShaderNodeVectorMath"),
                        "Material Studio · Emission Glow Strength")
        created.append(scale)
        scale.operation = "SCALE"
        vector_input = scale.inputs.get("Vector")
        scale_input = scale.inputs.get("Scale")
        vector_output = scale.outputs.get("Vector")
        if vector_input is None or scale_input is None or vector_output is None:
            raise RuntimeError("Vector Math Scale sockets are unavailable")

        if color_socket.is_linked:
            source = color_socket.links[0].from_socket
            links.new(source, vector_input)
        else:
            raw = color_socket.default_value
            vector_input.default_value = tuple(float(v) for v in raw[:3])
        scale_input.default_value = max(0.0, float(strength))

        output = _ms_tag(nodes.new("ShaderNodeOutputAOV"),
                         "Material Studio · Emission Glow AOV")
        created.append(output)
        output.aov_name = str(aov_name)
        color_input = output.inputs.get("Color")
        if color_input is None:
            raise RuntimeError("AOV Output Color input is unavailable")
        links.new(vector_output, color_input)
        say("material studio emission glow isolated", material_name, aov_name)
        return True
    except Exception as exc:
        for node in reversed(created):
            try:
                nodes.remove(node)
            except Exception:
                pass
        say("material studio emission AOV node failed", material_name, str(exc))
        return False

def apply_material_studio(config, engine):
    """Apply independent PBR settings to named materials and global fallback."""
    per_material = (config or {}).get("materials", {})
    global_config = (config or {}).get("global", {})
    if not isinstance(per_material, dict):
        per_material = {}
    if not isinstance(global_config, dict):
        global_config = {}

    # Optional render-only boost: it affects only materials whose Emission
    # controls are managed by Material Studio, inside the temporary Blender
    # render scene. It is never written back to the source .igz material.
    glow_config = (config or {}).get("glow", {})
    if not isinstance(glow_config, dict):
        glow_config = {}
    emission_boost_enabled = (
        bool(glow_config.get("enabled", False))
        and bool(glow_config.get("emission_boost_enabled", False))
    )
    try:
        emission_boost = max(1.0, min(10.0, float(
            glow_config.get("emission_boost", 1.0))))
    except (TypeError, ValueError):
        emission_boost = 1.0

    scene = bpy.context.scene
    glow_source = str(glow_config.get("source", "all_highlights") or "all_highlights").lower()
    emission_aov_name = None
    if bool(glow_config.get("enabled", False)) and glow_source == "emission_only":
        has_emission_glow = any(
            isinstance(item, dict)
            and bool(item.get("emission_enabled", False))
            and bool(item.get("emission_glow_enabled", True))
            for item in per_material.values()
        )
        if has_emission_glow:
            emission_aov_name = _ms_prepare_emission_aov(scene)
        else:
            say("material studio emission-only glow: no eligible material emission is enabled")
    applied = 0
    for mat in bpy.data.materials:
        cfg = _ms_config_for(mat.name, per_material, global_config)
        if not isinstance(cfg, dict) or not cfg:
            continue
        if not mat.use_nodes:
            mat.use_nodes = True
        nodes, links = mat.node_tree.nodes, mat.node_tree.links
        bsdf = next((n for n in nodes if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf is None:
            say("material studio: Principled BSDF not found", mat.name)
            continue

        # Remove only nodes created by this extension; imported base texture,
        # IngeTrazo Finish nodes, and unrelated user nodes are preserved.
        for node in list(nodes):
            if node.get("ingetrazo_material_studio"):
                nodes.remove(node)

        finish = cfg.get("finish", "auto")
        if finish and finish != "auto":
            _ms_finish(bsdf, finish)

        for names, key in (
            (("Roughness",), "roughness"),
            (("Metallic",), "metallic"),
            (("Anisotropic IOR Level", "Anisotropic"), "anisotropy"),
            (("IOR",), "ior"),
            (("Transmission Weight", "Transmission"), "transmission"),
            (("Coat Weight", "Clearcoat"), "coat"),
            (("Coat Roughness", "Clearcoat Roughness"), "coat_roughness"),
            (("Specular IOR Level", "Specular"), "specular"),
        ):
            if key in cfg and cfg[key] is not None:
                _ms_set(bsdf, names, float(cfg[key]))

        _ms_apply_tint(nodes, links, bsdf, cfg.get("base_color_tint"))

        mapping = cfg.get("mapping", "UV")
        if mapping not in ("UV", "Generated", "Object"):
            mapping = "UV"
        texcoord = _ms_tag(nodes.new("ShaderNodeTexCoord"),
                           "Material Studio · Coordinates")
        base_transform_count = _ms_apply_base_color_transform(
            nodes, links, bsdf, cfg)
        if base_transform_count:
            say("material studio base texture transform", mat.name,
                base_transform_count, "image node(s)")
        vector_socket = _ms_vector_output(nodes, links, texcoord, cfg, mapping)

        # Emission is strictly per-material. The global fallback config is
        # intended for shared surface/PBR controls only; allowing its
        # emission_enabled flag to flow into every material turns unrelated
        # textures (including imported entourage figures) into emitters.
        # Resolve the explicit material entry without the global fallback.
        # Old projects without per-material emission keys keep their original
        # imported emission values unchanged.
        emission_cfg = _ms_config_for(mat.name, per_material, {})
        if isinstance(emission_cfg, dict) and "emission_enabled" in emission_cfg:
            emission_color_socket = _ms_socket(
                bsdf, ("Emission Color", "Emission"))
            emission_strength_socket = _ms_socket(
                bsdf, ("Emission Strength",))
            if bool(emission_cfg.get("emission_enabled", False)):
                raw_color = emission_cfg.get("emission_color") or [1.0, 1.0, 1.0]
                try:
                    rgb = [_ms_srgb_to_linear(v) for v in raw_color[:3]]
                    if len(rgb) != 3:
                        raise ValueError("Emission color needs RGB values")
                except Exception:
                    rgb = [1.0, 1.0, 1.0]
                emission_tex = _ms_load_image(
                    nodes, links, vector_socket, emission_cfg.get("emission_map"),
                    "Material Studio · Emission Texture", colorspace="sRGB")
                if emission_tex is not None and emission_color_socket is not None:
                    for link in list(emission_color_socket.links):
                        links.remove(link)
                    links.new(emission_tex.outputs["Color"],
                              emission_color_socket)
                elif emission_color_socket is not None:
                    _ms_set(bsdf, ("Emission Color", "Emission"),
                            (rgb[0], rgb[1], rgb[2], 1.0))
                strength = max(0.0, float(emission_cfg.get("emission_strength", 1.0)))
                if emission_boost_enabled:
                    strength = min(100000.0, strength * emission_boost)
                if emission_strength_socket is not None:
                    _ms_set(bsdf, ("Emission Strength",), strength)
                elif emission_color_socket is not None and emission_tex is None:
                    # Compatibility fallback for older Principled BSDF nodes
                    # that expose only an Emission color input.
                    _ms_set(bsdf, ("Emission Color", "Emission"),
                            (rgb[0] * strength, rgb[1] * strength,
                             rgb[2] * strength, 1.0))
                if (emission_aov_name
                        and bool(emission_cfg.get("emission_glow_enabled", True))):
                    # Modern Principled BSDF has a separate Strength socket.
                    # On legacy nodes, color may already include strength.
                    aov_scale = strength if emission_strength_socket is not None else 1.0
                    _ms_add_emission_aov(
                        nodes, links, bsdf, emission_aov_name, aov_scale, mat.name
                    )
                say("material studio emission enabled", mat.name,
                    "strength", strength,
                    "render-only bloom boost", emission_boost if emission_boost_enabled else 1.0,
                    "texture" if emission_tex is not None else "solid color")
            else:
                if emission_strength_socket is not None:
                    _ms_set(bsdf, ("Emission Strength",), 0.0)
                elif emission_color_socket is not None:
                    _ms_set(bsdf, ("Emission Color", "Emission"),
                            (0.0, 0.0, 0.0, 1.0))

        rough_tex = _ms_load_image(
            nodes, links, vector_socket, cfg.get("roughness_map"),
            "Material Studio · Roughness Map")
        rough_socket = _ms_socket(bsdf, ("Roughness",))
        if rough_tex is not None and rough_socket is not None:
            for link in list(rough_socket.links):
                links.remove(link)
            links.new(rough_tex.outputs["Color"], rough_socket)

        metal_tex = _ms_load_image(
            nodes, links, vector_socket, cfg.get("metallic_map"),
            "Material Studio · Metallic Map")
        metal_socket = _ms_socket(bsdf, ("Metallic",))
        if metal_tex is not None and metal_socket is not None:
            for link in list(metal_socket.links):
                links.remove(link)
            links.new(metal_tex.outputs["Color"], metal_socket)

        normal_out = None
        normal_tex = _ms_load_image(
            nodes, links, vector_socket, cfg.get("normal_map"),
            "Material Studio · Normal Map")
        if normal_tex is not None:
            normal_node = _ms_tag(nodes.new("ShaderNodeNormalMap"),
                                  "Material Studio · Normal")
            normal_node.inputs["Strength"].default_value = float(
                cfg.get("normal_strength", 1.0))
            links.new(normal_tex.outputs["Color"], normal_node.inputs["Color"])
            normal_out = normal_node.outputs["Normal"]

        height_tex = _ms_load_image(
            nodes, links, vector_socket, cfg.get("height_map"),
            "Material Studio · Height Map")
        height_out = height_tex.outputs["Color"] if height_tex else None
        height_source_label = "dedicated height map" if height_tex is not None else None
        if height_out is None and cfg.get("use_base_texture_bump", False):
            base_height = _ms_base_image_as_height(
                nodes, links, texcoord, bsdf)
            if base_height is not None:
                height_out = base_height.outputs["Color"]
                height_source_label = "Base Color image"
        if height_out is not None:
            say("material studio height source", mat.name, height_source_label)
        elif cfg.get("use_base_texture_bump", False):
            say("material studio warning: no image found in Base Color chain", mat.name)

        # Convert the selected height source into a controllable grayscale
        # relief. The invert option is useful for brick images where mortar is
        # brighter than the brick: the mortar becomes recessed instead of raised.
        height_processed = None
        if height_out is not None:
            grayscale = _ms_tag(nodes.new("ShaderNodeRGBToBW"),
                                 "Material Studio · Height to Gray")
            links.new(height_out, grayscale.inputs["Color"])
            ramp = _ms_tag(nodes.new("ShaderNodeValToRGB"),
                           "Material Studio · Height Contrast")
            contrast = max(0.0, min(1.0, float(
                cfg.get("height_contrast", 0.65))))
            low = 0.49 * contrast
            high = 1.0 - low
            ramp.color_ramp.elements[0].position = low
            ramp.color_ramp.elements[1].position = high
            if cfg.get("invert_height", False):
                ramp.color_ramp.elements[0].color = (1.0, 1.0, 1.0, 1.0)
                ramp.color_ramp.elements[1].color = (0.0, 0.0, 0.0, 1.0)
            else:
                ramp.color_ramp.elements[0].color = (0.0, 0.0, 0.0, 1.0)
                ramp.color_ramp.elements[1].color = (1.0, 1.0, 1.0, 1.0)
            links.new(grayscale.outputs["Val"], ramp.inputs["Fac"])
            height_processed = ramp.outputs["Color"]

        final_normal = normal_out
        if height_processed is not None:
            bump = _ms_tag(nodes.new("ShaderNodeBump"),
                           "Material Studio · Main Relief")
            bump.inputs["Strength"].default_value = float(
                cfg.get("bump_strength", 0.45))
            bump.inputs["Distance"].default_value = float(
                cfg.get("bump_distance", 0.008))
            links.new(height_processed, bump.inputs["Height"])
            if final_normal is not None:
                links.new(final_normal, bump.inputs["Normal"])
            final_normal = bump.outputs["Normal"]

        # Optional procedural relief gives plain-color materials a surface
        # structure even when no Height/Normal image map is available.
        procedural_height = _ms_make_procedural_height(
            nodes, links, vector_socket, cfg)
        if procedural_height is not None:
            procedural_bump = _ms_tag(
                nodes.new("ShaderNodeBump"),
                "Material Studio · Procedural Relief")
            procedural_bump.inputs["Strength"].default_value = max(
                0.0, min(1.0, float(cfg.get("procedural_relief_strength", 0.22))))
            procedural_bump.inputs["Distance"].default_value = max(
                0.0, min(0.05, float(cfg.get("procedural_relief_distance", 0.003))))
            links.new(procedural_height, procedural_bump.inputs["Height"])
            if final_normal is not None:
                links.new(final_normal, procedural_bump.inputs["Normal"])
            final_normal = procedural_bump.outputs["Normal"]

        # A second, much finer bump layer adds grain to concrete, brick,
        # timber and brushed finishes without replacing the Base Color map.
        if cfg.get("micro_bump_enabled", False):
            try:
                noise = _ms_tag(nodes.new("ShaderNodeTexNoise"),
                                "Material Studio · Micro Surface")
                noise.inputs["Scale"].default_value = max(
                    1.0, float(cfg.get("micro_bump_scale", 100.0)))
                if noise.inputs.get("Detail") is not None:
                    noise.inputs["Detail"].default_value = 3.0
                coord = texcoord.outputs.get(mapping) or texcoord.outputs.get("Generated")
                if coord is not None:
                    links.new(coord, noise.inputs["Vector"])
                micro = _ms_tag(nodes.new("ShaderNodeBump"),
                                "Material Studio · Micro Bump")
                micro.inputs["Strength"].default_value = float(
                    cfg.get("micro_bump_strength", 0.08))
                micro.inputs["Distance"].default_value = float(
                    cfg.get("micro_bump_distance", 0.0008))
                if final_normal is not None:
                    links.new(final_normal, micro.inputs["Normal"])
                links.new(noise.outputs["Fac"], micro.inputs["Height"])
                final_normal = micro.outputs["Normal"]
            except Exception as exc:
                say("material studio micro bump unavailable", mat.name, str(exc))

        normal_socket = _ms_socket(bsdf, ("Normal",))
        if normal_socket is not None and final_normal is not None:
            for link in list(normal_socket.links):
                links.remove(link)
            links.new(final_normal, normal_socket)

        # Optional geometric displacement. It is Cycles-only and requires
        # adaptive subdivision; bump/normal remain available in both engines.
        # If no image height map exists, the procedural height can be used.
        displacement_height = (height_processed if height_processed is not None
                               else procedural_height)
        if (cfg.get("use_displacement", False) and displacement_height is not None
                and engine == "cycles"):
            try:
                if hasattr(scene.cycles, "feature_set"):
                    scene.cycles.feature_set = "EXPERIMENTAL"
                if hasattr(mat, "cycles") and hasattr(
                        mat.cycles, "displacement_method"):
                    mat.cycles.displacement_method = "BOTH"
                output = next((n for n in nodes
                               if n.type == "OUTPUT_MATERIAL"), None)
                if output is None:
                    output = nodes.new("ShaderNodeOutputMaterial")
                displacement = _ms_tag(
                    nodes.new("ShaderNodeDisplacement"),
                    "Material Studio · True Displacement")
                displacement.inputs["Midlevel"].default_value = float(
                    cfg.get("displacement_midlevel", 0.5))
                displacement.inputs["Scale"].default_value = float(
                    cfg.get("displacement_scale", 0.005))
                links.new(displacement_height, displacement.inputs["Height"])
                out_socket = output.inputs.get("Displacement")
                if out_socket is not None:
                    for link in list(out_socket.links):
                        links.remove(link)
                    links.new(displacement.outputs["Displacement"], out_socket)
                for obj in scene.objects:
                    if (obj.type == "MESH" and mat in obj.data.materials
                            and hasattr(obj, "cycles")
                            and hasattr(obj.cycles, "use_adaptive_subdivision")):
                        obj.cycles.use_adaptive_subdivision = True
                say("material studio displacement enabled", mat.name)
            except Exception as exc:
                say("material studio displacement unavailable", mat.name, str(exc))
        elif cfg.get("use_displacement", False) and engine != "cycles":
            say("material studio: geometric displacement is Cycles-only", mat.name)

        # A gentle procedural wave for the Water preset if no map is supplied.
        if finish == "water" and height_out is None and normal_out is None:
            try:
                noise = _ms_tag(nodes.new("ShaderNodeTexNoise"),
                                "Material Studio · Water Noise")
                noise.inputs["Scale"].default_value = 6.0
                noise.inputs["Detail"].default_value = 5.0
                bump = _ms_tag(nodes.new("ShaderNodeBump"),
                               "Material Studio · Water Ripple")
                bump.inputs["Strength"].default_value = 0.12
                bump.inputs["Distance"].default_value = 0.02
                links.new(noise.outputs["Fac"], bump.inputs["Height"])
                normal_socket = _ms_socket(bsdf, ("Normal",))
                if normal_socket is not None:
                    for link in list(normal_socket.links):
                        links.remove(link)
                    links.new(bump.outputs["Normal"], normal_socket)
            except Exception as exc:
                say("material studio water ripple unavailable", str(exc))

        applied += 1

    if applied:
        say("material studio", applied, "materials configured")




def apply_material_studio_lighting(config):
    """Add broad studio reflection sources and, optionally, a user HDRI."""
    import os
    config = config if isinstance(config, dict) else {}
    scene = bpy.context.scene

    # Optional HDRI replaces the procedural world colour with an image-based
    # environment. This gives reflective metals real surrounding detail.
    hdri_path = str(config.get("hdri_path") or "").strip()
    if hdri_path and os.path.isfile(hdri_path):
        try:
            if scene.world is None:
                scene.world = bpy.data.worlds.new("Material Studio HDRI")
            world = scene.world
            if hasattr(world, "use_nodes"):
                world.use_nodes = True
            nodes, links = world.node_tree.nodes, world.node_tree.links
            background = nodes.get("Background")
            if background is None:
                background = nodes.new("ShaderNodeBackground")
            env = _ms_tag(nodes.new("ShaderNodeTexEnvironment"),
                          "Material Studio · HDRI Environment")
            env.image = bpy.data.images.load(hdri_path, check_existing=True)
            texcoord = nodes.new("ShaderNodeTexCoord")
            direction = texcoord.outputs.get("Generated") or texcoord.outputs.get("Normal")
            if direction is not None:
                links.new(direction, env.inputs["Vector"])
            for link in list(background.inputs["Color"].links):
                links.remove(link)
            links.new(env.outputs["Color"], background.inputs["Color"])
            background.inputs["Strength"].default_value = max(
                0.0, float(config.get("hdri_strength", 0.8)))
            say("material studio HDRI loaded", os.path.basename(hdri_path))
        except Exception as exc:
            say("material studio HDRI error", str(exc))
    elif hdri_path:
        say("material studio HDRI missing", hdri_path)

    if not config.get("enabled", True):
        say("material studio reflections disabled")
        return

    # Softboxes are intended for reflective surfaces, not as a second daylight
    # rig for every scene. Skip them in a matte brick/concrete-only scene.
    reflective = []
    for mat in bpy.data.materials:
        if not getattr(mat, "use_nodes", False) or not mat.node_tree:
            continue
        bsdf = next((n for n in mat.node_tree.nodes
                     if n.type == "BSDF_PRINCIPLED"), None)
        if bsdf is None:
            continue
        metallic_socket = _ms_socket(bsdf, ("Metallic",))
        rough_socket = _ms_socket(bsdf, ("Roughness",))
        transmission_socket = _ms_socket(
            bsdf, ("Transmission Weight", "Transmission"))
        coat_socket = _ms_socket(bsdf, ("Coat Weight", "Clearcoat"))
        try:
            metallic = float(metallic_socket.default_value) if metallic_socket else 0.0
            roughness = float(rough_socket.default_value) if rough_socket else 0.5
            transmission = float(transmission_socket.default_value) if transmission_socket else 0.0
            coat = float(coat_socket.default_value) if coat_socket else 0.0
        except (TypeError, ValueError):
            continue
        if metallic >= 0.15 or roughness <= 0.22 or transmission >= 0.15 or coat >= 0.4:
            reflective.append(mat.name)

    if not reflective:
        say("material studio reflections skipped: no glossy/metal materials")
        return

    say("material studio reflections for", ", ".join(reflective[:6]))

    # Remove tagged lights if this routine is ever reused in a persistent
    # render session, then calculate a model-relative studio rig.
    for obj in list(scene.objects):
        if obj.get("ingetrazo_material_studio_light"):
            bpy.data.objects.remove(obj, do_unlink=True)

    from mathutils import Vector
    mesh_objects = [obj for obj in scene.objects if obj.type == "MESH"]
    if not mesh_objects:
        say("material studio reflections: no mesh objects")
        return

    points = []
    for obj in mesh_objects:
        try:
            points.extend(obj.matrix_world @ Vector(corner)
                          for corner in obj.bound_box)
        except Exception:
            continue
    if not points:
        say("material studio reflections: no model bounds")
        return

    minimum = Vector((min(p.x for p in points),
                      min(p.y for p in points),
                      min(p.z for p in points)))
    maximum = Vector((max(p.x for p in points),
                      max(p.y for p in points),
                      max(p.z for p in points)))
    center = (minimum + maximum) * 0.5
    radius = max((maximum - minimum).length * 0.5, 0.5)

    camera = scene.camera
    if camera is not None:
        view = camera.location - center
    else:
        view = Vector((5.0, -8.0, 4.0))
    if view.length < 1e-6:
        view = Vector((5.0, -8.0, 4.0))
    view.normalize()

    world_up = Vector((0.0, 0.0, 1.0))
    right = view.cross(world_up)
    if right.length < 1e-6:
        right = Vector((1.0, 0.0, 0.0))
    right.normalize()
    up = right.cross(view).normalized()

    strength = max(0.0, min(4.0, float(
        config.get("strength", 1.0))))
    if strength <= 0.0:
        say("material studio reflections: strength is zero")
        return

    # Large rectangular sources create readable highlights on polished
    # metal; a tiny point source would only create a pin-prick reflection.
    rig = (
        ("Key Softbox", -1.45, 0.70, 2.35, 1.00, (1.00, 0.96, 0.90)),
        ("Fill Softbox", 1.55, 0.25, 2.00, 0.62, (0.84, 0.91, 1.00)),
        ("Rim Softbox", -0.35, 1.35, -1.65, 0.78, (1.00, 1.00, 1.00)),
    )
    created = 0
    for name, x, y, z, factor, color in rig:
        position = center + right * (x * radius) + up * (y * radius) + view * (z * radius)
        data = bpy.data.lights.new("Material Studio · " + name, type="AREA")
        data.energy = 180.0 * radius * radius * strength * factor
        data.color = color
        data.shape = "RECTANGLE"
        data.size = max(0.5, radius * 1.8)
        if hasattr(data, "size_y"):
            data.size_y = max(0.35, radius * 1.15)
        if hasattr(data, "use_shadow"):
            data.use_shadow = True
        obj = bpy.data.objects.new("Material Studio · " + name, data)
        scene.collection.objects.link(obj)
        obj.location = position
        obj.rotation_euler = (center - position).to_track_quat("-Z", "Y").to_euler()
        obj["ingetrazo_material_studio_light"] = True
        created += 1

    say("material studio reflections", created, "softboxes")



def _ms_render_style_bounds(scene):
    """Return camera-relative bounds for imported model meshes only."""
    from mathutils import Vector
    mesh_objects = [obj for obj in scene.objects
                    if obj.type == "MESH" and obj.name != "IngeTrazo ground"]
    points = []
    for obj in mesh_objects:
        try:
            points.extend(obj.matrix_world @ Vector(corner)
                          for corner in obj.bound_box)
        except Exception:
            continue
    if not points:
        return None
    minimum = Vector((min(p.x for p in points), min(p.y for p in points),
                      min(p.z for p in points)))
    maximum = Vector((max(p.x for p in points), max(p.y for p in points),
                      max(p.z for p in points)))
    center = (minimum + maximum) * 0.5
    radius = max((maximum - minimum).length * 0.5, 0.5)
    camera = scene.camera
    view = (camera.location - center) if camera is not None else Vector((5, -8, 4))
    if view.length < 1e-6:
        view = Vector((5, -8, 4))
    view.normalize()
    world_up = Vector((0, 0, 1))
    right = view.cross(world_up)
    if right.length < 1e-6:
        right = Vector((1, 0, 0))
    right.normalize()
    up = right.cross(view).normalized()
    return center, radius, view, right, up


def _ms_style_area_light(scene, name, position, target, color, energy, size):
    from mathutils import Vector
    data = bpy.data.lights.new("Material Studio Style · " + name, type="AREA")
    data.energy = max(1.0, float(energy))
    data.color = tuple(color)
    data.shape = "RECTANGLE"
    data.size = max(0.5, float(size))
    if hasattr(data, "size_y"):
        data.size_y = max(0.35, float(size) * 0.68)
    if hasattr(data, "use_shadow"):
        data.use_shadow = True
    obj = bpy.data.objects.new("Material Studio Style · " + name, data)
    scene.collection.objects.link(obj)
    obj.location = position
    obj.rotation_euler = (Vector(target) - Vector(position)).to_track_quat(
        "-Z", "Y").to_euler()
    obj["ingetrazo_render_style_light"] = True
    return obj


def _ms_set_world_color(scene, color, strength, preserve_hdri=True):
    """Set a flat world colour, unless the user supplied an active HDRI."""
    world = scene.world
    if world is None:
        world = bpy.data.worlds.new("Material Studio Render Style World")
        scene.world = world
    if hasattr(world, "use_nodes"):
        world.use_nodes = True
    if not getattr(world, "node_tree", None):
        return False
    nodes, links = world.node_tree.nodes, world.node_tree.links
    background = nodes.get("Background")
    if background is None:
        background = nodes.new("ShaderNodeBackground")
    color_socket = background.inputs.get("Color")
    if color_socket is None:
        return False
    if preserve_hdri:
        for link in list(color_socket.links):
            if link.from_node.type == "TEX_ENVIRONMENT":
                say("render style kept user HDRI; world colour not overridden")
                return False
    for link in list(color_socket.links):
        links.remove(link)
    color_socket.default_value = (*tuple(color), 1.0)
    background.inputs["Strength"].default_value = max(0.0, float(strength))
    return True


def _ms_add_style_fill(scene, style_id):
    bounds = _ms_render_style_bounds(scene)
    if bounds is None:
        say("render style", style_id, "no model bounds for fill lights")
        return
    center, radius, view, right, up = bounds
    # Remove only this feature's own lights; user lights and PBR materials
    # are never changed.
    for obj in list(scene.objects):
        if obj.get("ingetrazo_render_style_light"):
            bpy.data.objects.remove(obj, do_unlink=True)
    if style_id == "studio_product":
        rig = (
            ("Product Key", -0.75, 0.80, 0.95, (1.0, 0.98, 0.94), 190.0),
            ("Product Fill", 0.85, 0.30, 0.30, (0.78, 0.86, 1.0), 85.0),
        )
    elif style_id == "interior_warm":
        rig = (
            ("Warm Key", -0.65, 0.95, 0.85, (1.0, 0.70, 0.43), 250.0),
            ("Warm Fill", 0.85, 0.35, 0.25, (1.0, 0.84, 0.66), 115.0),
        )
    elif style_id == "night_architecture":
        rig = (
            ("Night Warm Accent", -0.75, 0.45, 0.55, (1.0, 0.56, 0.30), 145.0),
            ("Night Cool Fill", 0.90, 0.75, -0.10, (0.48, 0.66, 1.0), 65.0),
        )
    else:
        return
    for name, x, y, z, color, power in rig:
        position = center + right * (x * radius) + up * (y * radius) + view * (z * radius)
        _ms_style_area_light(
            scene, name, position, center, color,
            power * radius * radius, radius * 1.35
        )


def apply_material_studio_user_lights(scene, config):
    """Create user-managed render lights; linked copies share light datablocks."""
    import math
    config = config if isinstance(config, dict) else {}
    if not config.get("enabled", True):
        say("material studio custom lights disabled")
        return

    # Remove only objects owned by this extension's custom-light feature.
    for obj in list(scene.objects):
        if obj.get("ingetrazo_material_studio_user_light"):
            bpy.data.objects.remove(obj, do_unlink=True)

    lights = config.get("lights", []) or []
    data_cache = {}
    created = 0
    for spec in lights:
        if not isinstance(spec, dict) or not spec.get("enabled", True):
            continue
        kind = str(spec.get("type", "AREA")).upper()
        if kind not in ("AREA", "POINT", "SPOT", "SUN"):
            say("material studio custom light skipped: invalid type", kind)
            continue
        light_id = str(spec.get("id", created + 1))
        data_id = str(spec.get("data_id", light_id))
        cache_key = (data_id, kind)
        data = data_cache.get(cache_key)
        if data is None:
            safe_data_id = _ms_clean_name(data_id)[:24] or str(created + 1)
            data_name = "Material Studio Data · " + safe_data_id
            try:
                data = bpy.data.lights.new(data_name, type=kind)
            except Exception as exc:
                say("material studio custom light create failed", spec.get("name"), str(exc))
                continue
            data_cache[cache_key] = data
            try:
                data.energy = max(0.0, float(spec.get("energy", 1000.0)))
                color = spec.get("color", [1.0, 1.0, 1.0])
                data.color = tuple(max(0.0, min(1.0, float(v))) for v in color[:3])
            except Exception as exc:
                say("material studio custom light data warning", str(exc))
            for attr, key, default in (
                ("use_shadow", "use_shadow", True),
                ("use_diffuse", "use_diffuse", True),
                ("use_glossy", "use_glossy", True),
            ):
                if hasattr(data, attr):
                    try:
                        setattr(data, attr, bool(spec.get(key, default)))
                    except Exception:
                        pass
            try:
                if kind == "AREA":
                    shape = str(spec.get("shape", "RECTANGLE"))
                    if shape not in ("SQUARE", "RECTANGLE", "DISK", "ELLIPSE"):
                        shape = "RECTANGLE"
                    data.shape = shape
                    data.size = max(0.001, float(spec.get("size", 4.0)))
                    if hasattr(data, "size_y"):
                        data.size_y = max(0.001, float(spec.get("size_y", 2.0)))
                elif kind == "POINT":
                    data.shadow_soft_size = max(0.001, float(spec.get("soft_size", 0.25)))
                elif kind == "SPOT":
                    data.shadow_soft_size = max(0.001, float(spec.get("soft_size", 0.25)))
                    data.spot_size = math.radians(max(1.0, min(179.0, float(spec.get("spot_size", 45.0)))))
                    data.spot_blend = max(0.0, min(1.0, float(spec.get("spot_blend", 0.15))))
                if kind in ("POINT", "SPOT"):
                    # Blender versions expose custom light distance on Light data.
                    # Keep this guarded for compatibility with different builds.
                    if hasattr(data, "use_custom_distance"):
                        data.use_custom_distance = bool(spec.get("use_custom_range", True))
                    if hasattr(data, "cutoff_distance"):
                        data.cutoff_distance = max(0.01, float(spec.get("range", 10.0)))
                elif kind == "SUN":
                    data.angle = math.radians(max(0.0, min(20.0, float(spec.get("sun_angle", 0.53)))))
            except Exception as exc:
                say("material studio custom light type settings warning", spec.get("name"), str(exc))

        try:
            object_name = str(spec.get("name", "Material Studio Light"))
            obj = bpy.data.objects.new(object_name, data)
            scene.collection.objects.link(obj)
            loc = spec.get("location", [0.0, -5.0, 5.0])
            rot = spec.get("rotation", [45.0, 0.0, 0.0])
            obj.location = tuple(float(v) for v in loc[:3])
            obj.rotation_euler = tuple(math.radians(float(v)) for v in rot[:3])
            obj["ingetrazo_material_studio_user_light"] = True
            obj["ingetrazo_material_studio_light_id"] = light_id
            obj["ingetrazo_material_studio_data_id"] = data_id
            created += 1
        except Exception as exc:
            say("material studio custom light object failed", spec.get("name"), str(exc))
    say("material studio custom lights", created, "created")


def apply_material_studio_render_style(scene, config, engine="cycles"):
    """Apply lighting-only render styles shared by Cycles and EEVEE.

    This function intentionally does not access or modify model materials.
    """
    import math
    config = config if isinstance(config, dict) else {}
    style_id = str(config.get("preset", "architectural_daylight") or "custom")
    hdri_path = str(config.get("hdri_path", "") or "").strip()
    say("render style", style_id, "engine", engine)

    if style_id == "golden_hour":
        sun = next((obj for obj in scene.objects
                    if obj.type == "LIGHT" and obj.name.startswith("IngeTrazo sun")), None)
        if sun is not None:
            sun.data.color = (1.0, 0.70, 0.43)
            sun.data.energy *= 0.88
            sun.data.angle = math.radians(1.15)
        # Keep IngeTrazo's physical sky gradient; the warm sun colour creates
        # the golden-hour character without flattening the sky to one colour.

    elif style_id == "studio_product":
        _ms_set_world_color(scene, (0.30, 0.32, 0.35), 0.38,
                            preserve_hdri=bool(hdri_path))
        _ms_add_style_fill(scene, style_id)

    elif style_id == "interior_warm":
        _ms_set_world_color(scene, (0.38, 0.29, 0.20), 0.32,
                            preserve_hdri=bool(hdri_path))
        _ms_add_style_fill(scene, style_id)

    elif style_id == "night_architecture":
        # Keep the dark-blue night world from IngeTrazo and add warm/cool
        # architectural accents. A user HDRI is left intact by the lighting
        # stage and is not replaced here.
        _ms_add_style_fill(scene, style_id)

    elif style_id == "presentation_white":
        world_changed = _ms_set_world_color(
            scene, (1.0, 1.0, 1.0), 0.8,
            preserve_hdri=bool(hdri_path)
        )
        # This is the extension's generated shadow-catching plane, not a
        # user's model material. It is safe to make the presentation ground white.
        ground = next((obj for obj in scene.objects
                       if obj.name == "IngeTrazo ground" and obj.type == "MESH"), None)
        if ground is not None and ground.data.materials:
            mat = ground.data.materials[0]
            if mat.use_nodes and mat.node_tree:
                bsdf = next((n for n in mat.node_tree.nodes
                              if n.type == "BSDF_PRINCIPLED"), None)
                if bsdf is not None:
                    _ms_set(bsdf, ("Base Color",), (1.0, 1.0, 1.0, 1.0))
        say("presentation white world", "set" if world_changed else "kept user HDRI")

    elif style_id == "dramatic_exterior":
        sun = next((obj for obj in scene.objects
                    if obj.type == "LIGHT" and obj.name.startswith("IngeTrazo sun")), None)
        if sun is not None:
            sun.data.angle = math.radians(0.32)
            sun.data.energy *= 1.08

    elif style_id in ("architectural_daylight", "overcast_soft", "custom"):
        # These styles are already defined by IngeTrazo's day/overcast setup
        # and the saved color-management controls. No model/material edits.
        pass

    else:
        say("unknown render style; keeping scene defaults", style_id)

    say("render style ready", style_id, "for", engine)


def apply_material_studio_look(scene, config):
    """Adjust Blender color management for the final render."""
    config = config if isinstance(config, dict) else {}
    view = getattr(scene, "view_settings", None)
    if view is None:
        say("material studio look: view settings unavailable")
        return
    try:
        view.exposure = float(config.get("exposure", 0.0))
    except Exception:
        pass
    try:
        view.gamma = float(config.get("gamma", 1.0))
    except Exception:
        pass
    look = str(config.get("render_look", "None") or "None")
    if look and look != "None":
        try:
            view.look = look
        except Exception as exc:
            say("material studio look unavailable", look, str(exc))
    say("material studio look", round(float(getattr(view, "exposure", 0.0)), 3),
        round(float(getattr(view, "gamma", 1.0)), 3),
        str(getattr(view, "look", "")))


def apply_camera_effects(scene, config, camera_config):
    """Set camera DOF for both Cycles and EEVEE render paths."""
    cam = scene.camera
    if cam is None:
        say("camera effects: no camera")
        return
    dof = cam.data.dof
    if not (config or {}).get("dof_enabled", False):
        dof.use_dof = False
        return

    dof.use_dof = True
    if (config or {}).get("focus_auto", True):
        eye = Vector(camera_config["eye"])
        target = Vector(camera_config["target"])
        distance = (target - eye).length
    else:
        distance = float(config.get("focus_distance", 5.0))
    dof.focus_distance = max(0.001, distance)
    dof.aperture_fstop = max(0.1, min(128.0, float(
        config.get("aperture_fstop", 5.6))))
    blades = int(config.get("aperture_blades", 6))
    if hasattr(dof, "aperture_blades"):
        dof.aperture_blades = max(0, min(16, blades))
    if hasattr(dof, "aperture_ratio"):
        dof.aperture_ratio = max(0.1, min(2.0, float(
            config.get("aperture_ratio", 1.0))))
    say("camera effects: DOF on, focus", round(dof.focus_distance, 3),
        "m, f/", dof.aperture_fstop)


def _ms_glare_socket(node, names):
    for name in names:
        try:
            socket = node.inputs.get(name)
        except Exception:
            socket = None
        if socket is not None:
            return socket
    wanted = {str(name).lower().replace("_", " ") for name in names}
    for socket in getattr(node, "inputs", ()):
        label = str(getattr(socket, "name", "")).lower().replace("_", " ")
        ident = str(getattr(socket, "identifier", "")).lower().replace("_", " ")
        if label in wanted or ident in wanted:
            return socket
    return None


def _ms_set_glare_socket(node, names, value):
    socket = _ms_glare_socket(node, names)
    if socket is None:
        return False
    try:
        socket.default_value = value
        return True
    except (TypeError, ValueError, AttributeError):
        return False


def _ms_configure_glare_node(glare, config):
    effect = str(config.get("effect", "BLOOM") or "BLOOM").upper()
    quality = str(config.get("quality", "HIGH") or "HIGH").upper()
    threshold = max(0.0, min(1000.0, float(config.get("threshold", 1.0))))
    strength = max(0.0, min(10.0, float(config.get("strength", 0.65))))
    size = max(0.05, min(3.0, float(config.get("size", 0.5))))
    saturation = max(0.0, min(1.0, float(config.get("saturation", 1.0))))
    smoothness = max(0.0, min(1.0, float(config.get("smoothness", 0.25))))
    streaks = max(1, min(16, int(config.get("streaks", 6))))
    clamp_highlights = bool(config.get("clamp", False))
    maximum = max(0.1, min(10000.0, float(config.get("maximum", 10.0))))

    available_types = set()
    try:
        prop = glare.bl_rna.properties.get("glare_type")
        if prop is not None:
            available_types = {item.identifier for item in prop.enum_items}
    except Exception:
        pass
    if available_types and effect not in available_types:
        if effect == "BLOOM" and "FOG_GLOW" in available_types:
            effect = "FOG_GLOW"
        else:
            effect = "FOG_GLOW" if "FOG_GLOW" in available_types else next(iter(available_types))
        say("material studio glow: requested type unavailable; using", effect)

    try:
        if hasattr(glare, "glare_type"):
            glare.glare_type = effect
    except Exception:
        pass
    _ms_set_glare_socket(glare, ("Type", "Glare Type"), effect)
    try:
        if hasattr(glare, "quality"):
            glare.quality = quality
    except Exception:
        pass
    _ms_set_glare_socket(glare, ("Quality",), quality)
    _ms_set_glare_socket(glare, ("Threshold",), threshold)
    _ms_set_glare_socket(glare, ("Smoothness",), smoothness)
    _ms_set_glare_socket(glare, ("Clamp",), clamp_highlights)
    _ms_set_glare_socket(glare, ("Maximum",), maximum)
    strength_socket_set = _ms_set_glare_socket(glare, ("Strength",), strength)
    _ms_set_glare_socket(glare, ("Saturation",), saturation)
    size_socket_set = _ms_set_glare_socket(glare, ("Size",), size)
    _ms_set_glare_socket(glare, ("Streaks",), streaks)
    try:
        if hasattr(glare, "threshold"):
            glare.threshold = threshold
        if not size_socket_set and hasattr(glare, "size"):
            glare.size = max(1, min(9, int(round(1.0 + 8.0 * min(1.0, size)))))
        if not strength_socket_set and hasattr(glare, "mix"):
            glare.mix = 1.0 - (2.0 * min(1.0, strength))
            if strength > 1.0:
                say("material studio glow: legacy Glare node caps intensity at 1.0")
        elif not strength_socket_set and strength > 1.0:
            say("material studio glow: Strength socket unavailable; intensity above 1.0 cannot be applied")
        if hasattr(glare, "streaks"):
            glare.streaks = streaks
    except Exception as exc:
        say("material studio glow controls partially unavailable", str(exc))
    return effect, quality, threshold, strength, size


def _ms_tag_glow_node(node, role):
    try:
        node["ingetrazo_material_studio_glow"] = True
        node["ingetrazo_material_studio_glow_role"] = str(role)
    except Exception:
        pass
    return node


def _ms_trace_previous_glow(socket):
    """Walk backwards through only our previous glow nodes to the user's source."""
    seen = set()
    while socket is not None:
        node = getattr(socket, "node", None)
        if node is None:
            break
        try:
            tagged = bool(node.get("ingetrazo_material_studio_glow", False))
            role = str(node.get("ingetrazo_material_studio_glow_role", ""))
        except Exception:
            tagged, role = False, ""
        if not tagged or id(node) in seen:
            break
        seen.add(id(node))
        preferred = ("A", "Color1", "Image") if role in ("add", "subtract") else ("Image",)
        upstream = None
        for name in preferred:
            input_socket = node.inputs.get(name)
            if input_socket is not None and input_socket.is_linked:
                upstream = input_socket.links[0].from_socket
                break
        if upstream is None:
            for input_socket in node.inputs:
                if input_socket.is_linked:
                    upstream = input_socket.links[0].from_socket
                    break
        if upstream is None:
            break
        socket = upstream
    return socket


def _ms_group_sockets(tree, direction):
    try:
        return [item for item in tree.interface.items_tree
                if getattr(item, "item_type", "") == "SOCKET"
                and getattr(item, "in_out", "") == direction]
    except Exception:
        return []


def _ms_ensure_compositor_group(tree):
    inputs = _ms_group_sockets(tree, "INPUT")
    outputs = _ms_group_sockets(tree, "OUTPUT")
    if not inputs:
        tree.interface.new_socket(name="Image", in_out="INPUT", socket_type="NodeSocketColor")
    if not outputs:
        tree.interface.new_socket(name="Image", in_out="OUTPUT", socket_type="NodeSocketColor")

    group_inputs = [node for node in tree.nodes if getattr(node, "type", "") == "GROUP_INPUT"]
    group_outputs = [node for node in tree.nodes if getattr(node, "type", "") == "GROUP_OUTPUT"]
    group_input = group_inputs[0] if group_inputs else tree.nodes.new("NodeGroupInput")
    group_output = next((node for node in group_outputs
                         if bool(getattr(node, "is_active_output", False))),
                        group_outputs[0] if group_outputs else None)
    if group_output is None:
        group_output = tree.nodes.new("NodeGroupOutput")
    try:
        group_output.is_active_output = True
    except Exception:
        pass
    try:
        group_input.update()
        group_output.update()
    except Exception:
        pass

    image_input = group_input.outputs.get("Image")
    if image_input is None:
        image_input = next((socket for socket in group_input.outputs
                            if getattr(socket, "type", "") in ("RGBA", "COLOR")), None)
    image_output = group_output.inputs.get("Image")
    if image_output is None:
        image_output = next((socket for socket in group_output.inputs
                             if getattr(socket, "type", "") in ("RGBA", "COLOR")), None)
    return group_input, group_output, image_input, image_output


def _ms_make_mix_node(nodes, links, a_socket, b_socket, operation, output_input):
    mix = nodes.new("ShaderNodeMix")
    mix.data_type = "RGBA"
    mix.blend_type = str(operation).upper()
    try:
        mix.clamp_result = False
    except Exception:
        pass
    factor = mix.inputs.get("Factor")
    socket_a = mix.inputs.get("A")
    socket_b = mix.inputs.get("B")
    result = mix.outputs.get("Result")
    if factor is None or socket_a is None or socket_b is None or result is None:
        nodes.remove(mix)
        raise RuntimeError("Blender 5.x Mix node RGBA sockets are unavailable")
    factor.default_value = 1.0
    links.new(a_socket, socket_a)
    links.new(b_socket, socket_b)
    links.new(result, output_input)
    _ms_tag_glow_node(mix, "add" if str(operation).upper() == "ADD" else "subtract")
    mix.label = "Material Studio · Glow Composite"
    return mix


def _ms_apply_glow_modern(scene, config):
    """Blender 5.x compositor pipeline using scene.compositing_node_group."""
    original_tree = getattr(scene, "compositing_node_group", None)
    if original_tree is None:
        tree = bpy.data.node_groups.new(
            "IngeTrazo Material Studio Compositor", "CompositorNodeTree"
        )
        is_new_tree = True
    else:
        try:
            if (bool(original_tree.get("ingetrazo_material_studio_glow_tree", False))
                    and int(getattr(original_tree, "users", 1)) <= 1):
                tree = original_tree
            else:
                tree = original_tree.copy()
            is_new_tree = tree is not original_tree
        except Exception:
            tree = original_tree
            is_new_tree = False

    group_input, group_output, input_image, output_image = _ms_ensure_compositor_group(tree)
    if input_image is None or output_image is None:
        say("material studio glow unavailable: compositor group Image socket missing")
        return

    output_link = next(iter(output_image.links), None)
    if output_link is not None:
        source_socket = _ms_trace_previous_glow(output_link.from_socket)
    else:
        source_socket = input_image
    if source_socket is None:
        say("material studio glow unavailable: compositor source image missing")
        return

    source_mode = str(config.get("source", "all_highlights") or "all_highlights").lower()
    aov_name = None
    aov_socket = None
    render_layers = None
    if source_mode == "emission_only":
        try:
            aov_name = str(scene.get("ingetrazo_ms_emission_aov_name", "") or "")
        except Exception:
            aov_name = ""
        if not aov_name:
            say("material studio emission-only glow skipped: no eligible Material Studio emission")
            return
        render_layers = tree.nodes.new("CompositorNodeRLayers")
        try:
            render_layers.scene = scene
            if scene.view_layers:
                render_layers.layer = scene.view_layers[0].name
                try:
                    scene.view_layers[0].update_render_passes()
                except Exception:
                    pass
        except Exception as exc:
            say("material studio Render Layers setup warning", str(exc))
        try:
            render_layers.update()
        except Exception:
            pass
        aov_socket = render_layers.outputs.get(aov_name)
        if aov_socket is None:
            available = [str(socket.name) for socket in render_layers.outputs]
            tree.nodes.remove(render_layers)
            say("material studio emission AOV output unavailable", aov_name, available)
            return

    # The working node group is copied before edits when it belonged to the user.
    # Remove only the previous Material Studio nodes after preserving their input.
    for old_node in list(tree.nodes):
        try:
            if bool(old_node.get("ingetrazo_material_studio_glow", False)):
                tree.nodes.remove(old_node)
        except Exception:
            pass

    glare = tree.nodes.new("CompositorNodeGlare")
    glare.name = "Material Studio · Glow & Bloom"
    glare.label = "Material Studio · Glow & Bloom"
    _ms_tag_glow_node(glare, "glare")
    effect, quality, threshold, strength, size = _ms_configure_glare_node(glare, config)
    glare_input = _ms_glare_socket(glare, ("Image",))
    if glare_input is None:
        say("material studio glow unavailable: Glare Image input missing")
        return

    if source_mode == "emission_only":
        tree.links.new(aov_socket, glare_input)
        isolated_glare = glare.outputs.get("Glare")
        if isolated_glare is None:
            tree.nodes.remove(glare)
            say("material studio emission-only glow unavailable: isolated Glare output missing")
            return
        _ms_make_mix_node(tree.nodes, tree.links, source_socket,
                          isolated_glare, "ADD", output_image)
        _ms_tag_glow_node(render_layers, "aov_render_layers")
    else:
        tree.links.new(source_socket, glare_input)
        image_output = glare.outputs.get("Image")
        if image_output is None:
            say("material studio glow unavailable: Glare Image output missing")
            return
        tree.links.new(image_output, output_image)

    try:
        tree["ingetrazo_material_studio_glow_tree"] = True
        if is_new_tree:
            scene.compositing_node_group = tree
        elif original_tree is not tree:
            scene.compositing_node_group = tree
    except Exception as exc:
        say("material studio compositor group assignment warning", str(exc))
        if original_tree is None:
            raise
    try:
        if hasattr(scene.render, "use_compositing"):
            scene.render.use_compositing = True
    except Exception:
        pass
    say("material studio glow ready · Blender 5.x", effect, "quality", quality,
        "source", source_mode, "threshold", round(threshold, 3),
        "strength", round(strength, 3), "size", round(size, 3))


def apply_material_studio_glow(scene, config):
    """Add a non-destructive glow stage for Blender 4.x and 5.x.

    Blender 5.0+ uses a compositor node group and Group Input/Output nodes;
    Blender 4.x keeps the legacy scene.node_tree / Composite node path.
    Emission-only mode reads a dedicated Shader AOV, so unrelated bright
    materials and reflections are not used as glow sources.
    """
    config = config if isinstance(config, dict) else {}
    if not bool(config.get("enabled", False)):
        say("material studio glow disabled; compositor left untouched")
        return

    try:
        if hasattr(scene, "compositing_node_group"):
            _ms_apply_glow_modern(scene, config)
            return

        # Legacy Blender 4.x compositor path.
        scene.use_nodes = True
        tree = getattr(scene, "node_tree", None)
        if tree is None:
            say("material studio glow unavailable: compositor node tree missing")
            return
        nodes, links = tree.nodes, tree.links
        composite = next((node for node in nodes
                          if getattr(node, "type", "") == "COMPOSITE"), None)
        if composite is None:
            composite = nodes.new("CompositorNodeComposite")
        composite_input = composite.inputs.get("Image")
        if composite_input is None:
            say("material studio glow unavailable: Composite Image input missing")
            return

        old_output_link = next(iter(composite_input.links), None)
        if old_output_link is not None:
            source_socket = _ms_trace_previous_glow(old_output_link.from_socket)
            links.remove(old_output_link)
        else:
            render_layers = next((node for node in nodes
                                  if getattr(node, "type", "") == "R_LAYERS"), None)
            if render_layers is None:
                render_layers = nodes.new("CompositorNodeRLayers")
            source_socket = render_layers.outputs.get("Image")

        if source_socket is None:
            say("material studio glow unavailable: no source image socket")
            return

        source_mode = str(config.get("source", "all_highlights") or "all_highlights").lower()
        aov_socket = None
        aov_name = ""
        if source_mode == "emission_only":
            try:
                aov_name = str(scene.get("ingetrazo_ms_emission_aov_name", "") or "")
            except Exception:
                aov_name = ""
            if not aov_name:
                say("material studio emission-only glow skipped: no eligible Material Studio emission")
                links.new(source_socket, composite_input)
                return
            render_layers = nodes.new("CompositorNodeRLayers")
            try:
                render_layers.scene = scene
                if scene.view_layers:
                    render_layers.layer = scene.view_layers[0].name
                    scene.view_layers[0].update_render_passes()
            except Exception:
                pass
            try:
                render_layers.update()
            except Exception:
                pass
            aov_socket = render_layers.outputs.get(aov_name)
            if aov_socket is None:
                nodes.remove(render_layers)
                links.new(source_socket, composite_input)
                say("material studio emission AOV output unavailable", aov_name)
                return

        for old_node in list(nodes):
            try:
                if bool(old_node.get("ingetrazo_material_studio_glow", False)):
                    nodes.remove(old_node)
            except Exception:
                pass

        glare = nodes.new("CompositorNodeGlare")
        glare.name = "Material Studio · Glow & Bloom"
        glare.label = "Material Studio · Glow & Bloom"
        _ms_tag_glow_node(glare, "glare")
        effect, quality, threshold, strength, size = _ms_configure_glare_node(glare, config)
        glare_input = _ms_glare_socket(glare, ("Image",))
        if glare_input is None:
            links.new(source_socket, composite_input)
            say("material studio glow unavailable: Glare Image input missing")
            return

        if source_mode == "emission_only":
            links.new(aov_socket, glare_input)
            isolated_glare = glare.outputs.get("Glare")
            if isolated_glare is not None:
                mix = nodes.new("CompositorNodeMixRGB")
                mix.blend_type = "ADD"
                mix.use_clamp = False
                mix.inputs[0].default_value = 1.0
                links.new(source_socket, mix.inputs[1])
                links.new(isolated_glare, mix.inputs[2])
                links.new(mix.outputs.get("Image"), composite_input)
                _ms_tag_glow_node(mix, "add")
            else:
                processed = glare.outputs.get("Image")
                if processed is None:
                    links.new(source_socket, composite_input)
                    return
                subtract = nodes.new("CompositorNodeMixRGB")
                subtract.blend_type = "SUBTRACT"
                subtract.use_clamp = False
                subtract.inputs[0].default_value = 1.0
                links.new(processed, subtract.inputs[1])
                links.new(aov_socket, subtract.inputs[2])
                add = nodes.new("CompositorNodeMixRGB")
                add.blend_type = "ADD"
                add.use_clamp = False
                add.inputs[0].default_value = 1.0
                links.new(source_socket, add.inputs[1])
                links.new(subtract.outputs.get("Image"), add.inputs[2])
                links.new(add.outputs.get("Image"), composite_input)
                _ms_tag_glow_node(subtract, "subtract")
                _ms_tag_glow_node(add, "add")
            _ms_tag_glow_node(render_layers, "aov_render_layers")
        else:
            links.new(source_socket, glare_input)
            image_output = glare.outputs.get("Image")
            if image_output is None:
                links.new(source_socket, composite_input)
                say("material studio glow unavailable: Glare Image output missing")
                return
            links.new(image_output, composite_input)

        try:
            if hasattr(scene.render, "use_compositing"):
                scene.render.use_compositing = True
        except Exception:
            pass
        say("material studio glow ready · legacy compositor", effect,
            "quality", quality, "source", source_mode,
            "threshold", round(threshold, 3), "strength", round(strength, 3),
            "size", round(size, 3))
    except Exception as exc:
        say("material studio glow setup error", str(exc))

'''


class MaterialStudioPanel(QWidget):
    def __init__(self, app):
        super().__init__()
        self.app = app
        self._proc = None
        self._work = None
        self._output = None
        self._log = []
        self._buffer = ""
        self._map_edits = {}
        self._tint = (1.0, 1.0, 1.0)
        self._emission_color = (1.0, 1.0, 1.0)
        # Do not override an imported material's existing emission until the
        # user explicitly edits the Emission controls.
        self._emission_touched = False
        self._active_emission_preset = "custom"
        self._applying_emission_preset = False
        self._active_render_preset = "architectural_daylight"
        self._applying_render_preset = False
        self._applying_glow_level = False
        self._lights = []
        self._loading_light = False
        self._light_clipboard = None
        self._view_pick = None
        self._light_pick_action = None
        self._light_preview = None
        self._viewport_helpers_available = False

        outer = QVBoxLayout(self)
        outer.setContentsMargins(5, 5, 5, 5)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll)

        body = QWidget()
        body.setMinimumWidth(0)
        scroll.setWidget(body)
        layout = QVBoxLayout(body)
        layout.setContentsMargins(7, 7, 7, 8)
        layout.setSpacing(8)

        heading = QLabel("MATERIAL STUDIO")
        heading.setStyleSheet("font-weight: 700; font-size: 14px;")
        layout.addWidget(heading)
        intro = QLabel(
            "Editor PBR, procedural surface relief, kamera, render style, Lighting Properties, "
            "dan local emission glow Blender. Pengaturan lanjutan disimpan bersama dokumen proyek."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        select_box = QGroupBox("Material")
        select_row = QHBoxLayout(select_box)
        self.material_combo = QComboBox()
        self.material_combo.currentIndexChanged.connect(self._load_material)
        select_row.addWidget(self.material_combo, 1)
        refresh = QPushButton("Refresh")
        refresh.clicked.connect(self.refresh)
        select_row.addWidget(refresh)
        layout.addWidget(select_box)

        self.tabs = QTabWidget()
        layout.addWidget(self.tabs, 1)

        self._build_surface_tab()
        self._build_maps_tab()
        self._build_camera_tab()
        self._build_lighting_tab()
        self.refresh()

    @staticmethod
    def _spin(minimum, maximum, step, decimals, default, suffix=""):
        w = QDoubleSpinBox()
        w.setRange(minimum, maximum)
        w.setSingleStep(step)
        w.setDecimals(decimals)
        w.setValue(default)
        if suffix:
            w.setSuffix(suffix)
        return w

    @staticmethod
    def _int_spin(minimum, maximum, step, default, suffix=""):
        w = QSpinBox()
        w.setRange(minimum, maximum)
        w.setSingleStep(step)
        w.setValue(default)
        if suffix:
            w.setSuffix(suffix)
        return w

    def _build_surface_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        preset_box = QGroupBox("Material Preset")
        preset_form = QFormLayout(preset_box)
        self.preset_combo = QComboBox()
        self.preset_combo.addItem("Custom", "")
        for key, spec in MATERIAL_PRESETS.items():
            self.preset_combo.addItem(spec["label"], key)
        preset_form.addRow("Quick preset:", self.preset_combo)
        apply_preset = QPushButton("Load preset values")
        apply_preset.clicked.connect(self._apply_preset)
        preset_form.addRow(apply_preset)
        layout.addWidget(preset_box)

        surface = QGroupBox("Surface · Principled BSDF")
        form = QFormLayout(surface)
        self.finish_combo = QComboBox()
        self.finish_combo.addItem("Automatic", "auto")
        for key, label in (
            ("matte", "Matte"), ("satin", "Satin"), ("gloss", "Gloss"),
            ("metal", "Metal"), ("glass", "Glass"), ("water", "Water")
        ):
            self.finish_combo.addItem(label, key)
        form.addRow("Finish:", self.finish_combo)

        self.roughness = self._spin(0, 1, 0.02, 3, 0.7)
        form.addRow("Roughness:", self.roughness)
        self.metallic = self._spin(0, 1, 0.02, 3, 0.0)
        form.addRow("Metallic:", self.metallic)
        self.ior = self._spin(1, 3, 0.01, 3, 1.45)
        form.addRow("IOR:", self.ior)
        self.transmission = self._spin(0, 1, 0.02, 3, 0.0)
        form.addRow("Transmission:", self.transmission)
        self.coat = self._spin(0, 1, 0.02, 3, 0.0)
        form.addRow("Coat:", self.coat)
        self.coat_roughness = self._spin(0, 1, 0.02, 3, 0.1)
        form.addRow("Coat roughness:", self.coat_roughness)
        self.specular = self._spin(0, 1, 0.02, 3, 0.5)
        form.addRow("Specular:", self.specular)
        self.anisotropy = self._spin(0, 1, 0.02, 3, 0.0)
        self.anisotropy.setToolTip(
            "Membantu membuat pantulan terarah pada brushed metal."
        )
        form.addRow("Anisotropy:", self.anisotropy)

        tint_box = QGroupBox("Base Color Tint · optional")
        tint_row = QHBoxLayout(tint_box)
        self.use_tint = QCheckBox("Tint base color / texture")
        tint_row.addWidget(self.use_tint, 1)
        self.tint_button = QPushButton("Choose color…")
        self.tint_button.clicked.connect(self._choose_tint)
        tint_row.addWidget(self.tint_button)
        layout.addWidget(surface)
        layout.addWidget(tint_box)

        emission_box = QGroupBox("Emission · Self-Illumination")
        emission_form = QFormLayout(emission_box)
        self.emission_enabled = QCheckBox("Enable Emission")
        self.emission_enabled.setToolTip(
            "Aktifkan material sebagai permukaan yang memancarkan cahaya. "
            "Efek menerangi objek sekitar bergantung pada engine dan pengaturan GI."
        )
        emission_form.addRow(self.emission_enabled)
        self.emission_glow_enabled = QCheckBox("Include this material in Glow / Bloom")
        self.emission_glow_enabled.setChecked(True)
        self.emission_glow_enabled.setToolTip(
            "Jika Glow Source diatur ke Material Studio Emission only, "
            "material ini ikut menjadi sumber Bloom. Matikan untuk mengecualikannya."
        )
        self.emission_glow_enabled.toggled.connect(self._mark_emission_touched)
        self.emission_glow_enabled.toggled.connect(self._mark_emission_preset_custom)
        self.emission_enabled.toggled.connect(
            lambda checked: self.emission_glow_enabled.setEnabled(bool(checked))
        )
        self.emission_enabled.toggled.connect(self._mark_emission_preset_custom)
        emission_form.addRow(self.emission_glow_enabled)

        self.emission_preset_combo = QComboBox()
        self.emission_preset_combo.addItem("Custom / Manual", "custom")
        for key, spec in EMISSION_PRESETS.items():
            self.emission_preset_combo.addItem(spec["label"], key)
        emission_form.addRow("Emission preset:", self.emission_preset_combo)
        self.apply_emission_preset_button = QPushButton("Apply Emission Preset")
        self.apply_emission_preset_button.setToolTip(
            "Mengatur warna dan kekuatan Emission pada material terpilih saja. "
            "Base Color dan pengaturan PBR tidak diubah."
        )
        self.apply_emission_preset_button.clicked.connect(self.apply_emission_preset)
        emission_form.addRow(self.apply_emission_preset_button)
        self.emission_preview_label = QLabel("Custom / Manual · Strength 1.00")
        self.emission_preview_label.setWordWrap(True)
        emission_form.addRow("Emission preview:", self.emission_preview_label)
        self.emission_preset_combo.currentIndexChanged.connect(
            self._emission_preset_selection_changed
        )

        self.emission_color_button = QPushButton("Choose emission color…")
        self.emission_color_button.clicked.connect(self._choose_emission_color)
        emission_form.addRow("Emission color:", self.emission_color_button)
        self.emission_strength = self._spin(0, 10000, 0.1, 3, 1.0)
        self.emission_strength.setToolTip(
            "Intensitas Emission Strength pada Principled BSDF Blender. "
            "Nilai tinggi dapat membuat permukaan sangat terang."
        )
        emission_form.addRow("Emission strength:", self.emission_strength)
        self._add_map_row(emission_form, "Emission Texture", "emission_map")
        self.emission_enabled.toggled.connect(self._mark_emission_touched)
        self.emission_strength.valueChanged.connect(self._mark_emission_touched)
        self.emission_strength.valueChanged.connect(self._mark_emission_preset_custom)
        self._map_edits["emission_map"].textChanged.connect(
            self._on_emission_map_changed
        )
        emission_note = QLabel(
            "Cycles dapat menghitung kontribusi cahaya dari permukaan emissive. "
            "Pada EEVEE, efek menerangi objek lain bergantung pada dukungan "
            "global illumination. Glow/Bloom merupakan efek compositor terpisah; "
            "centang Include this material in Glow / Bloom untuk memasukkan "
            "material ini ke sumber glow lokal."
        )
        emission_note.setWordWrap(True)
        emission_form.addRow(emission_note)
        layout.addWidget(emission_box)

        self.apply_surface_button = QPushButton("Apply Material")
        self.apply_surface_button.setToolTip(
            "Simpan pengaturan PBR material terpilih untuk render Blender "
            "Material Studio. Tidak mengubah preview viewport IngeTrazo."
        )
        self.apply_surface_button.clicked.connect(self.apply_material_settings)
        layout.addWidget(self.apply_surface_button)
        self.surface_status = QLabel(
            "Apply Material menyimpan pengaturan untuk render Blender."
        )
        self.surface_status.setWordWrap(True)
        layout.addWidget(self.surface_status)

        layout.addStretch(1)
        self.tabs.addTab(tab, "Surface")

    def _build_maps_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        maps = QGroupBox("PBR Texture Maps")
        form = QFormLayout(maps)
        self.mapping = QComboBox()
        self.mapping.addItem("UV coordinates", "UV")
        self.mapping.addItem("Generated coordinates", "Generated")
        self.mapping.addItem("Object coordinates", "Object")
        form.addRow("Mapping:", self.mapping)
        self._add_map_row(form, "Normal Map", "normal_map")
        self._add_map_row(form, "Height Map", "height_map")
        self._add_map_row(form, "Roughness Map", "roughness_map")
        self._add_map_row(form, "Metallic Map", "metallic_map")
        layout.addWidget(maps)

        transform = QGroupBox("Texture Transform")
        tform = QFormLayout(transform)
        self.map_scale_u = self._spin(0.01, 1000, 0.05, 2, 1.0)
        tform.addRow("Scale U:", self.map_scale_u)
        self.map_scale_v = self._spin(0.01, 1000, 0.05, 2, 1.0)
        tform.addRow("Scale V:", self.map_scale_v)
        self.map_offset_u = self._spin(-1000, 1000, 0.01, 3, 0.0)
        tform.addRow("Offset U:", self.map_offset_u)
        self.map_offset_v = self._spin(-1000, 1000, 0.01, 3, 0.0)
        tform.addRow("Offset V:", self.map_offset_v)
        self.map_rotation = self._spin(-360, 360, 1, 1, 0.0, "°")
        tform.addRow("Rotation:", self.map_rotation)
        transform_note = QLabel(
            "Mengatur Scale / Offset / Rotation untuk Base Color texture "
            "dan map PBR tambahan (roughness / normal / height / metallic) "
            "pada jalur render Blender Material Studio."
        )
        transform_note.setWordWrap(True)
        tform.addRow(transform_note)
        layout.addWidget(transform)

        relief = QGroupBox("Surface Relief")
        relief_form = QFormLayout(relief)
        self.use_base_bump = QCheckBox(
            "Use existing Base Color texture as Height"
        )
        self.use_base_bump.setToolTip(
            "Cara cepat untuk memberi relief pada tekstur bata/batu yang "
            "sudah terpasang. Hasil terbaik memakai Height Map khusus."
        )
        relief_form.addRow(self.use_base_bump)
        self.normal_strength = self._spin(0, 2, 0.05, 2, 1.0)
        relief_form.addRow("Normal strength:", self.normal_strength)
        self.bump_strength = self._spin(0, 2, 0.05, 2, 0.25)
        relief_form.addRow("Bump strength:", self.bump_strength)
        self.bump_distance = self._spin(
            0, 0.2, 0.001, 4, 0.008, " m"
        )
        relief_form.addRow("Bump distance:", self.bump_distance)
        self.height_contrast = self._spin(0, 1, 0.05, 2, 0.65)
        relief_form.addRow("Height contrast:", self.height_contrast)
        self.invert_height = QCheckBox(
            "Invert height (mortar recessed / brick raised)"
        )
        relief_form.addRow(self.invert_height)
        self.micro_bump_enabled = QCheckBox("Add fine surface grain")
        relief_form.addRow(self.micro_bump_enabled)
        self.micro_bump_strength = self._spin(0, 1, 0.02, 3, 0.08)
        relief_form.addRow("Fine grain strength:", self.micro_bump_strength)
        self.micro_bump_scale = self._spin(1, 500, 5, 1, 100.0)
        relief_form.addRow("Fine grain scale:", self.micro_bump_scale)
        layout.addWidget(relief)

        procedural = QGroupBox("Procedural Surface Relief · no image map required")
        procedural_form = QFormLayout(procedural)
        self.procedural_relief_enabled = QCheckBox(
            "Enable procedural surface pattern"
        )
        self.procedural_relief_enabled.setToolTip(
            "Membuat pola tinggi prosedural untuk material warna polos atau "
            "material yang belum memiliki Height Map. Base Color tidak diubah."
        )
        procedural_form.addRow(self.procedural_relief_enabled)
        self.procedural_relief_type = QComboBox()
        for label, key in (
            ("Brick / Mortar", "brick"),
            ("Stone / Cellular", "stone"),
            ("Concrete / Plaster", "concrete"),
            ("Wood Grain", "wood"),
            ("Fabric Weave", "fabric"),
            ("Fine Noise", "noise"),
        ):
            self.procedural_relief_type.addItem(label, key)
        procedural_form.addRow("Pattern:", self.procedural_relief_type)
        self.procedural_relief_scale = self._spin(0.1, 100.0, 0.5, 2, 8.0)
        procedural_form.addRow("Pattern scale:", self.procedural_relief_scale)
        self.procedural_relief_strength = self._spin(0, 1, 0.02, 3, 0.22)
        procedural_form.addRow("Relief strength:", self.procedural_relief_strength)
        self.procedural_relief_distance = self._spin(
            0, 0.05, 0.0005, 4, 0.003, " m"
        )
        procedural_form.addRow("Relief depth:", self.procedural_relief_distance)
        self.procedural_relief_detail = self._spin(0, 10, 0.5, 1, 4.0)
        procedural_form.addRow("Pattern detail:", self.procedural_relief_detail)
        self.procedural_relief_contrast = self._spin(0, 1, 0.05, 2, 0.65)
        procedural_form.addRow("Pattern contrast:", self.procedural_relief_contrast)
        self.procedural_relief_invert = QCheckBox(
            "Invert procedural pattern"
        )
        self.procedural_relief_invert.setToolTip(
            "Membalik area tinggi dan rendah. Untuk pola bata, gunakan untuk "
            "menguji apakah nat menjadi cekung dan bata menjadi menonjol."
        )
        procedural_form.addRow(self.procedural_relief_invert)
        procedural_note = QLabel(
            "Procedural Relief menambahkan bump pada shading tanpa mengubah "
            "Base Color. Pola Brick, Stone, Concrete, Wood, dan Fabric dapat "
            "dipakai tanpa file Height Map. Untuk perubahan siluet, aktifkan "
            "Adaptive Displacement di Cycles dan gunakan mesh yang cukup rapat."
        )
        procedural_note.setWordWrap(True)
        procedural_form.addRow(procedural_note)
        layout.addWidget(procedural)

        displacement = QGroupBox("Geometric Displacement · Cycles")
        disp_form = QFormLayout(displacement)
        self.use_displacement = QCheckBox(
            "Enable adaptive displacement (experimental)"
        )
        disp_form.addRow(self.use_displacement)
        self.displacement_scale = self._spin(
            0, 0.1, 0.001, 4, 0.005, " m"
        )
        disp_form.addRow("Displacement scale:", self.displacement_scale)
        self.displacement_midlevel = self._spin(0, 1, 0.05, 2, 0.5)
        disp_form.addRow("Midlevel:", self.displacement_midlevel)
        layout.addWidget(displacement)
        note = QLabel(
            "Bump/Normal mengubah shading, bukan siluet. Adaptive Displacement "
            "mencoba mengubah geometri pada Cycles dan memerlukan dukungan "
            "adaptive subdivision dari versi Blender."
        )
        note.setWordWrap(True)
        layout.addWidget(note)

        self.apply_maps_button = QPushButton("Apply PBR Maps & Relief")
        self.apply_maps_button.setToolTip(
            "Simpan seluruh pengaturan Surface, Maps, dan Relief material "
            "terpilih untuk render Blender Material Studio."
        )
        self.apply_maps_button.clicked.connect(self.apply_material_settings)
        layout.addWidget(self.apply_maps_button)
        self.maps_status = QLabel(
            "Perubahan map dan relief belum disimpan."
        )
        self.maps_status.setWordWrap(True)
        layout.addWidget(self.maps_status)

        layout.addStretch(1)
        self.tabs.addTab(tab, "Maps & Relief")

    def _build_camera_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        camera = QGroupBox("Camera Effects")
        form = QFormLayout(camera)
        self.dof_enabled = QCheckBox("Enable Depth of Field (DOF)")
        form.addRow(self.dof_enabled)
        self.focus_auto = QCheckBox("Focus on camera target automatically")
        self.focus_auto.setChecked(True)
        form.addRow(self.focus_auto)
        self.focus_distance = self._spin(0.01, 100000, 0.1, 2, 5.0, " m")
        self.focus_distance.setEnabled(False)
        form.addRow("Manual focus distance:", self.focus_distance)
        self.aperture_fstop = self._spin(0.1, 128, 0.1, 1, 5.6)
        form.addRow("Aperture / F-Stop:", self.aperture_fstop)
        self.aperture_blades = self._int_spin(0, 16, 1, 6)
        form.addRow("Bokeh blades:", self.aperture_blades)
        self.aperture_ratio = self._spin(0.1, 2, 0.05, 2, 1.0)
        form.addRow("Bokeh ratio:", self.aperture_ratio)
        self.focus_auto.toggled.connect(
            lambda checked: self.focus_distance.setEnabled(not checked)
        )
        layout.addWidget(camera)

        style_box = QGroupBox("Render Style Presets")
        style_form = QFormLayout(style_box)
        self.render_preset_combo = QComboBox()
        for key, spec in RENDER_STYLE_PRESETS.items():
            self.render_preset_combo.addItem(spec["label"], key)
        self.render_preset_combo.addItem("Custom / Manual", "custom")
        self.render_preset_combo.setCurrentIndex(0)
        style_form.addRow("Render style:", self.render_preset_combo)
        self.apply_render_preset_button = QPushButton("Apply Render Preset")
        self.apply_render_preset_button.setToolTip(
            "Menerapkan ambience, karakter pencahayaan dan color management. "
            "Tidak mengubah material, engine, resolusi, kualitas, kamera, "
            "ground atau file HDRI yang dipilih."
        )
        self.apply_render_preset_button.clicked.connect(self.apply_render_preset)
        style_form.addRow(self.apply_render_preset_button)
        style_note = QLabel(
            "Architectural Daylight menjadi preset awal. Preset dapat dipakai "
            "pada Cycles maupun EEVEE. Pengaturan manual dan seluruh material "
            "asli tetap dipertahankan; ubah kontrol render setelah preset "
            "diterapkan untuk beralih ke Custom / Manual."
        )
        style_note.setWordWrap(True)
        style_form.addRow(style_note)
        self.render_preset_combo.currentIndexChanged.connect(
            self._render_preset_selection_changed
        )
        layout.addWidget(style_box)

        render = QGroupBox("Render Settings")
        rform = QFormLayout(render)
        self.engine = QComboBox()
        self.engine.addItem("EEVEE · Fast", "eevee")
        self.engine.addItem("Cycles · Quality", "cycles")
        self.engine.setCurrentIndex(1)
        rform.addRow("Engine:", self.engine)
        self.quality = QComboBox()
        self.quality.addItems(["Draft", "Medium", "High"])
        self.quality.setCurrentIndex(1)
        rform.addRow("Quality:", self.quality)
        self.width = self._int_spin(320, 7680, 160, 1600, " px")
        rform.addRow("Image width:", self.width)
        self.height = self._int_spin(180, 4320, 90, 900, " px")
        rform.addRow("Image height:", self.height)
        self.ambience = QComboBox()
        self.ambience.addItem("Day", "day")
        self.ambience.addItem("Overcast", "overcast")
        self.ambience.addItem("Night", "night")
        rform.addRow("Ambience:", self.ambience)
        self.ground = QCheckBox("Ground plane to catch shadows")
        self.ground.setChecked(True)
        rform.addRow(self.ground)
        self.keep_blend = QCheckBox("Also save editable .blend file")
        rform.addRow(self.keep_blend)

        reflections = QGroupBox("Studio Reflections · Metal / Gloss")
        reflection_form = QFormLayout(reflections)
        self.studio_reflections = QCheckBox(
            "Add large softbox lights for visible reflections"
        )
        self.studio_reflections.setChecked(True)
        reflection_form.addRow(self.studio_reflections)
        self.studio_strength = self._spin(0, 4, 0.05, 2, 0.25)
        self.studio_strength.setToolTip(
            "Kekuatan softbox yang muncul sebagai highlight/refleksi pada "
            "metal dan material glossy. Coba 0.35–0.8 untuk refleksi lebih "
            "terlihat; turunkan jika area terang menjadi overexposed."
        )
        reflection_form.addRow("Metal / glossy highlight strength:", self.studio_strength)
        hdri_row = QHBoxLayout()
        self.hdri_path = QLineEdit()
        self.hdri_path.setPlaceholderText("Optional HDRI (.hdr / .exr)")
        hdri_browse = QPushButton("…")
        hdri_browse.setMaximumWidth(34)
        hdri_clear = QPushButton("×")
        hdri_clear.setMaximumWidth(28)
        hdri_browse.clicked.connect(self._browse_hdri)
        hdri_clear.clicked.connect(self.hdri_path.clear)
        hdri_row.addWidget(self.hdri_path, 1)
        hdri_row.addWidget(hdri_browse)
        hdri_row.addWidget(hdri_clear)
        reflection_form.addRow("Environment HDRI:", hdri_row)
        self.hdri_strength = self._spin(0, 10, 0.1, 2, 0.8)
        reflection_form.addRow("HDRI strength:", self.hdri_strength)
        reflection_note = QLabel(
            "Softbox hanya ditambahkan jika scene memiliki material glossy, "
            "kaca, atau metal. Untuk refleksi metal yang lebih tegas, coba "
            "strength 0.35–0.8. HDRI opsional memberi detail lingkungan yang "
            "lebih realistis; hasil refleksi tetap bergantung pada lingkungan "
            "dan bentuk objek."
        )
        reflection_note.setWordWrap(True)
        reflection_form.addRow(reflection_note)
        rform.addRow(reflections)

        tone = QGroupBox("Color Management · Exposure & Contrast")
        tone_form = QFormLayout(tone)
        self.exposure = self._spin(-8, 8, 0.1, 2, -0.3, " EV")
        tone_form.addRow("Exposure:", self.exposure)
        self.gamma = self._spin(0.2, 5.0, 0.05, 2, 1.0)
        tone_form.addRow("Gamma:", self.gamma)
        self.render_look = QComboBox()
        self.render_look.addItem("No extra contrast", "None")
        self.render_look.addItem("Medium contrast", "Medium Contrast")
        self.render_look.addItem("Medium high contrast", "Medium High Contrast")
        self.render_look.addItem("High contrast", "High Contrast")
        self.render_look.addItem("Very high contrast", "Very High Contrast")
        self._set_combo(self.render_look, "Medium High Contrast")
        tone_form.addRow("Contrast look:", self.render_look)
        self.ambience.currentIndexChanged.connect(self._mark_render_preset_custom)
        self.studio_reflections.toggled.connect(self._mark_render_preset_custom)
        self.studio_strength.valueChanged.connect(self._mark_render_preset_custom)
        self.exposure.valueChanged.connect(self._mark_render_preset_custom)
        self.gamma.valueChanged.connect(self._mark_render_preset_custom)
        self.render_look.currentIndexChanged.connect(self._mark_render_preset_custom)
        tone_note = QLabel(
            "Mengontrol tampilan akhir render Blender tanpa mengubah material. "
            "Exposure berguna untuk scene terlalu gelap/terang, sedangkan "
            "Contrast Look membantu membuat render lebih punchy."
        )
        tone_note.setWordWrap(True)
        tone_form.addRow(tone_note)
        rform.addRow(tone)

        glow_box = QGroupBox("Glow & Bloom · Compositor")
        glow_form = QFormLayout(glow_box)
        self.glow_preset_combo = QComboBox()
        self.glow_preset_combo.addItem("Custom / Manual", "custom")
        for key, spec in GLOW_PRESETS.items():
            self.glow_preset_combo.addItem(spec["label"], key)
        glow_form.addRow("Glow preset:", self.glow_preset_combo)
        glow_preset_actions = QWidget()
        glow_preset_actions_layout = QHBoxLayout(glow_preset_actions)
        glow_preset_actions_layout.setContentsMargins(0, 0, 0, 0)
        self.apply_glow_preset_button = QPushButton("Apply Glow Preset")
        self.apply_glow_preset_button.setToolTip(
            "Menerapkan nilai awal Bloom. Semua parameter tetap dapat diubah manual."
        )
        self.apply_glow_preset_button.clicked.connect(self.apply_glow_preset)
        glow_preset_actions_layout.addWidget(self.apply_glow_preset_button, 1)
        self.reset_glow_button = QPushButton("Reset Glow")
        self.reset_glow_button.setToolTip(
            "Mengembalikan pengaturan compositor ke kondisi aman dan mematikan Glow. "
            "Tidak mengubah Emission pada material."
        )
        self.reset_glow_button.clicked.connect(self.reset_glow_settings)
        glow_preset_actions_layout.addWidget(self.reset_glow_button)
        glow_form.addRow(glow_preset_actions)

        self.glow_enabled = QCheckBox("Enable Glow / Bloom")
        self.glow_enabled.setChecked(False)
        self.glow_enabled.setToolTip(
            "Menambahkan efek pasca-render pada highlight terang. Efek dapat "
            "mengenai material emissive, lampu, dan pantulan terang lain "
            "sesuai nilai Threshold."
        )
        glow_form.addRow(self.glow_enabled)

        self.glow_effect = QComboBox()
        self.glow_effect.addItem("Bloom · soft halo", "BLOOM")
        self.glow_effect.addItem("Fog Glow · soft realistic glow", "FOG_GLOW")
        self.glow_effect.addItem("Streaks · lens flare", "STREAKS")
        self.glow_effect.addItem("Ghosts · lens artifacts", "GHOSTS")
        self.glow_effect.addItem("Simple Star · starburst", "SIMPLE_STAR")
        glow_form.addRow("Glare type:", self.glow_effect)

        self.glow_quality = QComboBox()
        self.glow_quality.addItem("High", "HIGH")
        self.glow_quality.addItem("Medium", "MEDIUM")
        self.glow_quality.addItem("Low · faster", "LOW")
        glow_form.addRow("Quality:", self.glow_quality)

        self.glow_source = QComboBox()
        self.glow_source.addItem("All bright highlights", "all_highlights")
        self.glow_source.addItem("Material Studio Emission only", "emission_only")
        self.glow_source.setToolTip(
            "All bright highlights: Bloom dapat mengenai lampu, refleksi, dan highlight. "
            "Material Studio Emission only: Bloom hanya berasal dari material yang "
            "Emission-nya aktif dan Include in Glow dicentang."
        )
        glow_form.addRow("Glow source:", self.glow_source)

        self.glow_threshold = self._spin(0, 1000, 0.01, 3, 1.0)
        self.glow_threshold.setToolTip(
            "Batas kecerahan minimum. Nilai lebih tinggi membatasi efek "
            "pada highlight yang lebih terang."
        )
        glow_form.addRow("Threshold:", self.glow_threshold)

        self.glow_strength = self._spin(0, 10, 0.05, 2, 0.65)
        self.glow_strength.setToolTip(
            "Kekuatan efek Glow/Bloom. Blender 5.x mendukung nilai di atas 1.0; "
            "nilai tinggi dapat membuat highlight sangat terang."
        )
        glow_form.addRow("Glow intensity:", self.glow_strength)

        self.glow_size = self._spin(0.05, 3, 0.05, 2, 0.5)
        glow_form.addRow("Glow size:", self.glow_size)

        quick_level_widget = QWidget()
        quick_level_layout = QVBoxLayout(quick_level_widget)
        quick_level_layout.setContentsMargins(0, 0, 0, 0)
        self.glow_level_slider = QSlider(Qt.Horizontal)
        self.glow_level_slider.setRange(0, 2)
        self.glow_level_slider.setSingleStep(1)
        self.glow_level_slider.setPageStep(1)
        self.glow_level_slider.setTickPosition(QSlider.TickPosition.TicksBelow)
        self.glow_level_slider.setTickInterval(1)
        self.glow_level_slider.setValue(1)
        self.glow_level_slider.setToolTip(
            "Low / Medium / High mengubah Glow Intensity dan Glow Size saja. "
            "Threshold dan sumber Glow tetap mengikuti pengaturan saat ini."
        )
        quick_level_layout.addWidget(self.glow_level_slider)
        quick_level_labels = QHBoxLayout()
        quick_level_labels.addWidget(QLabel("Low"))
        quick_level_labels.addStretch(1)
        quick_level_labels.addWidget(QLabel("Medium"))
        quick_level_labels.addStretch(1)
        quick_level_labels.addWidget(QLabel("High"))
        quick_level_layout.addLayout(quick_level_labels)
        self.glow_level_label = QLabel("Medium · Intensity 0.65 · Size 0.50")
        glow_form.addRow("Quick Glow level:", quick_level_widget)
        glow_form.addRow("Level status:", self.glow_level_label)
        self.glow_level_slider.valueChanged.connect(self._apply_glow_level)

        self.glow_smoothness = self._spin(0, 1, 0.05, 2, 0.25)
        glow_form.addRow("Highlight softness:", self.glow_smoothness)

        self.glow_saturation = self._spin(0, 1, 0.05, 2, 1.0)
        glow_form.addRow("Glow saturation:", self.glow_saturation)

        self.glow_streaks = self._int_spin(1, 16, 1, 6)
        glow_form.addRow("Streak count:", self.glow_streaks)

        self.glow_clamp = QCheckBox("Clamp very bright highlights")
        self.glow_clamp.setChecked(False)
        glow_form.addRow(self.glow_clamp)
        self.glow_maximum = self._spin(0.1, 10000, 0.5, 1, 10.0)
        self.glow_clamp.toggled.connect(
            lambda checked: self.glow_maximum.setEnabled(
                bool(checked) and self.glow_enabled.isChecked()
            )
        )
        glow_form.addRow("Maximum highlight:", self.glow_maximum)

        self.glow_emission_boost_enabled = QCheckBox(
            "Enable Emission Bloom Boost (render only)"
        )
        self.glow_emission_boost_enabled.setChecked(False)
        self.glow_emission_boost_enabled.setToolTip(
            "Mengalikan Emission Strength hanya pada material yang Emission-nya "
            "diatur melalui Material Studio, saat render sementara. Tidak menulis "
            "perubahan ke material asli atau dokumen .igz. Pada Cycles, nilai ini "
            "juga dapat meningkatkan kontribusi cahaya emissive ke scene."
        )
        glow_form.addRow(self.glow_emission_boost_enabled)
        self.glow_emission_boost = self._spin(1.0, 10.0, 0.25, 2, 2.0)
        self.glow_emission_boost.setToolTip(
            "Multiplier Emission Strength untuk material yang dikelola Material Studio."
        )
        glow_form.addRow("Emission boost multiplier:", self.glow_emission_boost)
        self.glow_emission_boost_enabled.toggled.connect(
            lambda checked: self.glow_emission_boost.setEnabled(
                bool(checked) and self.glow_enabled.isChecked()
            )
        )

        glow_note = QLabel(
            "Glow diproses melalui Compositor Blender untuk Cycles dan EEVEE. "
            "Pilih All bright highlights untuk efek global, atau Material Studio "
            "Emission only agar Bloom hanya berasal dari material emissive yang "
            "dipilih. Mode lokal memakai Shader AOV dan tidak mengubah Base Color "
            "atau material asli."
        )
        glow_note.setWordWrap(True)
        glow_form.addRow(glow_note)
        self.glow_enabled.toggled.connect(self._set_glow_controls_enabled)
        self.glow_preset_combo.currentIndexChanged.connect(
            self._glow_preset_selection_changed
        )
        self.glow_strength.valueChanged.connect(self._mark_glow_level_manual)
        self.glow_size.valueChanged.connect(self._mark_glow_level_manual)
        for widget, signal_name in (
            (self.glow_enabled, "toggled"),
            (self.glow_effect, "currentIndexChanged"),
            (self.glow_quality, "currentIndexChanged"),
            (self.glow_source, "currentIndexChanged"),
            (self.glow_threshold, "valueChanged"),
            (self.glow_strength, "valueChanged"),
            (self.glow_size, "valueChanged"),
            (self.glow_smoothness, "valueChanged"),
            (self.glow_saturation, "valueChanged"),
            (self.glow_streaks, "valueChanged"),
            (self.glow_clamp, "toggled"),
            (self.glow_maximum, "valueChanged"),
            (self.glow_emission_boost_enabled, "toggled"),
            (self.glow_emission_boost, "valueChanged"),
        ):
            getattr(widget, signal_name).connect(self._mark_glow_preset_custom)
        rform.addRow(glow_box)
        self._set_glow_controls_enabled(self.glow_enabled.isChecked())

        blender_row = QHBoxLayout()
        self.blender_label = QLabel("Checking Blender…")
        self.blender_label.setWordWrap(True)
        blender_row.addWidget(self.blender_label, 1)
        choose_blender = QPushButton("Choose…")
        choose_blender.clicked.connect(self._choose_blender)
        blender_row.addWidget(choose_blender)
        rform.addRow("Blender:", blender_row)
        layout.addWidget(render)

        buttons = QHBoxLayout()
        self.apply_button = QPushButton("Save all settings")
        self.apply_button.setToolTip(
            "Simpan pengaturan material, kamera, dan render sekaligus."
        )
        self.apply_button.clicked.connect(self.apply_settings)
        buttons.addWidget(self.apply_button)
        self.render_button = QPushButton("Render")
        self.render_button.clicked.connect(self.start_render)
        buttons.addWidget(self.render_button)
        self.stop_button = QPushButton("Stop")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.stop_render)
        buttons.addWidget(self.stop_button)
        layout.addLayout(buttons)

        self.progress = QProgressBar()
        self.progress.setRange(0, 1000)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        layout.addWidget(self.progress)
        self.status = QLabel("Ready.")
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        self.open_render_button = QPushButton("Open rendered image")
        self.open_render_button.setEnabled(False)
        self.open_render_button.clicked.connect(self.open_render)
        layout.addWidget(self.open_render_button)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Camera & Render")

    def _build_lighting_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)

        intro = QLabel(
            "Lighting Properties untuk render Blender Material Studio. "
            "Lampu di sini terpisah dari material PBR dan tidak mengubah "
            "material asli pada dokumen."
        )
        intro.setWordWrap(True)
        layout.addWidget(intro)

        self.custom_lighting_enabled = QCheckBox("Enable custom lights")
        self.custom_lighting_enabled.setChecked(True)
        layout.addWidget(self.custom_lighting_enabled)
        self.show_light_guides = QCheckBox("Show light guides in viewport")
        self.show_light_guides.setChecked(True)
        self.show_light_guides.setToolTip(
            "Menampilkan bola wireframe Point, cone Spot, bingkai Area, dan arah Sun. "
            "Helper hanya overlay viewport dan tidak ikut dirender."
        )
        self.show_light_guides.toggled.connect(
            lambda _checked: self.app.viewport.update()
        )
        layout.addWidget(self.show_light_guides)

        lights_box = QGroupBox("Scene Lights")
        lights_layout = QVBoxLayout(lights_box)
        self.light_list = QListWidget()
        self.light_list.setMinimumHeight(120)
        self.light_list.currentRowChanged.connect(self._load_selected_light)
        lights_layout.addWidget(self.light_list)

        add_row = QHBoxLayout()
        self.add_light_type = QComboBox()
        self.add_light_type.addItem("Area Light", "AREA")
        self.add_light_type.addItem("Point Light", "POINT")
        self.add_light_type.addItem("Spot Light", "SPOT")
        self.add_light_type.addItem("Sun Light", "SUN")
        add_row.addWidget(self.add_light_type, 1)
        add_button = QPushButton("Add Light in Viewport")
        add_button.setToolTip("Klik titik pada model/viewport untuk menempatkan lampu.")
        add_button.clicked.connect(self._add_light)
        add_row.addWidget(add_button)
        lights_layout.addLayout(add_row)

        move_row = QHBoxLayout()
        self.move_light_button = QPushButton("Move Light in Viewport")
        self.move_light_button.setToolTip(
            "Pilih lampu, lalu klik posisi baru. Snap/inference IngeTrazo tetap aktif."
        )
        self.move_light_button.clicked.connect(self._begin_move_light)
        move_row.addWidget(self.move_light_button)
        self.apply_lighting_button = QPushButton("Apply Lighting")
        self.apply_lighting_button.setToolTip(
            "Simpan perubahan Lighting ke dokumen .igz tanpa menyimpan ulang material."
        )
        self.apply_lighting_button.clicked.connect(self._persist_lighting_only)
        move_row.addWidget(self.apply_lighting_button)
        lights_layout.addLayout(move_row)

        duplicate_row = QHBoxLayout()
        self.duplicate_independent_button = QPushButton("Duplicate Independent")
        self.duplicate_independent_button.clicked.connect(
            lambda: self._duplicate_light(linked=False)
        )
        duplicate_row.addWidget(self.duplicate_independent_button)
        self.duplicate_linked_button = QPushButton("Duplicate Linked")
        self.duplicate_linked_button.clicked.connect(
            lambda: self._duplicate_light(linked=True)
        )
        duplicate_row.addWidget(self.duplicate_linked_button)
        lights_layout.addLayout(duplicate_row)

        edit_row = QHBoxLayout()
        self.copy_light_settings_button = QPushButton("Copy Settings")
        self.copy_light_settings_button.clicked.connect(self._copy_light_settings)
        edit_row.addWidget(self.copy_light_settings_button)
        self.paste_light_settings_button = QPushButton("Paste Settings")
        self.paste_light_settings_button.clicked.connect(self._paste_light_settings)
        edit_row.addWidget(self.paste_light_settings_button)
        self.delete_light_button = QPushButton("Delete Light")
        self.delete_light_button.clicked.connect(self._delete_light)
        edit_row.addWidget(self.delete_light_button)
        lights_layout.addLayout(edit_row)
        layout.addWidget(lights_box)

        self.light_properties_box = QGroupBox("Light Properties")
        form = QFormLayout(self.light_properties_box)
        self.light_name = QLineEdit()
        form.addRow("Name:", self.light_name)
        self.light_enabled = QCheckBox("Light enabled")
        form.addRow(self.light_enabled)
        self.light_type = QComboBox()
        self.light_type.addItem("Area", "AREA")
        self.light_type.addItem("Point", "POINT")
        self.light_type.addItem("Spot", "SPOT")
        self.light_type.addItem("Sun", "SUN")
        form.addRow("Type:", self.light_type)
        self.light_power = self._spin(0, 10000000, 10, 1, 1200)
        form.addRow("Power / Strength:", self.light_power)
        self.light_color_button = QPushButton("Choose light color…")
        self.light_color_button.clicked.connect(self._choose_light_color)
        form.addRow("Color:", self.light_color_button)

        self.light_shape = QComboBox()
        for label, value in (("Rectangle", "RECTANGLE"), ("Square", "SQUARE"),
                             ("Disk", "DISK"), ("Ellipse", "ELLIPSE")):
            self.light_shape.addItem(label, value)
        form.addRow("Area shape:", self.light_shape)
        self.light_size = self._spin(0.001, 100000, 0.1, 3, 4.0, " u")
        form.addRow("Size / radius:", self.light_size)
        self.light_size_y = self._spin(0.001, 100000, 0.1, 3, 2.0, " u")
        form.addRow("Size Y:", self.light_size_y)
        self.light_soft_size = self._spin(0.001, 10000, 0.01, 3, 0.25, " u")
        form.addRow("Shadow softness / source size:", self.light_soft_size)
        self.light_soft_size.setToolTip(
            "Mengatur kelembutan bayangan / ukuran sumber cahaya, bukan radius jangkauan."
        )
        self.light_range = self._spin(0.01, 100000, 0.5, 2, 10.0, " u")
        form.addRow("Influence radius / Spot range:", self.light_range)
        self.light_range.setToolTip(
            "Point: radius bola jangkauan cahaya. Spot: panjang cone. "
            "Nilai ini juga dipakai untuk guide viewport."
        )
        self.light_use_custom_range = QCheckBox("Use finite influence distance")
        self.light_use_custom_range.setChecked(True)
        self.light_use_custom_range.setToolTip(
            "Jika aktif dan didukung Blender, jarak ini menjadi cutoff cahaya. "
            "Jika nonaktif, lingkaran Point tetap tampil sebagai guide referensi."
        )
        form.addRow(self.light_use_custom_range)
        self.light_spot_size = self._spin(1, 179, 1, 1, 45, "°")
        form.addRow("Spot cone:", self.light_spot_size)
        self.light_spot_blend = self._spin(0, 1, 0.02, 2, 0.15)
        form.addRow("Spot blend:", self.light_spot_blend)
        self.light_sun_angle = self._spin(0, 20, 0.05, 2, 0.53, "°")
        form.addRow("Sun angle:", self.light_sun_angle)

        self.light_use_shadow = QCheckBox("Cast shadows")
        self.light_use_shadow.setChecked(True)
        form.addRow(self.light_use_shadow)
        self.light_use_diffuse = QCheckBox("Affect diffuse surfaces")
        self.light_use_diffuse.setChecked(True)
        form.addRow(self.light_use_diffuse)
        self.light_use_glossy = QCheckBox("Affect glossy reflections")
        self.light_use_glossy.setChecked(True)
        form.addRow(self.light_use_glossy)

        self.light_transform_box = QGroupBox("Transform · Move / Rotate")
        transform_form = QFormLayout(self.light_transform_box)
        self.light_pos_x = self._spin(-100000, 100000, 0.1, 3, 0.0, " u")
        self.light_pos_y = self._spin(-100000, 100000, 0.1, 3, -5.0, " u")
        self.light_pos_z = self._spin(-100000, 100000, 0.1, 3, 5.0, " u")
        transform_form.addRow("Location X:", self.light_pos_x)
        transform_form.addRow("Location Y:", self.light_pos_y)
        transform_form.addRow("Location Z:", self.light_pos_z)
        self.light_rot_x = self._spin(-360, 360, 1, 1, 45.0, "°")
        self.light_rot_y = self._spin(-360, 360, 1, 1, 0.0, "°")
        self.light_rot_z = self._spin(-360, 360, 1, 1, 0.0, "°")
        transform_form.addRow("Rotation X:", self.light_rot_x)
        transform_form.addRow("Rotation Y:", self.light_rot_y)
        transform_form.addRow("Rotation Z:", self.light_rot_z)
        layout.addWidget(self.light_properties_box)
        layout.addWidget(self.light_transform_box)

        linked_note = QLabel(
            "Duplicate Independent menyalin seluruh pengaturan menjadi lampu "
            "mandiri. Duplicate Linked memakai data lampu yang sama: warna, "
            "power, ukuran dan tipe ikut berubah bersama, tetapi posisi dan "
            "rotasi masing-masing lampu tetap mandiri. Copy/Paste Settings "
            "menyalin data lampu tanpa menyalin transform."
        )
        linked_note.setWordWrap(True)
        layout.addWidget(linked_note)

        viewport_note = QLabel(
            "Pilih ikon lampu di viewport, lalu tekan M untuk mengaktifkan "
            "Move Light Material Studio; klik titik tujuan dengan snap dan "
            "inference IngeTrazo. Tombol Move Light in Viewport tetap tersedia. "
            "Bola radius Point dan cone Spot hanya overlay viewport, bukan geometri model, "
            "sehingga tidak ikut masuk hasil render."
        )
        viewport_note.setWordWrap(True)
        layout.addWidget(viewport_note)

        # All property changes are staged in the document and committed by
        # Save all settings or the Render button.
        for widget in (
            self.light_name, self.light_enabled, self.light_type,
            self.light_power, self.light_shape, self.light_size,
            self.light_size_y, self.light_soft_size, self.light_range,
            self.light_use_custom_range, self.light_spot_size,
            self.light_spot_blend, self.light_sun_angle,
            self.light_use_shadow, self.light_use_diffuse,
            self.light_use_glossy, self.light_pos_x, self.light_pos_y,
            self.light_pos_z, self.light_rot_x, self.light_rot_y,
            self.light_rot_z,
        ):
            signal = getattr(widget, "textChanged", None)
            if signal is not None:
                signal.connect(self._update_selected_light)
            signal = getattr(widget, "valueChanged", None)
            if signal is not None:
                signal.connect(self._update_selected_light)
            signal = getattr(widget, "toggled", None)
            if signal is not None:
                signal.connect(self._update_selected_light)
            signal = getattr(widget, "currentIndexChanged", None)
            if signal is not None:
                signal.connect(self._update_selected_light)
        self.custom_lighting_enabled.toggled.connect(self._lighting_enable_changed)

        layout.addStretch(1)
        self.tabs.addTab(tab, "Lighting")

    @staticmethod
    def _light_data_keys():
        return (
            "type", "color", "energy", "shape", "size", "size_y",
            "soft_size", "range", "use_custom_range", "spot_size",
            "spot_blend", "sun_angle",
            "use_shadow", "use_diffuse", "use_glossy",
        )

    def _new_light(self, kind="AREA", name=None):
        kind = str(kind or "AREA").upper()
        if kind not in ("AREA", "POINT", "SPOT", "SUN"):
            kind = "AREA"
        count = len(self._lights) + 1
        defaults = {
            "AREA": (1200.0, 4.0, 2.0),
            "POINT": (800.0, 4.0, 2.0),
            "SPOT": (1000.0, 4.0, 2.0),
            "SUN": (3.0, 4.0, 2.0),
        }
        energy, size, size_y = defaults[kind]
        return {
            "id": uuid.uuid4().hex,
            "data_id": uuid.uuid4().hex,
            "name": name or f"{kind.title()} Light {count:02d}",
            "type": kind,
            "enabled": True,
            "color": [1.0, 1.0, 1.0],
            "energy": energy,
            "shape": "RECTANGLE",
            "size": size,
            "size_y": size_y,
            "soft_size": 0.25,
            "range": 10.0,
            "use_custom_range": True,
            "spot_size": 45.0,
            "spot_blend": 0.15,
            "sun_angle": 0.53,
            "use_shadow": True,
            "use_diffuse": True,
            "use_glossy": True,
            "location": [0.0, -5.0, 5.0],
            "rotation": [45.0, 0.0, 0.0],
        }

    def _selected_light(self):
        row = self.light_list.currentRow()
        if 0 <= row < len(self._lights):
            return self._lights[row]
        return None

    def _light_list_label(self, light):
        linked_count = sum(
            1 for item in self._lights
            if item.get("data_id") == light.get("data_id")
        )
        status = "On" if light.get("enabled", True) else "Off"
        linked = " · Linked" if linked_count > 1 else ""
        return f"{light.get('name', 'Light')}  [{light.get('type', 'AREA')}]  · {status}{linked}"

    def _refresh_light_list(self, selected_id=None):
        self.light_list.blockSignals(True)
        self.light_list.clear()
        selected_row = -1
        for index, light in enumerate(self._lights):
            item = QListWidgetItem(self._light_list_label(light))
            item.setData(Qt.UserRole, light.get("id"))
            self.light_list.addItem(item)
            if light.get("id") == selected_id:
                selected_row = index
        if selected_row < 0 and self._lights:
            selected_row = 0
        self.light_list.setCurrentRow(selected_row)
        self.light_list.blockSignals(False)
        self._load_selected_light(selected_row)

    def _load_lighting(self):
        if self._view_pick is not None:
            self._view_pick = None
            release = getattr(self.app, "release_pick", None)
            if callable(release):
                try:
                    release()
                except Exception:
                    pass
        raw = self._data().get("lighting", {})
        if not isinstance(raw, dict):
            raw = {}
        self._lights = []
        for index, item in enumerate(raw.get("lights", []) or []):
            if not isinstance(item, dict):
                continue
            light = dict(item)
            kind = str(light.get("type", "AREA")).upper()
            if kind not in ("AREA", "POINT", "SPOT", "SUN"):
                kind = "AREA"
            light["type"] = kind
            light.setdefault("id", uuid.uuid4().hex)
            light.setdefault("data_id", light["id"])
            light.setdefault("name", f"{kind.title()} Light {index + 1:02d}")
            light.setdefault("enabled", True)
            defaults = self._new_light(kind, light["name"])
            for key, value in defaults.items():
                light.setdefault(key, value)
            for key in ("location", "rotation", "color"):
                try:
                    values = list(light.get(key, defaults[key]))[:3]
                    while len(values) < 3:
                        values.append(defaults[key][len(values)])
                    light[key] = [float(v) for v in values]
                except Exception:
                    light[key] = list(defaults[key])
            for key in ("energy", "size", "size_y", "soft_size", "range",
                        "spot_size", "spot_blend", "sun_angle"):
                try:
                    light[key] = float(light.get(key, defaults[key]))
                except Exception:
                    light[key] = defaults[key]
            for key in ("use_shadow", "use_diffuse", "use_glossy", "enabled",
                        "use_custom_range"):
                light[key] = bool(light.get(key, defaults[key]))
            if light.get("shape") not in ("SQUARE", "RECTANGLE", "DISK", "ELLIPSE"):
                light["shape"] = "RECTANGLE"
            self._lights.append(light)
        self.custom_lighting_enabled.setChecked(bool(raw.get("enabled", True)))
        self.show_light_guides.setChecked(bool(raw.get("show_guides", True)))
        self._refresh_light_list(raw.get("selected_light_id"))
        try:
            self.app.viewport.update()
        except Exception:
            pass

    @staticmethod
    def _linear_to_srgb(value):
        value = max(0.0, min(1.0, float(value)))
        return 12.92 * value if value <= 0.0031308 else 1.055 * (value ** (1.0 / 2.4)) - 0.055

    @staticmethod
    def _srgb_to_linear(value):
        value = max(0.0, min(1.0, float(value)))
        return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4

    def _set_light_color_button(self, color):
        try:
            srgb = [self._linear_to_srgb(v) for v in color[:3]]
            r, g, b = [max(0, min(255, int(v * 255))) for v in srgb]
            self.light_color_button.setStyleSheet(
                f"background-color: rgb({r}, {g}, {b}); color: "
                f"{'black' if (r + g + b) > 380 else 'white'};"
            )
            self.light_color_button.setText(f"Light Color  ·  #{r:02X}{g:02X}{b:02X}")
        except Exception:
            self.light_color_button.setStyleSheet("")
            self.light_color_button.setText("Choose light color…")

    def _load_selected_light(self, row=-1):
        light = self._selected_light()
        self._loading_light = True
        try:
            self.light_properties_box.setEnabled(light is not None)
            self.light_transform_box.setEnabled(light is not None)
            for button in (
                self.duplicate_independent_button, self.duplicate_linked_button,
                self.copy_light_settings_button, self.delete_light_button,
                self.move_light_button,
            ):
                button.setEnabled(light is not None)
            self.paste_light_settings_button.setEnabled(
                light is not None and self._light_clipboard is not None
            )
            if light is None:
                return
            self.light_name.setText(str(light.get("name", "Light")))
            self.light_enabled.setChecked(bool(light.get("enabled", True)))
            self._set_combo(self.light_type, light.get("type", "AREA"))
            self.light_power.setValue(float(light.get("energy", 1000.0)))
            self._set_light_color_button(light.get("color", [1, 1, 1]))
            self._set_combo(self.light_shape, light.get("shape", "RECTANGLE"))
            self.light_size.setValue(float(light.get("size", 4.0)))
            self.light_size_y.setValue(float(light.get("size_y", 2.0)))
            self.light_soft_size.setValue(float(light.get("soft_size", 0.25)))
            self.light_range.setValue(float(light.get("range", 10.0)))
            self.light_use_custom_range.setChecked(bool(light.get("use_custom_range", True)))
            self.light_spot_size.setValue(float(light.get("spot_size", 45.0)))
            self.light_spot_blend.setValue(float(light.get("spot_blend", 0.15)))
            self.light_sun_angle.setValue(float(light.get("sun_angle", 0.53)))
            self.light_use_shadow.setChecked(bool(light.get("use_shadow", True)))
            self.light_use_diffuse.setChecked(bool(light.get("use_diffuse", True)))
            self.light_use_glossy.setChecked(bool(light.get("use_glossy", True)))
            loc = light.get("location", [0, -5, 5])
            rot = light.get("rotation", [45, 0, 0])
            self.light_pos_x.setValue(float(loc[0]))
            self.light_pos_y.setValue(float(loc[1]))
            self.light_pos_z.setValue(float(loc[2]))
            self.light_rot_x.setValue(float(rot[0]))
            self.light_rot_y.setValue(float(rot[1]))
            self.light_rot_z.setValue(float(rot[2]))
            kind = light.get("type", "AREA")
            self.light_shape.setEnabled(kind == "AREA")
            self.light_size.setEnabled(kind == "AREA")
            self.light_size_y.setEnabled(kind == "AREA")
            self.light_soft_size.setEnabled(kind in ("POINT", "SPOT"))
            self.light_range.setEnabled(kind in ("POINT", "SPOT"))
            self.light_use_custom_range.setEnabled(kind in ("POINT", "SPOT"))
            self.light_spot_size.setEnabled(kind == "SPOT")
            self.light_spot_blend.setEnabled(kind == "SPOT")
            self.light_sun_angle.setEnabled(kind == "SUN")
        finally:
            self._loading_light = False

    def _add_light(self):
        if len(self._lights) >= 32:
            QMessageBox.information(
                self, "Lighting Properties", "Maksimal 32 custom lights per project."
            )
            return
        self._begin_light_pick("add", self.add_light_type.currentData())

    def _begin_move_light(self):
        light = self._selected_light()
        if light is None:
            QMessageBox.information(self, "Lighting Properties", "Pilih lampu yang akan dipindahkan.")
            return
        self._begin_light_pick("move", light_id=light.get("id"))

    def _begin_light_pick(self, action, kind=None, light_id=None):
        prompts = {
            "add": "Klik lokasi lampu baru pada model / viewport",
            "move": "Klik lokasi baru untuk memindahkan lampu",
        }
        self._light_pick_action = (action, kind, light_id)
        self._light_preview = None
        tool = _make_material_studio_pick_tool(
            prompts[action], self._finish_light_pick, self._cancel_light_pick,
            self._preview_light_pick,
        )
        self.app.viewport.set_active_tool(tool)
        win = self.app.window
        try:
            win.statusBar().showMessage(prompts[action] + " — Esc untuk batal")
        except Exception:
            pass
        self.app.viewport.setFocus()
        self.app.viewport.update()

    def eventFilter(self, watched, event):
        """Route M to the extension light-move tool when a light is selected.

        IngeTrazo 0.6.x Extension API exposes selection/deletion for extension
        pickables, while transform support is not yet public. This shortcut
        therefore starts Material Studio's own one-click move tool, which
        still uses IngeTrazo's native snap/inference ToolContext.
        """
        if (watched is getattr(self.app, "viewport", None)
                and event.type() == QEvent.KeyPress
                and event.key() == Qt.Key_M
                and not event.isAutoRepeat()
                and not (event.modifiers() & (
                    Qt.ControlModifier | Qt.AltModifier | Qt.MetaModifier
                ))
                and self._view_pick is not None
                and self._selected_light() is not None):
            self._begin_move_light()
            return True
        return super().eventFilter(watched, event)

    def _preview_light_pick(self, point):
        self._light_preview = QVector3D(point) if point is not None else None
        try:
            self.app.viewport.update()
        except Exception:
            pass

    def _finish_light_pick(self, point, on_face=False):
        action, kind, light_id = self._light_pick_action or (None, None, None)
        selected_id = light_id
        if action == "add":
            light = self._new_light(kind)
            p = QVector3D(point)
            if on_face and light["type"] == "POINT":
                p.setZ(p.z() + 0.10)
            light["location"] = [float(p.x()), float(p.y()), float(p.z())]
            self._lights.append(light)
            selected_id = light["id"]
            self._refresh_light_list(selected_id)
            self.status.setText(f"{light['name']} ditempatkan di viewport.")
        elif action == "move":
            light = next((item for item in self._lights if item.get("id") == light_id), None)
            if light is not None:
                p = QVector3D(point)
                light["location"] = [float(p.x()), float(p.y()), float(p.z())]
                selected_id = light_id
                self._refresh_light_list(selected_id)
                self.status.setText(f"{light.get('name', 'Light')} dipindahkan.")
        self._light_pick_action = None
        self._light_preview = None
        self._persist_lighting_only()
        self._restore_select_tool()

    def _cancel_light_pick(self):
        self._light_pick_action = None
        self._light_preview = None
        self.status.setText("Penempatan / pemindahan lampu dibatalkan.")
        self._restore_select_tool()

    def _restore_select_tool(self):
        win = self.app.window
        try:
            win.statusBar().clearMessage()
        except Exception:
            pass
        activate = getattr(win, "_activate_tool", None)
        if callable(activate):
            try:
                activate("select")
            except Exception:
                pass
        try:
            self.app.viewport.update()
        except Exception:
            pass

    def _persist_lighting_only(self):
        """Save only the Lighting block as one document-data undo step."""
        try:
            data = self._data()
            data["lighting"] = self._lighting_config()
            self.app.set_document_data(data)
            self.status.setText("Lighting tersimpan ke dokumen .igz.")
            try:
                self.app.viewport.update()
            except Exception:
                pass
            return True
        except Exception as exc:
            QMessageBox.critical(self, "Lighting Properties", str(exc))
            return False

    def _duplicate_light(self, linked=False):
        source = self._selected_light()
        if source is None:
            return
        if len(self._lights) >= 32:
            QMessageBox.information(
                self, "Lighting Properties", "Maksimal 32 custom lights per project."
            )
            return
        duplicate = json.loads(json.dumps(source))
        duplicate["id"] = uuid.uuid4().hex
        duplicate["name"] = str(source.get("name", "Light")) + (
            " Linked Copy" if linked else " Copy"
        )
        if not linked:
            duplicate["data_id"] = uuid.uuid4().hex
        loc = list(duplicate.get("location", [0, -5, 5]))
        loc[0] = float(loc[0]) + 1.0
        duplicate["location"] = loc
        self._lights.append(duplicate)
        self._refresh_light_list(duplicate["id"])
        mode = "Linked" if linked else "Independent"
        self.status.setText(f"{mode} duplicate dibuat. Posisi digeser +1 scene unit pada sumbu X.")
        self._persist_lighting_only()

    def _delete_light(self):
        light = self._selected_light()
        if light is not None:
            self._delete_light_by_id(light.get("id"))

    def _delete_light_by_id(self, light_id):
        if not light_id:
            return
        old_row = self.light_list.currentRow()
        self._lights = [item for item in self._lights if item.get("id") != light_id]
        self._view_pick = None
        if self._lights:
            next_row = min(max(old_row, 0), len(self._lights) - 1)
            selected_id = self._lights[next_row].get("id")
        else:
            selected_id = None
        self._refresh_light_list(selected_id)
        self.status.setText("Light dihapus dari konfigurasi Material Studio.")
        self._persist_lighting_only()

    def _delete_light_from_view(self, light_id):
        self._delete_light_by_id(light_id)

    def _copy_light_settings(self):
        light = self._selected_light()
        if light is None:
            return
        self._light_clipboard = {
            key: json.loads(json.dumps(light.get(key)))
            for key in self._light_data_keys()
        }
        self.paste_light_settings_button.setEnabled(True)
        self.status.setText("Properti lampu disalin. Paste tidak menyalin posisi/rotasi.")

    def _paste_light_settings(self):
        light = self._selected_light()
        if light is None or self._light_clipboard is None:
            return
        data_id = light.get("data_id")
        for item in self._lights:
            if item.get("data_id") == data_id:
                for key, value in self._light_clipboard.items():
                    item[key] = json.loads(json.dumps(value))
        self._refresh_light_list(light.get("id"))
        self.status.setText("Properti lampu ditempel. Posisi dan rotasi tetap milik lampu tujuan.")
        self._persist_lighting_only()

    def _pick_viewport_light(self, viewport, px, py):
        """Return the stable light ID under a viewport pixel, if any."""
        best_id = None
        best_distance = 14.0
        for light in self._lights:
            try:
                point = viewport._world_to_pixel(
                    QVector3D(*light.get("location", [0.0, 0.0, 0.0]))
                )
            except Exception:
                point = None
            if point is None:
                continue
            distance = ((float(point[0]) - float(px)) ** 2
                        + (float(point[1]) - float(py)) ** 2) ** 0.5
            if distance <= best_distance:
                best_id, best_distance = light.get("id"), distance
        return best_id

    def _on_viewport_light_selected(self, light_id):
        self._view_pick = light_id
        if light_id is not None:
            for row, light in enumerate(self._lights):
                if light.get("id") == light_id:
                    self.light_list.setCurrentRow(row)
                    break
        try:
            self.app.viewport.update()
        except Exception:
            pass

    def _choose_light_color(self):
        light = self._selected_light()
        if light is None:
            return
        color = light.get("color", [1, 1, 1])
        initial = QColor(*[
            max(0, min(255, int(self._linear_to_srgb(v) * 255)))
            for v in color[:3]
        ])
        chosen = QColorDialog.getColor(initial, self, "Choose Light Color")
        if chosen.isValid():
            light["color"] = [
                self._srgb_to_linear(chosen.redF()),
                self._srgb_to_linear(chosen.greenF()),
                self._srgb_to_linear(chosen.blueF()),
            ]
            self._set_light_color_button(light["color"])
            self._update_selected_light()

    def _update_selected_light(self, *_):
        if self._loading_light:
            return
        light = self._selected_light()
        if light is None:
            return
        light["name"] = self.light_name.text().strip() or "Light"
        light["enabled"] = self.light_enabled.isChecked()
        light["location"] = [
            self.light_pos_x.value(), self.light_pos_y.value(), self.light_pos_z.value()
        ]
        light["rotation"] = [
            self.light_rot_x.value(), self.light_rot_y.value(), self.light_rot_z.value()
        ]
        shared = {
            "type": self.light_type.currentData() or "AREA",
            "energy": self.light_power.value(),
            "shape": self.light_shape.currentData() or "RECTANGLE",
            "size": self.light_size.value(),
            "size_y": self.light_size_y.value(),
            "soft_size": self.light_soft_size.value(),
            "range": self.light_range.value(),
            "use_custom_range": self.light_use_custom_range.isChecked(),
            "spot_size": self.light_spot_size.value(),
            "spot_blend": self.light_spot_blend.value(),
            "sun_angle": self.light_sun_angle.value(),
            "use_shadow": self.light_use_shadow.isChecked(),
            "use_diffuse": self.light_use_diffuse.isChecked(),
            "use_glossy": self.light_use_glossy.isChecked(),
        }
        # Colour is stored on the selected record and shared with linked data
        # by the colour picker; all other data controls are shared here.
        shared["color"] = list(light.get("color", [1, 1, 1]))
        group_id = light.get("data_id")
        for item in self._lights:
            if item.get("data_id") == group_id:
                for key, value in shared.items():
                    item[key] = json.loads(json.dumps(value))
        self.light_shape.setEnabled(shared["type"] == "AREA")
        self.light_size.setEnabled(shared["type"] == "AREA")
        self.light_size_y.setEnabled(shared["type"] == "AREA")
        self.light_soft_size.setEnabled(shared["type"] in ("POINT", "SPOT"))
        self.light_range.setEnabled(shared["type"] in ("POINT", "SPOT"))
        self.light_use_custom_range.setEnabled(shared["type"] in ("POINT", "SPOT"))
        self.light_spot_size.setEnabled(shared["type"] == "SPOT")
        self.light_spot_blend.setEnabled(shared["type"] == "SPOT")
        self.light_sun_angle.setEnabled(shared["type"] == "SUN")
        for index, linked_light in enumerate(self._lights):
            item = self.light_list.item(index)
            if item is not None:
                item.setText(self._light_list_label(linked_light))
        self.status.setText("Perubahan Lighting Properties belum disimpan. Klik Apply Lighting untuk menyimpan.")
        try:
            self.app.viewport.update()
        except Exception:
            pass

    def _lighting_enable_changed(self, enabled):
        if self._loading_light:
            return
        self.status.setText(
            "Custom lights aktif." if enabled else
            "Custom lights nonaktif; lampu bawaan IngeTrazo/preset tetap dipakai."
        )
        try:
            self.app.viewport.update()
        except Exception:
            pass

    def _lighting_config(self):
        lights = json.loads(json.dumps(self._lights))
        seen = set()
        for light in lights:
            light_id = str(light.get("id", ""))
            if not light_id or light_id in seen:
                light["id"] = uuid.uuid4().hex
            seen.add(light["id"])
            if light.get("type") not in ("AREA", "POINT", "SPOT", "SUN"):
                raise ValueError(f"Jenis lampu tidak valid: {light.get('type')}")
            for key in ("location", "rotation", "color"):
                values = light.get(key, [])
                if not isinstance(values, list) or len(values) != 3:
                    raise ValueError(f"Nilai {key} pada {light.get('name', 'Light')} harus memiliki X, Y, Z/RGB.")
                if any(not isinstance(v, (int, float)) for v in values):
                    raise ValueError(f"Nilai {key} pada {light.get('name', 'Light')} tidak valid.")
        selected = self._selected_light()
        return {
            "enabled": self.custom_lighting_enabled.isChecked(),
            "show_guides": self.show_light_guides.isChecked(),
            "lights": lights,
            "selected_light_id": selected.get("id") if selected else None,
        }

    def _add_map_row(self, form, label, key):
        row = QHBoxLayout()
        edit = QLineEdit()
        edit.setPlaceholderText("Pilih file gambar…")
        edit.setMinimumWidth(50)
        browse = QPushButton("…")
        browse.setMaximumWidth(34)
        clear = QPushButton("×")
        clear.setMaximumWidth(28)
        browse.clicked.connect(lambda _=False, k=key: self._browse_map(k))
        clear.clicked.connect(lambda _=False, k=key: self._map_edits[k].clear())
        row.addWidget(edit, 1)
        row.addWidget(browse)
        row.addWidget(clear)
        form.addRow(label + ":", row)
        self._map_edits[key] = edit

    def _data(self):
        data = self.app.document_data(default={}) or {}
        if not isinstance(data, dict):
            data = {}
        data.setdefault("materials", {})
        data.setdefault("global", {})
        data.setdefault("camera", {})
        data.setdefault("render", {})
        data.setdefault("lighting", {"enabled": True, "lights": []})
        return data

    def _selected_name(self):
        return self.material_combo.currentData()

    def _install_sample_hook(self):
        """Listen to IngeTrazo's built-in eyedropper sample completion.

        PaintTool calls tray.materials.sync_from_paint() after it has updated
        PaintTool.current_material. Wrapping that documented-in-source
        integration point avoids changing IngeTrazo core files.
        """
        # ExtensionApp exposes the real MainWindow as `.window`.
        # The tray belongs to MainWindow, not ExtensionApp itself.
        window = getattr(self.app, "window", self.app)
        tray = getattr(window, "tray", None)
        paint_panel = getattr(tray, "materials", None)
        original = getattr(paint_panel, "sync_from_paint", None)
        if paint_panel is None or not callable(original):
            return False

        listeners = getattr(
            paint_panel, "_material_studio_sample_listeners", None
        )
        if listeners is None:
            listeners = []

            def sync_and_notify(*args, **kwargs):
                result = original(*args, **kwargs)
                for ref in tuple(listeners):
                    panel = ref()
                    if panel is None:
                        try:
                            listeners.remove(ref)
                        except ValueError:
                            pass
                        continue
                    try:
                        panel._on_sampled_material_changed()
                    except RuntimeError:
                        # The Qt panel may have been closed during shutdown.
                        pass
                return result

            paint_panel.sync_from_paint = sync_and_notify
            paint_panel._material_studio_sample_listeners = listeners

        if not any(ref() is self for ref in listeners):
            listeners.append(weakref.ref(self))
        return True

    @staticmethod
    def _normalised_texture_path(texture):
        """Comparable texture path for matching a sampled face to a registry material."""
        if not isinstance(texture, dict):
            return ""
        path = str(texture.get("path") or "").strip()
        if not path:
            return ""
        import os
        try:
            return os.path.normcase(os.path.abspath(os.path.normpath(path)))
        except (TypeError, ValueError, OSError):
            return os.path.normcase(os.path.normpath(path))

    @classmethod
    def _match_sampled_registry_material(cls, app, paint_tool):
        """Find a unique named scene material matching the sampled paint recipe.

        IngeTrazo faces can carry a texture or colour without a `mat` identity
        tag. In that case PaintTool.current_material is None even though the
        same texture/colour may belong to a named material in scene.materials.
        Only return a name when the match is unique; never guess between
        different named materials that share an image or colour.
        """
        registry = getattr(getattr(app, "scene", None), "materials", {}) or {}
        sampled_texture = getattr(paint_tool, "current_texture", None)
        if isinstance(sampled_texture, dict):
            sampled_path = cls._normalised_texture_path(sampled_texture)
            if sampled_path:
                path_matches = []
                exact_matches = []
                keys = ("sw", "sh", "rot", "tint", "tint_mode")
                for name, material in registry.items():
                    recipe = getattr(material, "texture", None)
                    if not isinstance(recipe, dict):
                        continue
                    if cls._normalised_texture_path(recipe) != sampled_path:
                        continue
                    path_matches.append(str(name))
                    if all(recipe.get(k) == sampled_texture.get(k)
                           for k in keys):
                        exact_matches.append(str(name))
                if len(exact_matches) == 1:
                    return exact_matches[0], "tekstur yang cocok"
                if len(exact_matches) > 1:
                    return None, "beberapa material memakai resep tekstur yang sama"
                if len(path_matches) == 1:
                    return path_matches[0], "file tekstur yang cocok"
                if len(path_matches) > 1:
                    return None, "file tekstur dipakai oleh beberapa material"

                # Some material libraries name the material after the image.
                # Use this only for an exact, unique filename-stem/name match.
                from pathlib import Path
                stem = Path(str(sampled_texture.get("path", ""))).stem.casefold()
                stem_matches = [
                    str(name) for name in registry
                    if str(name).casefold() == stem
                ]
                if len(stem_matches) == 1:
                    return stem_matches[0], "nama yang sama dengan file tekstur"
            # A sampled texture must not fall through to RGB matching:
            # current_color may be stale from the previous paint selection.
            return None, ""

        sampled_color = getattr(paint_tool, "current_color", None)
        if sampled_color is not None:
            try:
                color = tuple(round(float(v), 6) for v in sampled_color[:3])
                color_matches = []
                for name, material in registry.items():
                    recipe_color = getattr(material, "color", None)
                    if recipe_color is None:
                        continue
                    candidate = tuple(round(float(v), 6)
                                      for v in recipe_color[:3])
                    if candidate == color:
                        color_matches.append(str(name))
                if len(color_matches) == 1:
                    return color_matches[0], "warna yang cocok"
                if len(color_matches) > 1:
                    return None, "warna dipakai oleh beberapa material"
            except (TypeError, ValueError):
                pass
        return None, ""

    def _on_sampled_material_changed(self):
        """Select the sampled named material in Material Studio."""
        try:
            from tools.paint import PaintTool
            material = PaintTool.current_material
            name = str(getattr(material, "name", "") or "").strip()
            match_reason = "identitas material pada bidang"

            if not name:
                name, match_reason = self._match_sampled_registry_material(
                    self.app, PaintTool
                )

            if not name:
                texture = getattr(PaintTool, "current_texture", None) or {}
                texture_path = str(texture.get("path") or "")
                texture_label = Path(texture_path).name if texture_path else ""
                detail = (
                    f" Tekstur terbaca: {texture_label}."
                    if texture_label else
                    " Bidang hanya membawa warna tanpa identitas material."
                )
                self.status.setText(
                    "Sampel berhasil, tetapi tidak ada satu nama material "
                    "yang cocok secara unik di daftar material." + detail +
                    " Pilih nama material secara manual atau beri identitas "
                    "material pada bidang tersebut."
                )
                return

            index = self.material_combo.findData(name)
            if index < 0:
                # A just-sampled material may not yet be present in the
                # combo's cached list. Add its exact registry name.
                self.material_combo.addItem(name, name)
                index = self.material_combo.findData(name)

            if index >= 0:
                self.material_combo.setCurrentIndex(index)
                # Explicitly reload even when the material was already selected.
                self._load_material()
                message = f"Material sampel aktif: {name} ({match_reason})"
                self.status.setText(message)
                self.surface_status.setText(message)
                self.maps_status.setText(message)
        except Exception as exc:
            self.status.setText(
                f"Material hasil sampel tidak dapat dipilih: {exc}"
            )

    def _material_key(self, name):
        if not name or name == "__all__":
            return "__all__"
        clean = "".join(
            c if c.isalnum() or c in "._-" else "_" for c in str(name)
        ).strip("._-") or "material"
        if clean[0].isdigit():
            clean = "m_" + clean
        return clean

    def refresh(self):
        self._install_sample_hook()
        previous = self._selected_name()
        self.material_combo.blockSignals(True)
        self.material_combo.clear()
        self.material_combo.addItem("All other / unnamed materials", "__all__")
        materials = getattr(self.app.scene, "materials", {}) or {}
        for name in sorted(materials):
            self.material_combo.addItem(str(name), str(name))
        index = self.material_combo.findData(previous)
        if index >= 0:
            self.material_combo.setCurrentIndex(index)
        self.material_combo.blockSignals(False)
        self._load_material()
        self._load_camera_render()
        self._load_lighting()
        self._update_blender_label()

    @staticmethod
    def _guess_material_preset(name):
        text = str(name or "").lower().replace("-", "_").replace(" ", "_")
        if any(word in text for word in ("chrome", "mirror_metal", "mirror_chrome")):
            return "mirror_chrome"
        if any(word in text for word in ("brushed", "hairline")):
            return "brushed_metal"
        if any(word in text for word in ("stainless", "inox", "polished_steel")):
            return "polished_stainless"
        if any(word in text for word in ("aluminium", "aluminum")):
            return "satin_aluminium"
        if any(word in text for word in ("brick", "clay", "masonry", "stone")):
            return "brick"
        if any(word in text for word in ("metal", "steel")):
            return "metal"
        if any(word in text for word in ("concrete", "cement", "plaster")):
            return "concrete"
        if any(word in text for word in ("wood", "timber", "oak", "walnut")):
            return "natural_wood"
        if "marble" in text:
            return "polished_marble"
        if any(word in text for word in ("frosted", "etched_glass", "sandblasted_glass")):
            return "frosted_glass"
        if any(word in text for word in ("glass", "window")):
            return "glass"
        if any(word in text for word in ("porcelain", "granite_tile", "glazed_tile")):
            return "porcelain_gloss"
        if any(word in text for word in ("ceramic", "tile")):
            return "ceramic"
        if any(word in text for word in ("stainless", "inox")):
            return "stainless"
        if any(word in text for word in ("plastic", "polymer")):
            return "plastic"
        if any(word in text for word in ("fabric", "cloth", "carpet")):
            return "fabric"
        if "water" in text:
            return "water"
        return ""

    def _load_material(self, *_):
        name = self._selected_name()
        data = self._data()
        key = self._material_key(name)
        if key == "__all__":
            cfg = data.get("global", {})
            rough, metal, trans, ior = 0.65, 0.0, 0.0, 1.45
            finish = "auto"
            self._set_combo(self.preset_combo, "")
        else:
            cfg = data.get("materials", {}).get(key, {})
            if not cfg:
                guessed = self._guess_material_preset(name)
                if guessed:
                    cfg = dict(MATERIAL_PRESETS[guessed])
                    self._set_combo(self.preset_combo, guessed)
                    self.status.setText(
                        f"Preset {MATERIAL_PRESETS[guessed]['label']} "
                        "dipilih otomatis untuk material baru. Klik Apply Material."
                    )
                else:
                    self._set_combo(self.preset_combo, "")
            else:
                self._set_combo(self.preset_combo, "")
            material = (getattr(self.app.scene, "materials", {}) or {}).get(name)
            from core.finish import PBR, resolve
            picture = None
            if material is not None and getattr(material, "texture", None):
                picture = material.texture.get("path")
            resolved = resolve(
                getattr(material, "finish", None) if material else None,
                name, picture,
                getattr(material, "opacity", None) if material else None,
            )
            rough, metal, trans, ior = PBR.get(resolved, PBR["matte"])
            finish = getattr(material, "finish", None) or "auto"

        cfg = cfg if isinstance(cfg, dict) else {}
        self._set_combo(self.finish_combo, cfg.get("finish", finish))
        self.roughness.setValue(float(cfg.get("roughness", rough)))
        self.metallic.setValue(float(cfg.get("metallic", metal)))
        self.ior.setValue(float(cfg.get("ior", ior)))
        self.transmission.setValue(float(cfg.get("transmission", trans)))
        self.coat.setValue(float(cfg.get("coat", 0.0)))
        self.coat_roughness.setValue(float(cfg.get("coat_roughness", 0.1)))
        self.specular.setValue(float(cfg.get("specular", 0.5)))
        self.anisotropy.setValue(float(cfg.get("anisotropy", 0.0)))
        self.use_tint.setChecked(bool(cfg.get("base_color_tint")))
        tint = cfg.get("base_color_tint") or [1.0, 1.0, 1.0]
        self._tint = tuple(float(v) for v in tint[:3])
        self._update_tint_button()
        self._applying_emission_preset = True
        self._emission_touched = "emission_enabled" in cfg
        self.emission_enabled.blockSignals(True)
        self.emission_strength.blockSignals(True)
        self.emission_enabled.setChecked(bool(cfg.get("emission_enabled", False)))
        self.emission_strength.setValue(float(cfg.get("emission_strength", 1.0)))
        self.emission_glow_enabled.blockSignals(True)
        self.emission_glow_enabled.setChecked(bool(cfg.get("emission_glow_enabled", True)))
        self.emission_glow_enabled.setEnabled(self.emission_enabled.isChecked())
        self.emission_glow_enabled.blockSignals(False)
        self.emission_enabled.blockSignals(False)
        self.emission_strength.blockSignals(False)
        emission_color = cfg.get("emission_color") or [1.0, 1.0, 1.0]
        self._emission_color = tuple(float(v) for v in emission_color[:3])
        self._active_emission_preset = str(
            cfg.get("emission_preset", "custom") or "custom"
        )
        if self.emission_preset_combo.findData(self._active_emission_preset) < 0:
            self._active_emission_preset = "custom"
        self._set_combo(self.emission_preset_combo, self._active_emission_preset)
        self._applying_emission_preset = False
        self._update_emission_button()
        self._update_emission_preview()

        self._set_combo(self.mapping, cfg.get("mapping", "UV"))
        for map_key, edit in self._map_edits.items():
            edit.blockSignals(True)
            edit.setText(str(cfg.get(map_key, "") or ""))
            edit.blockSignals(False)
        self.map_scale_u.setValue(float(cfg.get("map_scale_u", 1.0)))
        self.map_scale_v.setValue(float(cfg.get("map_scale_v", 1.0)))
        self.map_offset_u.setValue(float(cfg.get("map_offset_u", 0.0)))
        self.map_offset_v.setValue(float(cfg.get("map_offset_v", 0.0)))
        self.map_rotation.setValue(float(cfg.get("map_rotation", 0.0)))
        self.use_base_bump.setChecked(
            bool(cfg.get("use_base_texture_bump", False))
        )
        self.normal_strength.setValue(float(cfg.get("normal_strength", 1.0)))
        self.bump_strength.setValue(float(cfg.get("bump_strength", 0.45)))
        self.bump_distance.setValue(float(cfg.get("bump_distance", 0.008)))
        self.height_contrast.setValue(float(cfg.get("height_contrast", 0.65)))
        self.invert_height.setChecked(bool(cfg.get("invert_height", False)))
        self.micro_bump_enabled.setChecked(
            bool(cfg.get("micro_bump_enabled", False))
        )
        self.micro_bump_strength.setValue(
            float(cfg.get("micro_bump_strength", 0.08))
        )
        self.micro_bump_scale.setValue(
            float(cfg.get("micro_bump_scale", 100.0))
        )
        self.use_displacement.setChecked(
            bool(cfg.get("use_displacement", False))
        )
        self.displacement_scale.setValue(
            float(cfg.get("displacement_scale", 0.005))
        )
        self.displacement_midlevel.setValue(
            float(cfg.get("displacement_midlevel", 0.5))
        )
        self.procedural_relief_enabled.setChecked(
            bool(cfg.get("procedural_relief_enabled", False))
        )
        self._set_combo(
            self.procedural_relief_type,
            cfg.get("procedural_relief_type", "brick")
        )
        self.procedural_relief_scale.setValue(
            float(cfg.get("procedural_relief_scale", 8.0))
        )
        self.procedural_relief_strength.setValue(
            float(cfg.get("procedural_relief_strength", 0.22))
        )
        self.procedural_relief_distance.setValue(
            float(cfg.get("procedural_relief_distance", 0.003))
        )
        self.procedural_relief_detail.setValue(
            float(cfg.get("procedural_relief_detail", 4.0))
        )
        self.procedural_relief_contrast.setValue(
            float(cfg.get("procedural_relief_contrast", 0.65))
        )
        self.procedural_relief_invert.setChecked(
            bool(cfg.get("procedural_relief_invert", False))
        )

    @staticmethod
    def _set_combo(combo, value):
        index = combo.findData(value)
        if index < 0:
            index = combo.findData("auto")
        combo.setCurrentIndex(max(0, index))

    def _apply_preset(self):
        key = self.preset_combo.currentData()
        spec = MATERIAL_PRESETS.get(key)
        if not spec:
            return
        self._set_combo(self.finish_combo, spec["finish"])
        for field in (
            "roughness", "metallic", "ior", "transmission", "coat",
            "coat_roughness", "specular", "anisotropy", "bump_strength",
            "bump_distance", "height_contrast", "micro_bump_strength",
            "micro_bump_scale",
        ):
            getattr(self, field).setValue(float(spec[field]))
        self.use_base_bump.setChecked(bool(spec["use_base_texture_bump"]))
        self.invert_height.setChecked(bool(spec["invert_height"]))
        self.micro_bump_enabled.setChecked(bool(spec["micro_bump_enabled"]))
        self.status.setText(
            f"Preset {spec['label']} dimuat ke kontrol. Klik Apply Material "
            "untuk menyimpan PBR sebelum Render."
        )
        self.tabs.setCurrentIndex(0)

    def _choose_tint(self):
        initial = QColor(
            int(self._tint[0] * 255),
            int(self._tint[1] * 255),
            int(self._tint[2] * 255),
        )
        color = QColorDialog.getColor(initial, self, "Base Color Tint")
        if color.isValid():
            self._tint = (
                color.redF(), color.greenF(), color.blueF()
            )
            self._update_tint_button()
            self.use_tint.setChecked(True)

    def _update_tint_button(self):
        r, g, b = [max(0, min(255, int(v * 255))) for v in self._tint]
        self.tint_button.setStyleSheet(
            f"QPushButton {{ background-color: rgb({r},{g},{b}); }}"
        )

    def _mark_emission_touched(self, *_):
        self._emission_touched = True

    def _on_emission_map_changed(self, path):
        self._emission_touched = True
        self._mark_emission_preset_custom()
        if str(path or "").strip() and not self.emission_enabled.isChecked():
            self.emission_enabled.setChecked(True)

    def _choose_emission_color(self):
        initial = QColor(
            int(self._emission_color[0] * 255),
            int(self._emission_color[1] * 255),
            int(self._emission_color[2] * 255),
        )
        color = QColorDialog.getColor(initial, self, "Emission Color")
        if color.isValid():
            self._emission_color = (
                color.redF(), color.greenF(), color.blueF()
            )
            self._update_emission_button()
            self.emission_enabled.setChecked(True)
            self._mark_emission_preset_custom()

    def _update_emission_button(self):
        r, g, b = [max(0, min(255, int(v * 255)))
                   for v in self._emission_color]
        self.emission_color_button.setStyleSheet(
            f"QPushButton {{ background-color: rgb({r},{g},{b}); }}"
        )

    def _update_emission_preview(self):
        if not hasattr(self, "emission_preview_label"):
            return
        spec = EMISSION_PRESETS.get(self._active_emission_preset, {})
        label = spec.get("label", "Custom / Manual")
        r, g, b = self._emission_color
        self.emission_preview_label.setText(
            f"{label} · RGB {r:.2f}, {g:.2f}, {b:.2f} · "
            f"Strength {self.emission_strength.value():.2f}"
        )

    def _emission_preset_selection_changed(self, *_):
        if self._applying_emission_preset:
            return
        selected = self.emission_preset_combo.currentData()
        if selected == "custom":
            self._active_emission_preset = "custom"
            self._update_emission_preview()
            return
        spec = EMISSION_PRESETS.get(selected, {})
        color = spec.get("color", self._emission_color)
        self.emission_preview_label.setText(
            f"Preview: {spec.get('label', 'Emission')} · "
            f"RGB {color[0]:.2f}, {color[1]:.2f}, {color[2]:.2f} · "
            f"Strength {float(spec.get('strength', self.emission_strength.value())):.2f} "
            "· klik Apply Emission Preset untuk menerapkan"
        )
        self.status.setText(
            f"Preset {spec.get('label', 'Emission')} dipilih. "
            "Klik Apply Emission Preset untuk menerapkan warna dan strength."
        )

    def _mark_emission_preset_custom(self, *_):
        if self._applying_emission_preset:
            return
        self._active_emission_preset = "custom"
        combo = getattr(self, "emission_preset_combo", None)
        if combo is not None:
            index = combo.findData("custom")
            if index >= 0 and combo.currentIndex() != index:
                combo.blockSignals(True)
                combo.setCurrentIndex(index)
                combo.blockSignals(False)
        self._update_emission_preview()

    def apply_emission_preset(self):
        if self._selected_name() == "__all__":
            QMessageBox.information(
                self, "Emission Presets",
                "Pilih satu material tertentu pada daftar Material sebelum "
                "menerapkan preset Emission. Preset ini tidak diterapkan secara global."
            )
            return False
        preset_id = self.emission_preset_combo.currentData()
        if preset_id == "custom":
            self._active_emission_preset = "custom"
            self.status.setText(
                "Custom / Manual dipilih. Tidak ada nilai Emission yang ditimpa."
            )
            return True
        spec = EMISSION_PRESETS.get(preset_id)
        if not spec:
            QMessageBox.warning(
                self, "Emission Presets", "Preset Emission tidak dikenal."
            )
            return False

        self._applying_emission_preset = True
        try:
            self._emission_color = tuple(float(v) for v in spec["color"])
            self.emission_strength.setValue(float(spec["strength"]))
            self.emission_enabled.setChecked(True)
            self.emission_glow_enabled.setChecked(True)
            self.emission_glow_enabled.setEnabled(True)
            self._emission_touched = True
            self._active_emission_preset = preset_id
            self._set_combo(self.emission_preset_combo, preset_id)
        finally:
            self._applying_emission_preset = False

        self._update_emission_button()
        self._update_emission_preview()
        self.status.setText(
            f"Preset Emission {spec['label']} diterapkan pada material terpilih. "
            "Klik Apply Material atau Save all settings untuk menyimpan."
        )
        return True

    def _browse_map(self, key):
        current = self._map_edits[key].text().strip()
        start = str(Path(current).parent) if current else ""
        path, _ = QFileDialog.getOpenFileName(
            self, f"Choose {key.replace('_', ' ')}", start, MAP_FILTER
        )
        if path:
            self._map_edits[key].setText(path)

    def _material_config(self):
        config = {
            "finish": self.finish_combo.currentData() or "auto",
            "roughness": self.roughness.value(),
            "metallic": self.metallic.value(),
            "ior": self.ior.value(),
            "transmission": self.transmission.value(),
            "coat": self.coat.value(),
            "coat_roughness": self.coat_roughness.value(),
            "specular": self.specular.value(),
            "anisotropy": self.anisotropy.value(),
            "base_color_tint": list(self._tint) if self.use_tint.isChecked() else None,
            "mapping": self.mapping.currentData() or "UV",
            "map_scale_u": self.map_scale_u.value(),
            "map_scale_v": self.map_scale_v.value(),
            "map_offset_u": self.map_offset_u.value(),
            "map_offset_v": self.map_offset_v.value(),
            "map_rotation": self.map_rotation.value(),
            "use_base_texture_bump": self.use_base_bump.isChecked(),
            "normal_strength": self.normal_strength.value(),
            "bump_strength": self.bump_strength.value(),
            "bump_distance": self.bump_distance.value(),
            "height_contrast": self.height_contrast.value(),
            "invert_height": self.invert_height.isChecked(),
            "micro_bump_enabled": self.micro_bump_enabled.isChecked(),
            "micro_bump_strength": self.micro_bump_strength.value(),
            "micro_bump_scale": self.micro_bump_scale.value(),
            "use_displacement": self.use_displacement.isChecked(),
            "displacement_scale": self.displacement_scale.value(),
            "displacement_midlevel": self.displacement_midlevel.value(),
            "procedural_relief_enabled": self.procedural_relief_enabled.isChecked(),
            "procedural_relief_type": self.procedural_relief_type.currentData() or "brick",
            "procedural_relief_scale": self.procedural_relief_scale.value(),
            "procedural_relief_strength": self.procedural_relief_strength.value(),
            "procedural_relief_distance": self.procedural_relief_distance.value(),
            "procedural_relief_detail": self.procedural_relief_detail.value(),
            "procedural_relief_contrast": self.procedural_relief_contrast.value(),
            "procedural_relief_invert": self.procedural_relief_invert.isChecked(),
        }
        for key, edit in self._map_edits.items():
            path = edit.text().strip()
            if path and not Path(path).is_file():
                raise ValueError(f"File map tidak ditemukan:\n{path}")
            config[key] = path
        if self._emission_touched:
            config.update({
                "emission_enabled": self.emission_enabled.isChecked(),
                "emission_glow_enabled": self.emission_glow_enabled.isChecked(),
                "emission_color": list(self._emission_color),
                "emission_strength": self.emission_strength.value(),
                "emission_preset": self._active_emission_preset,
            })
        return config

    def _camera_config(self):
        return {
            "dof_enabled": self.dof_enabled.isChecked(),
            "focus_auto": self.focus_auto.isChecked(),
            "focus_distance": self.focus_distance.value(),
            "aperture_fstop": self.aperture_fstop.value(),
            "aperture_blades": self.aperture_blades.value(),
            "aperture_ratio": self.aperture_ratio.value(),
        }

    def _render_preset_selection_changed(self, *_):
        if not hasattr(self, "status"):
            return
        selected = self.render_preset_combo.currentData()
        if selected == "custom":
            self._active_render_preset = "custom"
            self.status.setText(
                "Custom / Manual dipilih. Kontrol render saat ini tidak diubah."
            )
        else:
            spec = RENDER_STYLE_PRESETS.get(selected, {})
            self.status.setText(
                f"{spec.get('label', 'Preset')} dipilih. Klik Apply Render "
                "Preset untuk menerapkan gaya ini."
            )

    def _mark_render_preset_custom(self, *_):
        if self._applying_render_preset:
            return
        self._active_render_preset = "custom"
        if hasattr(self, "render_preset_combo"):
            index = self.render_preset_combo.findData("custom")
            if index >= 0 and self.render_preset_combo.currentIndex() != index:
                self.render_preset_combo.blockSignals(True)
                self.render_preset_combo.setCurrentIndex(index)
                self.render_preset_combo.blockSignals(False)
        if hasattr(self, "status"):
            self.status.setText(
                "Pengaturan render manual aktif. Preset: Custom / Manual."
            )

    def apply_render_preset(self):
        preset_id = self.render_preset_combo.currentData()
        if preset_id == "custom":
            self._active_render_preset = "custom"
            self.status.setText(
                "Custom / Manual dipilih. Tidak ada pengaturan yang ditimpa."
            )
            return True
        spec = RENDER_STYLE_PRESETS.get(preset_id)
        if not spec:
            QMessageBox.warning(
                self, "Render Style Presets", "Preset render tidak dikenal."
            )
            return False

        # Only style controls are updated. Engine, samples/quality, output
        # dimensions, ground, keep-blend, camera, HDRI and all material/PBR
        # document data remain untouched.
        self._applying_render_preset = True
        try:
            self._set_combo(self.ambience, spec["ambience"])
            self.studio_reflections.setChecked(
                bool(spec["studio_reflections"])
            )
            self.studio_strength.setValue(float(spec["studio_strength"]))
            self.exposure.setValue(float(spec["exposure"]))
            self.gamma.setValue(float(spec["gamma"]))
            self._set_combo(self.render_look, spec["render_look"])
            self._active_render_preset = preset_id
        finally:
            self._applying_render_preset = False

        self.status.setText(
            f"Preset {spec['label']} diterapkan. Klik Save all settings "
            "atau Render untuk menyimpan dan menggunakannya."
        )
        return True

    def _glow_preset_selection_changed(self, *_):
        if getattr(self, "_applying_glow_preset", False):
            return
        selected = self.glow_preset_combo.currentData()
        if selected == "custom":
            self._active_glow_preset = "custom"
            if hasattr(self, "status"):
                self.status.setText(
                    "Custom / Manual dipilih. Parameter Glow saat ini tidak diubah."
                )
        else:
            spec = GLOW_PRESETS.get(selected, {})
            if hasattr(self, "status"):
                self.status.setText(
                    f"Preset {spec.get('label', 'Glow')} dipilih. "
                    "Klik Apply Glow Preset untuk menerapkan nilainya."
                )

    def _mark_glow_preset_custom(self, *_):
        if getattr(self, "_applying_glow_preset", False):
            return
        self._active_glow_preset = "custom"
        combo = getattr(self, "glow_preset_combo", None)
        if combo is not None:
            index = combo.findData("custom")
            if index >= 0 and combo.currentIndex() != index:
                combo.blockSignals(True)
                combo.setCurrentIndex(index)
                combo.blockSignals(False)
        if hasattr(self, "status"):
            self.status.setText(
                "Pengaturan Glow manual aktif. Preset: Custom / Manual."
            )

    def apply_glow_preset(self):
        preset_id = self.glow_preset_combo.currentData()
        if preset_id == "custom":
            self._active_glow_preset = "custom"
            self.status.setText(
                "Custom / Manual dipilih. Tidak ada parameter yang ditimpa."
            )
            return True
        spec = GLOW_PRESETS.get(preset_id)
        if not spec:
            QMessageBox.warning(
                self, "Glow Presets", "Preset Glow tidak dikenal."
            )
            return False

        self._applying_glow_preset = True
        try:
            self.glow_enabled.setChecked(True)
            self._set_combo(self.glow_effect, spec["effect"])
            self._set_combo(self.glow_quality, spec["quality"])
            self.glow_threshold.setValue(float(spec["threshold"]))
            self.glow_strength.setValue(float(spec["strength"]))
            self.glow_size.setValue(float(spec["size"]))
            self.glow_smoothness.setValue(float(spec["smoothness"]))
            self.glow_saturation.setValue(float(spec["saturation"]))
            self.glow_streaks.setValue(int(spec["streaks"]))
            self.glow_clamp.setChecked(bool(spec["clamp"]))
            self.glow_maximum.setValue(float(spec["maximum"]))
            self.glow_emission_boost_enabled.setChecked(
                bool(spec["emission_boost_enabled"])
            )
            self.glow_emission_boost.setValue(
                float(spec["emission_boost"])
            )
            self._active_glow_preset = preset_id
        finally:
            self._applying_glow_preset = False

        self._set_glow_controls_enabled(True)
        self._sync_glow_level_display()
        self.glow_level_label.setText(f"Preset: {spec['label']}")
        self.status.setText(
            f"Preset Glow {spec['label']} diterapkan. Klik Save all settings "
            "atau Render untuk menyimpan dan menggunakannya."
        )
        return True

    def _mark_glow_level_manual(self, *_):
        if self._applying_glow_level or self._applying_glow_preset:
            return
        if hasattr(self, "glow_level_label"):
            self.glow_level_label.setText("Custom / Manual")

    def _apply_glow_level(self, level):
        if self._applying_glow_preset:
            return
        spec = GLOW_LEVELS.get(int(level))
        if not spec:
            return
        self._applying_glow_level = True
        try:
            self.glow_enabled.setChecked(True)
            self.glow_strength.setValue(float(spec["strength"]))
            self.glow_size.setValue(float(spec["size"]))
            self._active_glow_preset = "custom"
            index = self.glow_preset_combo.findData("custom")
            if index >= 0:
                self.glow_preset_combo.blockSignals(True)
                self.glow_preset_combo.setCurrentIndex(index)
                self.glow_preset_combo.blockSignals(False)
        finally:
            self._applying_glow_level = False
        self._set_glow_controls_enabled(True)
        self.glow_level_label.setText(
            f"Quick: {spec['label']} · Intensity {spec['strength']:.2f} · "
            f"Size {spec['size']:.2f}"
        )
        self.status.setText(
            f"Quick Glow {spec['label']} diterapkan. Threshold dan Glow Source "
            "tidak diubah."
        )

    def _sync_glow_level_display(self):
        targets = [(key, spec) for key, spec in GLOW_LEVELS.items()]
        current_strength = self.glow_strength.value()
        current_size = self.glow_size.value()
        nearest = min(
            targets,
            key=lambda item: abs(item[1]["strength"] - current_strength)
            + abs(item[1]["size"] - current_size),
        )[0]
        self.glow_level_slider.blockSignals(True)
        self.glow_level_slider.setValue(nearest)
        self.glow_level_slider.blockSignals(False)
        spec = GLOW_PRESETS.get(self._active_glow_preset)
        if spec:
            label = f"Preset: {spec['label']}"
        else:
            label = "Custom / Manual"
        self.glow_level_label.setText(label)

    def reset_glow_settings(self):
        # Reset only compositor controls. Material Emission color/strength and
        # per-material inclusion flags are deliberately left untouched.
        self._applying_glow_preset = True
        try:
            self.glow_enabled.setChecked(False)
            self._set_combo(self.glow_effect, "BLOOM")
            self._set_combo(self.glow_quality, "HIGH")
            self._set_combo(self.glow_source, "emission_only")
            self.glow_threshold.setValue(0.50)
            self.glow_strength.setValue(0.65)
            self.glow_size.setValue(0.40)
            self.glow_smoothness.setValue(0.25)
            self.glow_saturation.setValue(1.0)
            self.glow_streaks.setValue(6)
            self.glow_clamp.setChecked(False)
            self.glow_maximum.setValue(10.0)
            self.glow_emission_boost_enabled.setChecked(False)
            self.glow_emission_boost.setValue(1.5)
            self._active_glow_preset = "custom"
            self._set_combo(self.glow_preset_combo, "custom")
        finally:
            self._applying_glow_preset = False
        self.glow_level_slider.blockSignals(True)
        self.glow_level_slider.setValue(1)
        self.glow_level_slider.blockSignals(False)
        self._set_glow_controls_enabled(False)
        self.glow_level_label.setText("Safe default · Glow OFF · Emission only")
        self.status.setText(
            "Glow di-reset dan dimatikan. Sumber disetel ke Material Studio "
            "Emission only; pengaturan Emission material tidak diubah."
        )
        return True

    def _set_glow_controls_enabled(self, enabled):
        enabled = bool(enabled)
        for widget_name in (
            "glow_effect", "glow_quality", "glow_source", "glow_threshold", "glow_strength",
            "glow_size", "glow_level_slider", "glow_smoothness", "glow_saturation", "glow_streaks",
            "glow_clamp", "glow_maximum", "glow_emission_boost_enabled",
            "glow_emission_boost",
        ):
            widget = getattr(self, widget_name, None)
            if widget is not None:
                widget.setEnabled(enabled)
        maximum = getattr(self, "glow_maximum", None)
        clamp = getattr(self, "glow_clamp", None)
        if maximum is not None and clamp is not None:
            maximum.setEnabled(enabled and clamp.isChecked())
        boost = getattr(self, "glow_emission_boost", None)
        boost_toggle = getattr(self, "glow_emission_boost_enabled", None)
        if boost is not None and boost_toggle is not None:
            boost.setEnabled(enabled and boost_toggle.isChecked())

    def _render_config(self):
        hdri = self.hdri_path.text().strip()
        if hdri and not Path(hdri).is_file():
            raise ValueError(f"File HDRI tidak ditemukan:\\n{hdri}")
        return {
            "engine": self.engine.currentData(),
            "quality": self.quality.currentIndex(),
            "width": self.width.value(),
            "height": self.height.value(),
            "ambience": self.ambience.currentData(),
            "ground": self.ground.isChecked(),
            "keep_blend": self.keep_blend.isChecked(),
            "studio_reflections": self.studio_reflections.isChecked(),
            "studio_strength": self.studio_strength.value(),
            "hdri_path": hdri,
            "hdri_strength": self.hdri_strength.value(),
            "exposure": self.exposure.value(),
            "gamma": self.gamma.value(),
            "render_look": self.render_look.currentData() or "None",
            "render_preset": self._active_render_preset,
            "glow_enabled": self.glow_enabled.isChecked(),
            "glow_preset": self._active_glow_preset,
            "glow_effect": self.glow_effect.currentData() or "BLOOM",
            "glow_quality": self.glow_quality.currentData() or "HIGH",
            "glow_source": self.glow_source.currentData() or "all_highlights",
            "glow_threshold": self.glow_threshold.value(),
            "glow_strength": self.glow_strength.value(),
            "glow_size": self.glow_size.value(),
            "glow_smoothness": self.glow_smoothness.value(),
            "glow_saturation": self.glow_saturation.value(),
            "glow_streaks": self.glow_streaks.value(),
            "glow_clamp": self.glow_clamp.isChecked(),
            "glow_maximum": self.glow_maximum.value(),
            "glow_emission_boost_enabled": self.glow_emission_boost_enabled.isChecked(),
            "glow_emission_boost": self.glow_emission_boost.value(),
        }

    def apply_material_settings(self):
        name = self._selected_name()
        try:
            config = self._material_config()
        except ValueError as exc:
            QMessageBox.warning(self, "Material Studio", str(exc))
            return False

        data = self._data()
        if name == "__all__":
            data["global"] = config
        else:
            key = self._material_key(name)
            data["materials"][key] = config

        try:
            self.app.set_document_data(data)
            if name != "__all__":
                material = (getattr(self.app.scene, "materials", {}) or {}).get(name)
                finish_value = config["finish"]
                finish = None if finish_value == "auto" else finish_value
                if material is not None and getattr(material, "finish", None) != finish:
                    from core.history import SetMaterialFinishCommand
                    self.app.viewport.history.execute(
                        SetMaterialFinishCommand(name, finish)
                    )

            message = (
                f"PBR {name if name != '__all__' else 'global'} tersimpan "
                "untuk render Blender Material Studio."
            )
            self.surface_status.setText(message)
            self.maps_status.setText(message)
            self.status.setText(message)
            return True
        except Exception as exc:
            QMessageBox.critical(self, "Material Studio", str(exc))
            return False

    def apply_settings(self):
        name = self._selected_name()
        try:
            config = self._material_config()
            render_config = self._render_config()
            lighting_config = self._lighting_config()
        except ValueError as exc:
            QMessageBox.warning(self, "Material Studio", str(exc))
            return False

        data = self._data()
        if name == "__all__":
            data["global"] = config
        else:
            key = self._material_key(name)
            data["materials"][key] = config

        data["camera"] = self._camera_config()
        data["render"] = render_config
        data["lighting"] = lighting_config

        try:
            self.app.set_document_data(data)
            if name != "__all__":
                material = (getattr(self.app.scene, "materials", {}) or {}).get(name)
                finish_value = config["finish"]
                finish = None if finish_value == "auto" else finish_value
                if material is not None and getattr(material, "finish", None) != finish:
                    from core.history import SetMaterialFinishCommand
                    self.app.viewport.history.execute(
                        SetMaterialFinishCommand(name, finish)
                    )
            self.status.setText(
                f"Pengaturan {name if name != '__all__' else 'global'} tersimpan."
            )
            return True
        except Exception as exc:
            QMessageBox.critical(self, "Material Studio", str(exc))
            return False

    def _load_camera_render(self):
        data = self._data()
        cam = data.get("camera", {})
        ren = data.get("render", {})
        self._applying_render_preset = True
        self.dof_enabled.setChecked(bool(cam.get("dof_enabled", False)))
        self.focus_auto.setChecked(bool(cam.get("focus_auto", True)))
        self.focus_distance.setValue(float(cam.get("focus_distance", 5.0)))
        self.focus_distance.setEnabled(not self.focus_auto.isChecked())
        self.aperture_fstop.setValue(float(cam.get("aperture_fstop", 5.6)))
        self.aperture_blades.setValue(int(cam.get("aperture_blades", 6)))
        self.aperture_ratio.setValue(float(cam.get("aperture_ratio", 1.0)))
        self._set_combo(self.engine, ren.get("engine", "cycles"))
        self.quality.setCurrentIndex(max(0, min(2, int(ren.get("quality", 1)))))
        self.width.setValue(int(ren.get("width", 1600)))
        self.height.setValue(int(ren.get("height", 900)))
        self._set_combo(self.ambience, ren.get("ambience", "day"))
        self.ground.setChecked(bool(ren.get("ground", True)))
        self.keep_blend.setChecked(bool(ren.get("keep_blend", False)))
        self.studio_reflections.setChecked(
            bool(ren.get("studio_reflections", True))
        )
        self.studio_strength.setValue(float(ren.get("studio_strength", 0.25)))
        self.hdri_path.setText(str(ren.get("hdri_path", "") or ""))
        self.hdri_strength.setValue(float(ren.get("hdri_strength", 0.8)))
        # Older projects did not store a render preset. Keep their manual
        # values and label them Custom rather than silently applying a preset.
        old_project_default = "custom" if ren else "architectural_daylight"
        self._active_render_preset = str(
            ren.get("render_preset", old_project_default)
        )
        default_exposure = 0.0 if ren else -0.3
        default_look = "None" if ren else "Medium High Contrast"
        self.exposure.setValue(float(ren.get("exposure", default_exposure)))
        self.gamma.setValue(float(ren.get("gamma", 1.0)))
        self._set_combo(self.render_look, ren.get("render_look", default_look))
        self._applying_glow_preset = True
        self.glow_enabled.setChecked(bool(ren.get("glow_enabled", False)))
        self._set_combo(self.glow_effect, ren.get("glow_effect", "BLOOM"))
        self._set_combo(self.glow_quality, ren.get("glow_quality", "HIGH"))
        self._set_combo(self.glow_source, ren.get("glow_source", "all_highlights"))
        self.glow_threshold.setValue(float(ren.get("glow_threshold", 1.0)))
        self.glow_strength.setValue(float(ren.get("glow_strength", 0.65)))
        self.glow_size.setValue(float(ren.get("glow_size", 0.5)))
        self.glow_smoothness.setValue(float(ren.get("glow_smoothness", 0.25)))
        self.glow_saturation.setValue(float(ren.get("glow_saturation", 1.0)))
        self.glow_streaks.setValue(int(ren.get("glow_streaks", 6)))
        self.glow_clamp.setChecked(bool(ren.get("glow_clamp", False)))
        self.glow_maximum.setValue(float(ren.get("glow_maximum", 10.0)))
        self.glow_emission_boost_enabled.setChecked(
            bool(ren.get("glow_emission_boost_enabled", False))
        )
        self.glow_emission_boost.setValue(
            float(ren.get("glow_emission_boost", 2.0))
        )
        self._active_glow_preset = str(ren.get("glow_preset", "custom") or "custom")
        if self.glow_preset_combo.findData(self._active_glow_preset) < 0:
            self._active_glow_preset = "custom"
        self._set_combo(self.glow_preset_combo, self._active_glow_preset)
        self._applying_glow_preset = False
        self._set_glow_controls_enabled(self.glow_enabled.isChecked())
        self._sync_glow_level_display()
        preset_index = self.render_preset_combo.findData(
            self._active_render_preset
        )
        if preset_index < 0:
            preset_index = self.render_preset_combo.findData("custom")
            self._active_render_preset = "custom"
        self.render_preset_combo.setCurrentIndex(max(0, preset_index))
        self._applying_render_preset = False

    def _browse_hdri(self):
        current = self.hdri_path.text().strip()
        start = str(Path(current).parent) if current else ""
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose environment HDRI", start,
            "HDRI / Environment (*.hdr *.exr *.png *.jpg *.jpeg *.tif *.tiff);;"
            "All files (*.*)"
        )
        if path:
            self.hdri_path.setText(path)

    def _choose_blender(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Choose Blender executable", "",
            "Blender (blender blender.exe Blender);;All files (*)"
        )
        if not path:
            return
        from core import render_blender as rb
        QSettings().setValue(rb.SETTINGS_KEY, path)
        self._update_blender_label()

    def _update_blender_label(self):
        try:
            from core import render_blender as rb
            saved = str(QSettings().value(rb.SETTINGS_KEY, "") or "")
            found = rb.find_blender(saved or None)
            self.blender_label.setText(
                found.where if found else "Blender belum ditemukan."
            )
        except Exception:
            self.blender_label.setText("Status Blender belum tersedia.")

    def _patched_render_script(self, target_path):
        from core import render_blender as rb
        source = rb.render_script().read_text(encoding="utf-8")
        main_marker = "\ndef main():"
        finish_marker = "    apply_finishes()\n"
        camera_marker = '    set_camera(scene, job["camera"], w, h)\n'
        lights_marker = '    add_lights(scene, job.get("lights") or [])\n'
        view_marker = '    # Blender 5 no longer prints per-sample progress in the background;'
        if main_marker not in source:
            raise RuntimeError("Fungsi main() render_scene.py tidak ditemukan.")
        if finish_marker not in source:
            raise RuntimeError("Titik integrasi apply_finishes() tidak ditemukan.")
        if camera_marker not in source:
            raise RuntimeError("Titik integrasi kamera tidak ditemukan.")
        if lights_marker not in source:
            raise RuntimeError("Titik integrasi pencahayaan tidak ditemukan.")
        if view_marker not in source:
            raise RuntimeError("Titik integrasi color management tidak ditemukan.")

        source = source.replace(
            main_marker,
            "\n" + BLENDER_MATERIAL_HOOK + "\n\ndef main():",
            1,
        )
        source = source.replace(
            finish_marker,
            finish_marker
            + "    apply_material_studio(job.get('material_studio', {}), "
              "job.get('engine', 'eevee'))\n",
            1,
        )
        source = source.replace(
            camera_marker,
            camera_marker
            + "    apply_camera_effects(scene, job.get('camera_effects', {}), "
              "job['camera'])\n",
            1,
        )
        source = source.replace(
            lights_marker,
            lights_marker
            + "    apply_material_studio_lighting("
              "job.get('material_studio', {}).get('studio', {}))\n"
            + "    apply_material_studio_user_lights("
              "scene, job.get('material_studio', {}).get('lighting', {}))\n",
            1,
        )
        # Apply the render style and final color-management overrides only
        # after render_scene.py assigns its own default exposure/look.
        source = source.replace(
            view_marker,
            "    apply_material_studio_render_style("
            "scene, job.get('material_studio', {}).get('render_style', {}), "
            "job.get('engine', 'eevee'))\n"
            "    apply_material_studio_look("
            "scene, job.get('material_studio', {}).get('look', {}))\n"
            "    apply_material_studio_glow("
            "scene, job.get('material_studio', {}).get('glow', {}))\n"
            + view_marker,
            1,
        )
        target_path.write_text(source, encoding="utf-8")

    def start_render(self):
        if self._proc is not None:
            return
        if not self.apply_settings():
            return

        try:
            from core import render_blender as rb
            saved = str(QSettings().value(rb.SETTINGS_KEY, "") or "")
            found = rb.find_blender(saved or None)
            if found is None:
                QMessageBox.warning(
                    self, "Material Studio",
                    "Blender tidak ditemukan. Instal Blender atau pilih "
                    "blender.exe melalui tombol Choose…."
                )
                return

            data = self._data()
            ren = data.get("render", {})
            stamp = time.strftime("%Y%m%d-%H%M%S")
            self._work = rb.work_base() / "material-studio" / stamp
            plugin_data = getattr(self.app.scene, "plugin_data", {}) or {}
            render_state = plugin_data.get("render_blender.py", {})
            if not isinstance(render_state, dict):
                render_state = {}
            saved_lights = render_state.get("lights", [])
            saved_sun_scale = render_state.get("sun_scale", 1.0)
            job = rb.write_job(
                self.app.scene, self.app.viewport.camera, self._work,
                engine=ren.get("engine", "cycles"),
                quality=int(ren.get("quality", 1)),
                width=int(ren.get("width", 1600)),
                height=int(ren.get("height", 900)),
                ground=bool(ren.get("ground", True)),
                keep_blend=bool(ren.get("keep_blend", False)),
                ambience=ren.get("ambience", render_state.get("ambience", "day")),
                lights=saved_lights,
                sun_scale=float(saved_sun_scale),
            )

            job_data = json.loads(job.read_text(encoding="utf-8"))
            job_data["material_studio"] = {
                "materials": data.get("materials", {}),
                "global": data.get("global", {}),
                "studio": {
                    "enabled": bool(ren.get("studio_reflections", True)),
                    "strength": float(ren.get("studio_strength", 0.25)),
                    "hdri_path": str(ren.get("hdri_path", "") or ""),
                    "hdri_strength": float(ren.get("hdri_strength", 0.8)),
                },
                "look": {
                    "exposure": float(ren.get("exposure", 0.0)),
                    "gamma": float(ren.get("gamma", 1.0)),
                    "render_look": str(ren.get("render_look", "None") or "None"),
                },
                "render_style": {
                    "preset": str(ren.get("render_preset", "architectural_daylight")),
                    "hdri_path": str(ren.get("hdri_path", "") or ""),
                },
                "lighting": data.get("lighting", {"enabled": True, "lights": []}),
                "glow": {
                    "enabled": bool(ren.get("glow_enabled", False)),
                    "effect": str(ren.get("glow_effect", "BLOOM") or "BLOOM"),
                    "quality": str(ren.get("glow_quality", "HIGH") or "HIGH"),
                    "source": str(ren.get("glow_source", "all_highlights") or "all_highlights"),
                    "threshold": float(ren.get("glow_threshold", 1.0)),
                    "strength": float(ren.get("glow_strength", 0.65)),
                    "size": float(ren.get("glow_size", 0.5)),
                    "smoothness": float(ren.get("glow_smoothness", 0.25)),
                    "saturation": float(ren.get("glow_saturation", 1.0)),
                    "streaks": int(ren.get("glow_streaks", 6)),
                    "clamp": bool(ren.get("glow_clamp", False)),
                    "maximum": float(ren.get("glow_maximum", 10.0)),
                    "emission_boost_enabled": bool(ren.get("glow_emission_boost_enabled", False)),
                    "emission_boost": float(ren.get("glow_emission_boost", 2.0)),
                },
            }
            job_data["camera_effects"] = data.get("camera", {})
            job.write_text(json.dumps(job_data, indent=2), encoding="utf-8")

            argv = rb.command(found, job)
            script_path = job.parent / rb.render_script().name
            self._patched_render_script(script_path)
            self._output = Path(job_data["output"])

            proc = QProcess(self)
            env = QProcessEnvironment()
            for key, value in rb.clean_env().items():
                env.insert(str(key), str(value))
            proc.setProcessEnvironment(env)
            proc.setProcessChannelMode(QProcess.MergedChannels)
            proc.readyReadStandardOutput.connect(self._read_output)
            proc.finished.connect(self._render_finished)
            proc.errorOccurred.connect(self._render_error)
            self._proc = proc
            self._log = []
            self._buffer = ""
            self.progress.setValue(0)
            self.open_render_button.setEnabled(False)
            self.render_button.setEnabled(False)
            self.stop_button.setEnabled(True)
            self.status.setText("Blender sedang menyiapkan scene dan material…")
            proc.start(argv[0], argv[1:])
        except Exception as exc:
            self._proc = None
            self.render_button.setEnabled(True)
            self.stop_button.setEnabled(False)
            QMessageBox.critical(self, "Material Studio", str(exc))

    def _read_output(self):
        if self._proc is None:
            return
        raw = bytes(self._proc.readAllStandardOutput()).decode(
            "utf-8", "replace"
        )
        self._buffer += raw
        lines = self._buffer.split("\n")
        self._buffer = lines.pop() if lines else ""
        from core import render_blender as rb
        for line in lines:
            self._log.append(line)
            fraction = rb.progress_of(line)
            if fraction is not None:
                self.progress.setValue(int(fraction * 1000))
                self.status.setText(f"Rendering… {int(fraction * 100)}%")
            elif "material studio" in line.lower():
                self.status.setText(line.replace("INGETRAZO ", ""))
            elif line.startswith("INGETRAZO rendering"):
                self.status.setText("Blender sedang merender…")

    def _render_finished(self, code, _exit_status):
        self._proc = None
        self.render_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        if code == 0 and self._output is not None and self._output.is_file():
            self.progress.setValue(1000)
            self.status.setText("Render selesai.")
            self.open_render_button.setEnabled(True)
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._output)))
        else:
            tail = "\n".join(self._log[-12:])
            self.status.setText("Render gagal. Periksa log Blender.")
            QMessageBox.warning(
                self, "Material Studio",
                "Render tidak menghasilkan gambar.\n\n" + tail[-3500:]
            )

    def _render_error(self, _error):
        self.status.setText("Blender gagal dijalankan.")
        self._proc = None
        self.render_button.setEnabled(True)
        self.stop_button.setEnabled(False)

    def stop_render(self):
        if self._proc is not None:
            self._proc.kill()
            self.status.setText("Render dihentikan.")

    def open_render(self):
        if self._output is not None and self._output.is_file():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._output)))



def _make_material_studio_pick_tool(prompt, done, cancelled, preview):
    """One-click point tool using IngeTrazo's native snap/inference context."""
    from tools.base import Tool

    class _MaterialStudioPickPoint(Tool):
        name = prompt
        shortcut = None
        uses_snap = True

        def on_activate(self, viewport):
            preview(None)

        def on_deactivate(self, viewport):
            preview(None)

        def on_hover(self, ctx):
            preview(QVector3D(ctx.world))

        def on_click(self, ctx):
            on_face = ctx.snap is not None and ctx.snap.kind == "on_face"
            done(QVector3D(ctx.world), on_face)

        def on_key(self, viewport, key, modifiers):
            if key == Qt.Key_Escape:
                cancelled()
                return True
            return False

        def rubber_band_lines(self):
            return []

    return _MaterialStudioPickPoint()


def _ms_rotate_xyz(rotation_degrees, vector):
    """Rotate a local vector with Blender-style XYZ Euler angles."""
    rx, ry, rz = [math.radians(float(v)) for v in rotation_degrees[:3]]
    x, y, z = [float(v) for v in vector]
    cx, sx = math.cos(rx), math.sin(rx)
    cy, sy = math.cos(ry), math.sin(ry)
    cz, sz = math.cos(rz), math.sin(rz)
    # Apply X, then Y, then Z.
    y, z = y * cx - z * sx, y * sx + z * cx
    x, z = x * cy + z * sy, -x * sy + z * cy
    x, y = x * cz - y * sz, x * sz + y * cz
    return (x, y, z)


def _ms_vadd(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def _ms_vscale(v, factor):
    return (v[0] * factor, v[1] * factor, v[2] * factor)


def _ms_light_axes(light):
    rotation = light.get("rotation", [0.0, 0.0, 0.0])
    direction = _ms_rotate_xyz(rotation, (0.0, 0.0, -1.0))
    right = _ms_rotate_xyz(rotation, (1.0, 0.0, 0.0))
    up = _ms_rotate_xyz(rotation, (0.0, 1.0, 0.0))
    return direction, right, up


def _ms_project(viewport, point):
    try:
        px = viewport._world_to_pixel(QVector3D(*point))
        if px is None:
            return None
        return QPointF(float(px[0]), float(px[1]))
    except Exception:
        return None


def _ms_draw_world_polyline(viewport, painter, points, pen, closed=False):
    if len(points) < 2:
        return
    projected = [_ms_project(viewport, point) for point in points]
    painter.setPen(pen)
    count = len(projected)
    pairs = [(i, i + 1) for i in range(count - 1)]
    if closed:
        pairs.append((count - 1, 0))
    for a, b in pairs:
        if projected[a] is not None and projected[b] is not None:
            painter.drawLine(projected[a], projected[b])


def _ms_draw_light_guide(light, viewport, painter, tint, selected=False):
    """Draw non-geometric 3D lighting guides as viewport overlay strokes."""
    kind = str(light.get("type", "AREA")).upper()
    position = tuple(float(v) for v in light.get("location", [0, -5, 5])[:3])
    direction, right, up = _ms_light_axes(light)
    guide_color = QColor(tint)
    guide_color.setAlpha(205 if selected else 145)
    guide_pen = QPen(guide_color, 1.45 if selected else 1.15, Qt.DashLine)
    strong_pen = QPen(guide_color, 1.9 if selected else 1.55)

    if kind == "POINT":
        # A spherical cage: three orthogonal great circles plus two latitude
        # rings. This reads as a 3D influence volume rather than a flat circle.
        radius = max(0.01, float(light.get("range", 10.0)))
        finite_range = bool(light.get("use_custom_range", True))
        segments = 64
        sphere_color = QColor(guide_color)
        sphere_color.setAlpha(205 if selected else 135)
        sphere_style = Qt.DashLine if finite_range else Qt.DotLine
        sphere_pen = QPen(sphere_color, 1.65 if selected else 1.15, sphere_style)
        latitude_color = QColor(guide_color)
        latitude_color.setAlpha(150 if selected else 95)
        latitude_pen = QPen(latitude_color, 1.0, Qt.DotLine)

        # Main meridians / great circles.
        for plane in ("XY", "XZ", "YZ"):
            ring = []
            for i in range(segments):
                a = 2.0 * math.pi * i / segments
                c, s = math.cos(a) * radius, math.sin(a) * radius
                if plane == "XY":
                    offset = (c, s, 0.0)
                elif plane == "XZ":
                    offset = (c, 0.0, s)
                else:
                    offset = (0.0, c, s)
                ring.append(_ms_vadd(position, offset))
            _ms_draw_world_polyline(viewport, painter, ring, sphere_pen, closed=True)

        # Latitude rings at +/- 30 degrees add a visible spherical grid.
        latitude_z = radius * 0.5
        latitude_radius = radius * math.sqrt(0.75)
        for z in (-latitude_z, latitude_z):
            ring = []
            for i in range(segments):
                a = 2.0 * math.pi * i / segments
                ring.append(_ms_vadd(position, (
                    latitude_radius * math.cos(a),
                    latitude_radius * math.sin(a),
                    z,
                )))
            _ms_draw_world_polyline(viewport, painter, ring, latitude_pen, closed=True)

        # Radius leader and end marker. Use the light's local X axis so the
        # measurement remains visually attached when the light is rotated.
        radius_end = _ms_vadd(position, _ms_vscale(right, radius))
        _ms_draw_world_polyline(viewport, painter, [position, radius_end], strong_pen)
        end_px = _ms_project(viewport, radius_end)
        if end_px is not None:
            painter.setPen(QPen(guide_color, 1.5))
            painter.drawEllipse(end_px, 3.0 if selected else 2.2,
                                3.0 if selected else 2.2)
            if selected:
                label = f"R = {radius:g} u"
                if not finite_range:
                    label += " · guide only"
                painter.setPen(QPen(guide_color, 1.0))
                painter.drawText(QPointF(end_px.x() + 7.0, end_px.y() - 6.0), label)

    elif kind == "SPOT":
        distance = max(0.01, float(light.get("range", 10.0)))
        half_angle = math.radians(max(1.0, min(179.0, float(
            light.get("spot_size", 45.0)))) / 2.0)
        base_radius = distance * math.tan(half_angle)
        base_center = _ms_vadd(position, _ms_vscale(direction, distance))
        ring = []
        segments = 48
        for i in range(segments):
            a = 2.0 * math.pi * i / segments
            offset = _ms_vadd(
                _ms_vscale(right, base_radius * math.cos(a)),
                _ms_vscale(up, base_radius * math.sin(a)),
            )
            ring.append(_ms_vadd(base_center, offset))
        _ms_draw_world_polyline(viewport, painter, ring, guide_pen, closed=True)
        # Four generatrices and the centre axis describe the cone direction.
        for i in range(0, segments, 12):
            _ms_draw_world_polyline(
                viewport, painter, [position, ring[i]], strong_pen
            )
        _ms_draw_world_polyline(
            viewport, painter, [position, base_center], guide_pen
        )

    elif kind == "AREA":
        sx = max(0.001, float(light.get("size", 4.0)))
        sy = max(0.001, float(light.get("size_y", 2.0)))
        shape = str(light.get("shape", "RECTANGLE")).upper()
        if shape in ("DISK", "ELLIPSE"):
            if shape == "DISK":
                sy = sx
            ring = []
            for i in range(48):
                a = 2.0 * math.pi * i / 48
                offset = _ms_vadd(
                    _ms_vscale(right, 0.5 * sx * math.cos(a)),
                    _ms_vscale(up, 0.5 * sy * math.sin(a)),
                )
                ring.append(_ms_vadd(position, offset))
            _ms_draw_world_polyline(viewport, painter, ring, strong_pen, closed=True)
        else:
            if shape == "SQUARE":
                sy = sx
            corners = []
            for x, y in ((-sx/2, -sy/2), (sx/2, -sy/2),
                         (sx/2, sy/2), (-sx/2, sy/2)):
                offset = _ms_vadd(_ms_vscale(right, x), _ms_vscale(up, y))
                corners.append(_ms_vadd(position, offset))
            _ms_draw_world_polyline(viewport, painter, corners, strong_pen, closed=True)
        axis_len = max(0.25, min(2.0, max(sx, sy) * 0.35))
        _ms_draw_world_polyline(
            viewport, painter,
            [position, _ms_vadd(position, _ms_vscale(direction, axis_len))],
            guide_pen,
        )

    elif kind == "SUN":
        # A sun has direction, not a finite point-light radius.
        for offset_factor in (-0.22, 0.0, 0.22):
            start = _ms_vadd(position, _ms_vscale(right, offset_factor))
            end = _ms_vadd(start, _ms_vscale(direction, 2.0))
            _ms_draw_world_polyline(viewport, painter, [start, end], strong_pen)
        tip = _ms_vadd(position, _ms_vscale(direction, 2.0))
        arrow_a = _ms_vadd(tip, _ms_vscale(right, 0.12))
        arrow_b = _ms_vadd(tip, _ms_vscale(up, 0.12))
        _ms_draw_world_polyline(viewport, painter, [arrow_a, tip, arrow_b], strong_pen)

def _draw_material_studio_lights(panel, viewport, painter):
    """Draw light glyphs and 3D guides as overlays, never render geometry."""
    lights = panel._lights
    if not lights and panel._light_preview is None:
        return
    painter.save()
    try:
        painter.setRenderHint(QPainter.Antialiasing, True)
        font = QFont()
        font.setPointSize(8)
        painter.setFont(font)
        selected = panel._view_pick
        active = panel._selected_light()
        selected_id = active.get("id") if active else None
        guides_visible = getattr(panel, "show_light_guides", None)
        guides_visible = guides_visible is None or guides_visible.isChecked()

        for light in lights:
            try:
                position = QVector3D(*light.get("location", [0.0, 0.0, 0.0]))
                pixel = viewport._world_to_pixel(position)
            except Exception:
                pixel = None
            if pixel is None:
                continue
            centre = QPointF(float(pixel[0]), float(pixel[1]))
            rgb = light.get("color", [1.0, 1.0, 1.0])
            try:
                srgb = [panel._linear_to_srgb(v) for v in rgb[:3]]
                tint = QColor.fromRgbF(*srgb)
            except Exception:
                tint = QColor(255, 235, 120)
            if not light.get("enabled", True):
                tint = QColor(145, 145, 145)

            kind = str(light.get("type", "AREA")).upper()
            if guides_visible:
                _ms_draw_light_guide(
                    light, viewport, painter, tint,
                    selected=(light.get("id") == selected or light.get("id") == selected_id)
                )

            # Screen-space lamp glyph remains the reliable selection handle.
            painter.setPen(QPen(QColor(35, 35, 35), 1.2))
            painter.setBrush(tint)
            if kind == "AREA":
                painter.drawRoundedRect(QRectF(centre.x() - 7, centre.y() - 5,
                                               14, 10), 2, 2)
                painter.setPen(QPen(tint.darker(145), 1.2))
                painter.drawLine(QPointF(centre.x() - 4, centre.y() + 1),
                                 QPointF(centre.x() + 4, centre.y() + 1))
            elif kind == "SUN":
                painter.drawEllipse(centre, 5.0, 5.0)
                painter.setPen(QPen(tint.darker(145), 1.5))
                for ray in range(8):
                    angle = ray * math.pi / 4.0
                    painter.drawLine(
                        QPointF(centre.x() + 7 * math.cos(angle),
                                centre.y() + 7 * math.sin(angle)),
                        QPointF(centre.x() + 11 * math.cos(angle),
                                centre.y() + 11 * math.sin(angle)),
                    )
            else:
                painter.drawEllipse(centre, 5.5, 5.5)
                painter.setPen(QPen(tint.darker(150), 1.5))
                painter.drawLine(QPointF(centre.x() - 3, centre.y() + 7),
                                 QPointF(centre.x() + 3, centre.y() + 7))
                painter.drawLine(QPointF(centre.x() - 2, centre.y() + 9),
                                 QPointF(centre.x() + 2, centre.y() + 9))
                if kind == "SPOT":
                    painter.setPen(QPen(tint.darker(130), 1.2, Qt.DashLine))
                    painter.drawLine(QPointF(centre.x(), centre.y() + 11),
                                     QPointF(centre.x(), centre.y() + 20))

            if kind != "AREA":
                painter.setPen(QPen(tint.darker(140), 1.2))
                for ray in range(8):
                    angle = ray * math.pi / 4.0
                    painter.drawLine(
                        QPointF(centre.x() + 7 * math.cos(angle),
                                centre.y() + 7 * math.sin(angle)),
                        QPointF(centre.x() + 10 * math.cos(angle),
                                centre.y() + 10 * math.sin(angle)),
                    )

            light_id = light.get("id")
            if light_id == selected or light_id == selected_id:
                painter.setBrush(Qt.NoBrush)
                painter.setPen(QPen(QColor(242, 115, 41), 2.5))
                painter.drawEllipse(centre, 14.0, 14.0)
                painter.setPen(QPen(QColor(25, 25, 25), 1.0))
                label = f"{light.get('name', 'Light')} · {kind}"
                painter.drawText(QPointF(centre.x() + 16, centre.y() - 9), label)

        if panel._light_preview is not None:
            pixel = _ms_project(viewport, (
                panel._light_preview.x(), panel._light_preview.y(),
                panel._light_preview.z()
            ))
            if pixel is not None:
                painter.setBrush(Qt.NoBrush)
                painter.setPen(QPen(QColor(30, 150, 235), 2.0, Qt.DashLine))
                painter.drawEllipse(pixel, 9.0, 9.0)
                painter.drawLine(QPointF(pixel.x() - 13, pixel.y()),
                                 QPointF(pixel.x() + 13, pixel.y()))
                painter.drawLine(QPointF(pixel.x(), pixel.y() - 13),
                                 QPointF(pixel.x(), pixel.y() + 13))
    finally:
        painter.restore()

def setup(app):
    """IngeTrazo extension entry point."""
    if getattr(app, "api_version", None) not in (1, 2):
        raise RuntimeError("Material Studio requires Extension API 1 or 2.")

    from core.version import __version__
    if not str(__version__).startswith("0.6."):
        raise RuntimeError(
            f"Material Studio targets IngeTrazo 0.6.x; detected {__version__}."
        )

    panel = MaterialStudioPanel(app)
    dock = app.add_panel(
        "Material Studio", panel, name="material_studio", start_hidden=False
    )
    app.add_menu_action(
        "Material Studio…",
        lambda: app.show_panel(dock),
        tip="Edit PBR materials, texture relief and camera depth of field."
    )
    app.on_document_changed(panel.refresh)
    add_overlay = getattr(app, "add_overlay", None)
    add_pickable = getattr(app, "add_pickable", None)
    try:
        if callable(add_overlay):
            add_overlay(lambda viewport, painter: _draw_material_studio_lights(
                panel, viewport, painter
            ))
        if callable(add_pickable):
            add_pickable(
                pick=panel._pick_viewport_light,
                on_select=panel._on_viewport_light_selected,
                delete=panel._delete_light_from_view,
            )
        panel._viewport_helpers_available = callable(add_overlay) and callable(add_pickable)
        try:
            app.viewport.installEventFilter(panel)
            panel._light_move_shortcut_installed = True
        except Exception:
            panel._light_move_shortcut_installed = False
        if not panel._viewport_helpers_available:
            panel.status.setText(
                "Viewport light helpers tidak tersedia pada Extension API ini; "
                "gunakan koordinat XYZ dan Render."
            )
    except Exception as exc:
        panel._viewport_helpers_available = False
        panel.status.setText(f"Viewport light helper gagal diaktifkan: {exc}")
