# IngeTrazo Material Studio v0.4.15

Target: IngeTrazo 0.6.x · tested-version metadata: 0.6.2.1
Blender: 5.3 recommended (with legacy Blender 4.x compositor fallback)
License: GPL-3.0-or-later

## What's new in v0.4.15

- Replaces remaining Indonesian user-facing panel descriptions, tooltips, prompts, status messages, validation errors, and render messages with English source strings.
- Routes these user-facing messages through IngeTrazo's core.i18n.tr() translation function.
- Keeps the existing Material Studio feature set and project-data structure.
- Does not intentionally change PBR calculations, material presets, texture maps, relief, Emission, Glow/Bloom, lighting, camera, or the Blender render pipeline.

## Features retained

- Per-material PBR properties and texture maps.
- Image-based Height / Normal maps, Base Color bump, and micro-bump.
- Procedural Surface Relief for materials without a dedicated Height Map.
- Procedural patterns: Brick / Mortar, Stone / Cellular, Concrete / Plaster, Wood Grain, Fabric Weave, and Fine Noise.
- Controls for pattern scale, relief strength, relief depth, detail, contrast, and pattern inversion.
- Emission and Glow / Bloom controls.
- Lighting, camera depth of field, and render style presets.
- Blender Cycles / EEVEE rendering, including the legacy Blender 4.x compositor fallback.
- Extension-specific material and camera settings stored in the .igz project.

## Translation behavior

English is the source language passed to core.i18n.tr(). The host application's language catalogues provide translations. Missing entries fall back to readable English. Spanish, Portuguese, and Indonesian translations for newly introduced keys require corresponding entries in IngeTrazo's central i18n catalogues.

## Install

Preferred installation:
1. Open **Extensions → Extension Manager** in IngeTrazo.
2. Find **Material Studio** and choose **Install**.

Manual installation:
1. Close IngeTrazo.
2. Copy the complete `material_studio` folder from this ZIP into the user plugins folder.
3. Reopen IngeTrazo and open **Material Studio**.

## Test procedural brick relief

1. Select the brick material in Material Studio.
2. Open **Maps & Relief**.
3. Find **Procedural Surface Relief · no image map required**.
4. Enable **Enable procedural surface pattern**.
5. Choose **Brick / Mortar**.
6. Start with Pattern scale `8.0`, Relief strength `0.22`, Relief depth `0.003 m`, Pattern detail `4.0`, and Pattern contrast `0.65`.
7. If the raised/recessed areas look reversed, toggle **Invert procedural pattern**.
8. Click **Apply PBR Maps & Relief**, then render.

## Suggested tests

- Try **Concrete / Plaster** on a plain gray material.
- Try **Wood Grain** on a plain brown material.
- Try **Stone / Cellular** on a plain stone-colored material.
- Compare the same view with procedural relief off and on.
- Keep relief depth subtle at first; too much bump can look inflated or noisy.

## Important limitations and validation

- Procedural relief uses shader bump by default, so it changes shading/highlights rather than the object's silhouette.
- True geometric displacement is optional, Cycles-only, and depends on adaptive subdivision support and mesh/render settings.
- Python source compilation and ZIP structure checks are performed for this package.
- An actual IngeTrazo GUI test and final Blender render test of v0.4.15 are still required in the target installation before publication.
